Mechanical Load Tracker
#######################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

This component calcualtes and stores information about the alteration of the whole mechanical system. 
The alteration is calculated using the motor torque.

These calculation is applicable for all steering systems.

.. only:: confidential

   Block Diagram
   =============

   .. image:: MechanicalLoadTracker_CalMan_BlockDiagram.png 

Input Signals
-------------

================================   ====   ======================
Signal Name                        Unit   Description
================================   ====   ======================
mApplI_LimitedMotorTorque_xds16     Nm     limited motor torque
================================   ====   ======================


Output Signals
--------------

=================================   ====   =====================
Signal Name                         Unit   Description
=================================   ====   =====================
yLdTrkI_GenMechanicalLoad_xdu32            Value of the generic mechanical alteration
yLdTrkI_GenMechanicalLoadH_xdu32           Value of the generic mechanical alteration high
=================================   ====   =====================

.. only:: confidential

   =================================   ====   =====================
   Signal Name [Measurement Signals]   Unit   Description
   =================================   ====   =====================
   fLdTrk_GenMechJobResultOK_xdb              Job Result of NVM Read all operation
   mLdTrk_FiltMmot4GenMech_xds16       Nm     Filtered motor torque for Generic Mechanical Load Tracker
   zLdTrk_ValuesInResiduum_xdu16              Values in residuum, max value must be equal to size of yLdTrk_ResiduumGenMechLoad_xau8
   yLdTrk_ResiduumGenMechLoad_xau8            Residuum Gen Mech, array size = (2*amount of classes+1)*2
   =================================   ====   =====================

   Detailed Description
   --------------------
   The load encountered by the steering system during its life time is calculated based on the changes in the limited motor torque and stored persistently. 
   This diagnostic information is taken into consideration when deciding if the steering system can be refurbished or it must be scrapped.


   Calibration/Application Parameters
   ==================================

   Provide a table of internal calibration parameters.
   
   ==========================================   =====   ==================   =============================================
   Parameter Name                               Unit    Range                Description
   ==========================================   =====   ==================   =============================================
   xLdTrk_FilterFactMMOTGenMech_XDU16                   0.0009765625 .. 1    filter factor motor torque
   ==========================================   =====   ==================   =============================================
   
   All other Rom-Parameter are dependent to Wöhler-Versuche or Wöhler-Kennlinien. These Rom-Parameter are set by MechanicalDataSheet.



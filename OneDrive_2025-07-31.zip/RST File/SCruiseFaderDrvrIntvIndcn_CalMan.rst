.. only:: not confidential

   Smart Cruise Fading | Driver Intervention Indication
   #####################################################

   The component monitors the torsionbar torque as long as SCI mode is active (fade-in, active, fade-out) to check for a driver intervention indication.
   
.. only:: confidential

   Smart Cruise Fading | Driver Intervention Indication
   #####################################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   The software component Smart Cruise Fading Driver Intervention Indication is part of the Smart Cruise Fading functionality.
   The component monitors the torsionbar torque as long as SCI mode is active (fade-in, active, fade-out) to check for a driver intervention indication.
   This indication may be passed to the superior ECU or may be evaluated by the Fader as a fade-out reason.

   Based on the torsion bar torque input a Emergency event indication of driver intervention indications is calculated.


   Block Diagram
   =============

   .. image:: SCruiseFaderDrvrIntvIndcn_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ====================================   ====   ====================================================================================================
   Signal Name                            Unit   Description
   ====================================   ====   ====================================================================================================
   fSCruiseFadrI_MonSafeOk_xdb                   Indicate whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   fSCruiseLimrI_MonSafeOk_xdb                   Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   mApplI_TorsionBarTorque_xds16          Nm     HW LIB: torsion bar torque
   sHwlWrapI_TorsionBarTorqueState_xde           HwLib TorsionBar Torque State
   vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16   km/h   Maximum vehicle speed
   xSCruiseFadrI_Prgs2SCI_xdu16                  Factor indicates fading progress (0=SFC; 1=SCI)
   ====================================   ====   ====================================================================================================


   Output Signals
   --------------

   ===========================================   ====   ====================================================================
   Signal Name                                   Unit   Description
   ===========================================   ====   ====================================================================
   fSCruiseFadrI_EmgyEveIndcn_xdb                       Emergency event due to high torsion bar torque indicated
   tSCruiseFadr_ElpdDeadTiEmgcyEveReplcmt_xdu8   s      Elapsed dead time of TBT evaluation after transition to replcmt mode
   tSCruiseFadr_EmgyEveIndcnTmr_xdu8             s      Debounce timer of emergency event indication [s]
   ===========================================   ====   ====================================================================


   Detailed Description
   --------------------

   Emergency event indication:

   Once the torsion bar torque exceeds the calibrated torque threshold (vehicle speed dependent) of the emergency event indication the debouncing starts. While debouncing a time counter is increased.
   Once this time counter exceeds the calibrated time threshold the emergency event indication flag is set.
   Setting the emergency event indication flag is suppressed right after the transition from normal SCI mode to replacement mode to not consider torsion bar torque oscillations caused by the transition itself.
   This flag as well as the debouncing is reset as soon as the torsion bar torque falls below the calibrated torque threshold of the emergency event indication.

   Calibration/Application Parameters
   ==================================

   =======================================   ====   ==========   ============================================================================
   Parameter Name                            Unit   Range        Description
   =======================================   ====   ==========   ============================================================================
   mSCruiseFadr_TrqThdEmgyEveIndcn_XAU16     Nm     0..25        TBT threshold to start emergency event debouncing dependent on vehicle speed
   tSCruiseFadr_DeadTiEmgcyEveReplcmt_XDU8   s      0.001..0.2   Dead time not considering TBT for DII after transition to replacement torque
   tSCruiseFadr_DebTmrEmgyEveIndcn_XDU8      s      0.01..2      Debouncing time to detect an emergency event
   =======================================   ====   ==========   ============================================================================

   .. include:: SCruiseFaderDrvrIntvIndcn_CalMan_VT.irst

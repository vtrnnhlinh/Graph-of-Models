Cardan Joint Compensation
#########################

Short Description
=================

The function is used for compensation of the steering torque deviation due to the cardan joints.

.. only:: confidential

   Block Diagram
   =============

   .. image:: CardanJointCompensation_CalMan_BlockDiagram.png


Input Signals
-------------

=================================   ====   =========================================================================================================
Signal Name                         Unit   Description
=================================   ====   =========================================================================================================
wApplI_PinionAngle_xds16            °      Pinion Angle
=================================   ====   =========================================================================================================

.. only:: confidential

   =================================   ====   =========================================================================================================
   Signal Name [for internal usage]                         Unit   Description
   =================================   ====   =========================================================================================================
   mApplI_TorsionBarTorque_xds16       Nm     HW LIB: torsion bar torque.
   sApplI_SteeringAngleState_xdu8             state of steering angle / rackposition: 0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit
   vVehSpI_AbsAvgVehSpd_xdu16          km/h   Average vehicle speed. Close to the actual speed over ground as possible.
   xApplI_GearSign_xds8                       sign of the steering gear.
   fCJCI_MonSafeOk_xdb                        Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false).
   =================================   ====   =========================================================================================================


Output Signals
--------------

===================================   ====   ================================================================================================
Signal Name                           Unit   Description
===================================   ====   ================================================================================================
mCJCI_DesMotTrqOffset4Check_xds16     Nm     Desired motor torque offset of Cardan Joint Compensation to be read by Check component only
mCJCI_DesSteerTrqOffset4Check_xds16   Nm     Desired steering torque offset from Cardan Joint Compensation to be read by Check component only
===================================   ====   ================================================================================================

.. only:: confidential

   ===================================   ====   ================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ================================================================================================
   fCJC_Activate_xdb                            Indicates whether CJC shall actively calculate and request a torque.
   sCJC_FeatureState_xdu8                       Internal feature state for FunctionCoordinator.
   sCJC_FctCoCtrlState_xdu8                     Return value of the FunctionCoordinator.
   ===================================   ====   ================================================================================================


Detailed Description
--------------------
Due to the installation condition in the vehicle and the adjustability of the steering column, we need cardan joints (universal joints) 
to connect the steering wheel to the input shaft of the steering system. These cardan joints cause angular errors which manifest 
themselves as variations in the torque signal produced by the steering torque sensor. Fluctuations in this torque signal will also be
noticeable in the EPS motor torque. With this CardanJointCompensation module, these steering torque fluctuations are compensated. 

It is very important for the correct functioning of the compensation to define an installation position of the universal joints and a matching
steering angle. If this is not the case then it is possible that the cardan joint effect is amplified (worst case at 90° phase offset
between steering angle and the installation position of the Cardan joint).
Therefore the pinion angle is used for the compensation which center position is synchronized with the external steering angle sensor
(or index sensor for internal steering angle sensor) and the correction values (long-time-/ short-time-correction) aren't included.


Calibration/Application Parameters
==================================

=================================   ====   =========   =====================================================================
Parameter Name                      Unit   Range       Description
=================================   ====   =========   =====================================================================
mCJC_LimitSteerTorqueOffset_XDU16   Nm     0..3        limit of steering torque offset
wCJC_AngleOffset_XDS16              °      -180..180   phase shift
xCJC_AmplitudeFactor_XAS16                 0..1        pinion angle dependent amplitude factor
xCJC_ControlRatio_XDU16                    0..1        factor to calculate motor torque offset out of steering torque offset
xCJC_SubVehSpeedFactor_XDU16               0..1        substitute factor in case of invalid vehicle speed
xCJC_VehicleSpeedFactor_XAU16              0..1        vehicle speed dependent factor
=================================   ====   =========   =====================================================================


.. include:: CardanJointCompensation_CalMan_VT.irst

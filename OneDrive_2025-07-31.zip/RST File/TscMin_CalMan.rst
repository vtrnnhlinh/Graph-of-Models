﻿TorqueSignalConditioningMinimum
###############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component TscMin calculates a torsion bar torque and a torsion bar torque state for safety relevant HAD monitoring functions and for output on the vehicle bus if requested by the OEM.

.. only:: confidential

   Block Diagram
   =============

   .. image:: TscMin_CalMan_BlockDiagram.png


   Input Signals
   -------------

    ======================================      =========   ====================================================================================
    Signal Name                                 Unit        Description
    ======================================      =========   ====================================================================================
    sHwlWrapI_TorsionBarTorqueState_xde         -           HW LIB Wrapper: Validity state of the torsion bar torque
    mHwlWrapI_TorsionBarTorque_xds16            Nm          HW LIB Wrapper: Torsion bar torque
    mHwlWrapI_TorsionBarTorqueRed_xds16         Nm          HW LIB Wrapper: Torsion bar torque redundant
    ======================================      =========   ====================================================================================


   Output Signals
   --------------

    ======================================      =========   ====================================================================================
    Signal Name                                 Unit        Description
    ======================================      =========   ====================================================================================
    sApplI_TorsionBarTorqueMinState_xdu16       -           Torsion Bar Torque state from both channels
    mApplI_TorsionBarTorqueMin_xds16            Nm          Minimal Torsion Bar Torque from both channels, if the signals differ from each other
    ======================================      =========   ====================================================================================

.. only:: confidential

    ======================================      =========   ====================================================================================
    Signal Name                                 Unit        Description
    ======================================      =========   ====================================================================================
    tTsc_TBTViolationTime_xdu16                 ms          Time of exceeding the limit of the permitted torsionbar torque deviation
    ======================================      =========   ====================================================================================

   Detailed Description
   --------------------
   The component TscMin calculates a torsion bar torque (TscMin) and a torsion bar torque state (TscMin_State) for HAD 
   based on the two torsion bar torque signals from the HwLib. These signals are used in safety relevant HAD monitoring functions and for output on the vehicle bus if requested by the OEM.


.. only:: confidential


  Calibration/Application Parameters
  ==================================

    ==============================      =========   ========   ================================================================
    Parameter Name                      Unit        Range      Description
    ==============================      =========   ========   ================================================================
    mTsc_MaxAllowedTBTDiff_XDU16        Nm          0…50       Maximum allowed deviation between the two torque sensor signals
    tTsc_MaxAllowedTime_XDU16           ms          0…60000    Maximum allowed time of limit violation
    ==============================      =========   ========   ================================================================

.. include:: TscMin_CalMan_VT.irst

Blocked Steering Detection Check
#################################

Short Description
=================
Checks if the motor torque offset calculated by Blocked Steering Detection is with in the safety limits.

.. only:: confidential

   Block Diagram
   ==============

   .. image:: BlockedSteeringDetectionCheck_CalMan_BlockDiagram.png   

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Input Signals
   -------------
   ===================================   ====   =========================================================
   Signal Name                           Unit   Description
   ===================================   ====   =========================================================
   mBsdI_MotorTorque4Check_xds16         Nm     blocked steering detection motor torque offset for check
   sFctCoI_ArbitrationResult_xau8               is result valid for this channel?
   wApplI_RotorPosition_xds32            °      Integrated, compensated rotorposition
   ===================================   ====   =========================================================

   Output Signals
   --------------

   ===================================   ====   =====================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   =====================================================================================================
   mBsdI_MotorTorqueOffset_xds16         Nm     Blocked steering detection motor torque offset
   fBsdI_MonSafeOk_xdb                          Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   ===================================   ====   =====================================================================================================


   Detailed Description
   --------------------
   The motor torque offset from the Blocked Steering Detection is checked against the saftey limits. 
   The calculated value from Blocked Steering Detection is passed as the output if it is with in the safety limits. Other wise the output is set to 0Nm.

   Calibration/Application Parameters
   ==================================

   =================================   ====   =========   =============================================
   Parameter Name                      Unit   Range       Description
   =================================   ====   =========   =============================================
   mBsd_MaxSafetyMotorTorq_XDU16        Nm     0 .. 1      Max. allowed Motor Torque from safety side
   wBsd_MinCheckRotPosChange_XDU16      °      0 .. 50     Min change in Rotpos to shutdown BSD
   =================================   ====   =========   =============================================

.. include:: BlockedSteeringDetectionCheck_CalMan_VT.irst

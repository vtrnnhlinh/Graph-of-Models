.. only:: not confidential

   Smart Cruise Interface | Steer Torque Connector
   ###############################################

   The component SCruise Steer Torque Connector combines all the torques that are present on the steering input shaft.

.. only:: confidential

   Smart Cruise Interface | Steer Torque Connector
   ###############################################

      .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   The component SCruiseSteerTrqCnctr combines all the torques that are present on the steering input shaft.
   It adds the Nominal Steering Torque, Nominal Damping Torque, Nominal Steering Feel Torque, Nominal Active Inertia Torque and Nominal Primary Controller Torque.
   And then subtracts the external offset torque from the summation.


   Block Diagram
   =============

   .. image:: SCruiseSteerTrqCnctr_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ===============================   ====   ==============================================================================================================================================
   Signal Name                       Unit   Description
   ===============================   ====   ==============================================================================================================================================
   mSCruiseI_ExtSteerTrqOffs_xds16   Nm     Additional steering torque offset to an input nominal steering torque
   mSCruiseI_NomActvJTrq_xds16       Nm     Nominal active inertia torque of SCruise
   mSCruiseI_NomDampgTrq_xds16       Nm     Nominal damping torque
   mSCruiseI_NomPrimCtrlrTrq_xds16   Nm     Nominal Steer Torque to increase Rack Position accuracy in the primary controller
   mSCruiseI_NomSteerFeelTrq_xds16   Nm     factorized, nominal steering feel torque
   mSCruiseI_NomSteerTrq_xds16       Nm     This signal is the TorsionBarTorque which was interpolated and factorized and will be send to the SCruiseSteeringTorqueConnector for summation
   ===============================   ====   ==============================================================================================================================================


   Output Signals
   --------------

   ===================================   ====   ==============================================================
   Signal Name                           Unit   Description
   ===================================   ====   ==============================================================
   mSCruiseI_NomSteerTrqSum_xds16        Nm     This is the sum of the all single steering torques
   mSCruise_NomSteerTrqSumBfrLim_xdu16   Nm     NomSteerTrqSum before limitation based on characteristic curve
   ===================================   ====   ==============================================================


   Detailed Description
   --------------------

   SCruiseSteerTrqCnctr summates the individual torques of Damping, SteerFeel, Requested Steering Torque, ActvJ Torque and NomSteerIPart Torque. Finally it subtracts the requested External Steering Torque Offset from the sum.
   To increase the stability of the TBT controller, the sum will be saturated in a way the higher value will be compressed. A hard limitation would lead to an overshoot of the TBT Controller due to its inertia.

   .. image:: SCruiseSteerTrqCnctr_CalMan_Limitation.png

   The resulting torque will be provided as input for the TBT controller.
   Additionally a valid check of the inputs happen. In case one of the input signals becomes invalid, the output will be set to SNA.


   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ===================================   ====   =====   ==========================================================================
   Parameter Name                        Unit   Range   Description
   ===================================   ====   =====   ==========================================================================
   mSCruise_MaxNomSteerTorqueSum_XAU16   Nm     0..12   Dynamically limitation (buckling) of NomSteerTorqueSum dependent on itself
   ===================================   ====   =====   ==========================================================================

   .. include:: SCruiseSteerTrqCnctr_CalMan_VT.irst

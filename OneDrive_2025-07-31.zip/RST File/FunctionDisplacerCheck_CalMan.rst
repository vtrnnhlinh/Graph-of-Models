Function Displacer Check
#########################

Short Description
=================
This component receives motor torque offset from Function Displacer component, and checks if it is with in the safe limits.


.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Input Signals
   -------------

   =====================================     ====   ===========================================
   Signal Name                               Unit   Description
   =====================================     ====   ===========================================
   sApplI_EcuState_xdu8                             Ecu safe state
   sFctCoI_ArbitrationResult_xau8    				is arbitration valid for this channel?
   mFuncDisplI_MotorTorque4Check_xds16        Nm    Vibration motor torque in EcuState FailOp
   =====================================     ====   ===========================================

   Output Signals
   --------------

   ===================================   ====   ===============================
   Signal Name                           Unit   Description
   ===================================   ====   ===============================
   mFuncDisplI_MotorTorqueOffset_xds16   Nm     The final motor torque offset 
   fFuncDisplI_MonSafeOk_xdb                    Indicates whether MonitorSafe checks report OK (1) or if they have detected a problem (0)
   ===================================   ====   ===============================
   
   ===================================   ====   ===============================
   Signal Name [Internal]                Unit   Description
   ===================================   ====   ===============================
   mFuncDispl_MtrTrqSaturated_xds16      Nm     Saturated motor torque for vibration at steering wheel in EcuState FailOp
   sFuncDispl_PreStoreData_xdu16                Indicates whether  MonitorSafe checks report OK (0) or if torque exceeds limit (1) or if invalid arbitration was detected (2) of if both the errors are present (3).
   ===================================   ====   ===============================

   Detailed Description
   --------------------
   This component performs the safety limitation for the motor torque offset from Function Displacer.
   It deactivates the function until the end of the cycle in case the safety limitation or the arbitration check fails.
   

   Calibration/Application Parameters
   ==================================

   =======================================   =====   ======   =================================
   Parameter Name                            Unit    Range    Description
   =======================================   =====   ======   =================================
   mFuncDispl_MaxSafetyMotorTorq_XDU16       Nm      0..0.5   The maximum allowed motor torque
   =======================================   =====   ======   =================================


.. include:: FunctionDisplacerCheck_CalMan_VT.irst

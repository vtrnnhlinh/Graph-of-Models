On Center Connection
####################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
The component OnCenterConnection (OCC) provides a motor torque that represents an artificial friction for better steering feel when the steering wheel is moved out of a stationary position.

Block Diagram
=============

.. only:: confidential

   .. image:: OnCenterConnection_CalMan_BlockDiagram.png


Input Signals
-------------

================================   =====   ===========================
Signal Name                        Unit    Description
================================   =====   ===========================
vApplI_AbsVehicleSpeedFilt_xds16   km/h    Abs.vehicle speed:processed
nApplI_RotorSpeed_xds16            1/min   Rotor speed
mApplI_LimitedMotorTorque_xds16    Nm      Limited motor torque
xRackForceI_RatioD2C_xdu16         -       Ratio of the merges force (1=100% Dynamic, 0=100% Comfort)
================================   =====   ===========================


Output Signals
--------------

=================================   ====   =====================
Signal Name                         Unit   Description
=================================   ====   =====================
mOCCI_MotorTorque_xds16             Nm     motor torque of OnCenterConnection
=================================   ====   =====================

.. only:: confidential

   =================================   ====   ==================================
   Signal Name                         Unit   Description
   =================================   ====   ==================================
   kOCC_OccFriction_xds16              N      Occ offset force
   kOCC_FilteredOccFriction_xds16      N      Occ offset force filtered (but higher resolution)
   fOCC_Activated_xdu8                        OCC activation conditions status
   =================================   ====   ==================================


Detailed Description
--------------------

OccFriction motor torque caluclated based on the the input signals are VehicleSpeed, RotorSpeed and LimitedMotorTorque.OCC Base Friction filtered,converts it to a motor torque
and saturates it to a maximum of +/- mOCC_MaxAllowedTorque Nm.The saturated motor torque is set via mOCCI_MotorTorque_xds16, only if all of the OCC input signals are valid. If one of
the input signal is invalid, mOCCI_MotorTorque_xds16 is set to 0 Nm.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

======================================   =====   ======   ===========================================================
Parameter Name                           Unit    Range    Description
======================================   =====   ======   ===========================================================
xOCC_OccScalBaseFric_XAU16                       0..1     Scaling factor for base friction depending on vehicle speed
kOCC_OccBaseFriction_XDU16               N       0..150   Occ Base friction
nOCC_OccDeadZone_XDU16                   1/min   0..100   Occ Rotor Speed DeadZone
xOCC_OccFilterFactor_XDU16                       0..1     Occ Filter Factor
fOCC_Enable_XDU8                                 0 / 1    Activate OnCenterConnection
fOCC_RFfactEnable_XDU8                           0 / 1    Activate Fading of OCC based on xRackForceI_RatioD2C_xdu16. 0 = OCC always on, 1 = Fade OCC based on RFMC/D
mOCC_MaxAllowedTorque_XDU16              Nm      0..0.5   Occ motor torque saturation
======================================   =====   ======   ===========================================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   ======================================   =====   ========   ==========================================================
   Parameter Name                           Unit    Range      Description
   ======================================   =====   ========   ==========================================================
   xsyNoEffDepEngTorqueToRackForce_XDU16    N/Nm    1..5000    Factor from Engine Torque to Rack Force without efficiency
   xsyRackForceToEngTorque_XDU16            Nm/N    0..0.003   Factor from Rack Force to Engine Torque
   ======================================   =====   ========   ==========================================================



.. include:: OnCenterConnection_CalMan_VT.irst

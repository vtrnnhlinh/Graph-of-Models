FltManStateMachineDualUcSymmSRA
###############################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

This component implements the CentralizedFaultManagement state machine for the variant SCU4-D6 SRA.

.. only:: confidential

   Block Diagram
   =============

   .. image:: FltManStateMachineDualUcSymmSRA_CalMan_BlockDiagram.png

Output Signals
--------------

============================================   ====   =============================================================
Signal Name                                    Unit   Description
============================================   ====   =============================================================
sFltManI_EcuChannelStateReq_xdu8                      Outputstage control request to Hardware Library
sFltManI_RequestEcuState_xdu8                         ECU state request to ApplicationStateMachine
sFltManI_EcuFaultMode_xdu8                            Overall CFM fault mode
sFltManI_LocalModeTx_xdu8                             CFM fault mode transmitted to remote controller
sFltManI_TorqueDistributionStatus_xdu8                Torque distribution control request to Hardware Library
sFltManI_EcuChannelRole_xdu8                          Indicates whether current channel is Master
============================================   ====   =============================================================

Detailed Description
--------------------
This component updates component specific internal variables with corresponding provided inputs, updates the functionality specific local fault management
state, determines the disable request in the corresponding state of the functionality specific state machine, determines the torque distribution status and the channel's role
in the corresponding state of the functionality specific state machine, executes the corresponding state handler, and provides the functionality
specific public interfaces.


.. include:: FltManStateMachineDualUcSymmSRA_CalMan_VT.irst

Rotor Speed
###########

Short Description
=================

Map the rotor speed from Hwlib to Application Interface and also calculate rotor acceleration.

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RotorSpeed_CalMan_BlockDiagram.png

   Input Signals
   -------------

   ================================   ======   ======================
   Signal Name                        Unit     Description
   ================================   ======   ======================
   nrsI_IntRotorSpeed_xds16           1/min    rotor speed HWLib
   ================================   ======   ======================

   Output Signals
   --------------

   =================================   =========   =================================================
   Signal Name                         Unit        Description
   =================================   =========   =================================================
   nApplI_Rotor Speed_xds16            1/min       Unfiltered rotor speed
   nApplI_RotorSpeedFilt_xds16         1/min       Filtered rotor speed
   nApplI_AbsRotorSpeedFilt_xdu16      1/min       Absolute filtered rotor speed
   aApplI_RotAcceleration_xds16        1/min/ms    Rotor acceleration
   aApplI_RotAccelerationFilt_xds16    1/min/ms    Filtered rotor acceleration
   =================================   =========   =================================================


   Detailed Description
   --------------------

   The rotor speed component maps the rotor speed which is received from the HWLib and calculates the rotor acceleration.
   The HWLib calculates the rotor speed as an deviation of the rotor position in a faster task cycle for a better precision. 
   The rotor speed component in the application layer doesn’t have the possibility to do this.
   The signals rotor speed, filtered rotor speed, absolute filtered rotor speed, rotor acceleration, filtered rotor acceleration are safety relevant and are redundantly stored.

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ===========================================  ====   ==========   ==========================================================
   Parameter Name                               Unit   Range        Description
   ===========================================  ====   ==========   ==========================================================
   xRotSp_RotSpeedFilterFact_XDU16                     0.001..0.5   Filter factor of the filtered rotor speed 
   xRotSp_RotSpeedFilterFactAcceleration_XDU16         0.001..0.5   Filter factor of the filtered rotor speed for acceleration 
   xRotSp_RotAccelerationLowFilterFact_XDU16           0.001..1.0   Low filter factor of unfiltered rotor acceleration
   xRotSp_RotAccelerationFilterFact_XDU16              0.001..0.5   Filter factor of the filtered rotor acceleration
   ===========================================  ====   ==========   ==========================================================

.. include:: RotorSpeed_CalMan_VT.irst

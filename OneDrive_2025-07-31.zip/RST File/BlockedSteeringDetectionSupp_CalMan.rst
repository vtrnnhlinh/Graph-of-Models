Blocked Steering Detection Supp
###############################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!
   
Short Description
=================
The Bsd Supp component contains the entire temperature calculation and provides the validity signal 
to the BSD main component

.. only:: confidential

   Block Diagram
   ==============

   .. image:: BlockedSteeringDetectionSupp_CalMan_BlockDiagram.png
   
Input Signals
-------------
===================================   ====   =========================================================
Signal Name                           Unit   Description
===================================   ====   =========================================================
cHwlWrapI_OutstageTempFilt             °C	 blocked steering detection Tempreture for check
xApplI_TotalMotTorLim              			 It is to check if  System is already in full assist
===================================   ====   =========================================================

Output Signals
--------------

===================================   ====   =====================================================================================================
Signal Name                           Unit   Description
===================================   ====   =====================================================================================================
fBsd_ActivationFlag_xdb    					   which gives the information whether the temperature is valid to activate the BSD functionality                        
===================================   ====   =====================================================================================================


Detailed Description
--------------------
The Activation Flag from the Blocked Steering Detection Supp which gives the information whether the temperature is valid to activate the BSD functionality. 
   

Calibration/Application Parameters
==================================

=================================   ====   ==========   =============================================
Parameter Name                      Unit   Range        Description
=================================   ====   ==========   =============================================
cBsd_TempratureLimit_XDU8            °C    -70 .. 140   Max. allowed Tempreture from safety side
=================================   ====   ==========   =============================================

.. include:: BlockedSteeringDetectionSupp_CalMan_VT.irst

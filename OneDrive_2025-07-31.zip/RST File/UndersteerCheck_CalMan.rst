Understeer Check
#################

Short Description
=================

The component UndersteerCheck is responsible to fulfill the safety requirements, which are allocated to the function Understeer.
The requested steering torque offset is less or equal than an applicable safety limit and the arbitration result for
for the Understeer channel is checked.
In case of an error, the steeringtorque- and motortorque offsets will be set to zero.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============
   
   .. image:: UnderSteerCheck_CalMan_BlockDiagram.png

   Input Signals
   -------------

   =======================================   ====   ======================
   Signal Name                               Unit   Description
   =======================================   ====   ======================
   mUnStI_MotorTorqueOffset4Check_xds16      Nm     motor torque offset of Understeer
   mUnStI_SteeringTorqueOffset4Check_xds16   Nm     steering torque offset of Understeer
   sFctCoI_ArbitrationResult_xau8                   state of arbitration for this channel:0=Arbitration Not OK;1=Arbitration OK, channel active;2=Arbitration OK, channel passive
   =======================================   ====   ======================

   Output Signals
   --------------

   =================================   ====   =====================
   Signal Name                         Unit   Description
   =================================   ====   =====================
   mUnStI_MotorTorqueOffset_xds16      Nm     motor torque offset Understeer
   mUnStI_SteeringTorqueOffset_xds16   Nm     steering torque offset Understeer
   fUnStI_MonSafeOk_xdb                       indicates whether the MonitorSafe() checks reports OK, or detected an error (false)
   =================================   ====   =====================

   ========================================   ====   =====================
   Signal Name  [Internal]                    Unit   Description
   ========================================   ====   =====================
   mUnSt_SteeringTorqueOffsetMakeSafe_xds16   Nm     steering torque offset; sender MakeSafe() function
   ========================================   ====   =====================
   
   Detailed Description
   --------------------

   The function is devided into 3 parts:

    * UnStI_MakeSafe(): safety limitation of steering torque offset.
    * UnStI_MonitorSafe(): monitoring the safety limitation and evaluation of the ArbitrationResult (0 - Error, 1 - Arb ok & Channel active, 2 - Arb ok & Channel passive) of the channel Understeer. Call of EvtHstI_HlSetEventEntry() and write the DiagData block.
    * UnStI_DisableSwitch(): switch off the steeringtorque- and motortorque offset, if the monitor function has detected a problem.


   Calibration/Application Parameters
   ==================================
   ===========================================   =====   ========   =============================================
   Parameter Name                                Unit    Range      Description
   ===========================================   =====   ========   =============================================
   mUnSt_SafetyLimitSteeringTorqueOffset_XDU16   Nm      0...3      safety limit of steering torque offset
   ===========================================   =====   ========   =============================================

.. include:: UndersteerCheck_CalMan_VT.irst

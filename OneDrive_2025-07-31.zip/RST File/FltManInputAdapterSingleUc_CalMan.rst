FltManInputAdapterSingleUc
##########################

.. only:: confidential

    Short Description
    =================

    The FltManInputAdapter component maps the following HardwareLib signals into an event list based on the actual status of the signals.


   Block Diagram
   =============

   .. image:: FltManInputAdapterSingleUc_CalMan_BlockDiagram.png


    Input Signals
    -------------


   ===================================   =====   =========================================================================================================
   Signal Name [for internal usage]                         Unit   Description
   ===================================   =====   =========================================================================================================
   sFltManI_MonSafeOk_xdb                        Indicates whether the MonitorSafe checks report OK (1) or if they have detected a problem (0).
   sHwlWrapI_ActuatorState_xde                   HwLib Actuator State
   sHwlWrapI_ChipsetSafetyFault_xde              HwLib Chipset SafetyFault State
   sHwlWrapI_RotorPositionState_xde              HwLib Rotor Position State
   sHwlWrapI_BoardTempState_xde                  HwLib Board Temp State
   sHwlWrapI_TorsionBarTorqueState_xde           HwLib TorsionBar Torque State
   sHwlWrapI_SystemVoltageState_xde              HwLib System Voltage State
   nApplI_RotorSpeedFilt_xds16           1/min   Filtered Rotor Speed.This interface describes the filtered rotor speed.
   vVehSpI_AbsAvgVehSpd_xdu16            km/h    Average vehicle speed. Goal: be as close to the actual speed over ground as possible        
   wApplI_SteeringAngle_xds16            °       corrected steering angle                  
   sApplI_SteeringAngleState_xdu8                steering angle status(0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit)
   sFltManI_FailOpFinished_xdu8                  Flag triggering request into disabled mode
   ===================================   =====   =========================================================================================================


    Output Signals
    --------------


   ===================================   ====   ================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ================================================================================================
   sFltManI_Events_xau8                         An array of error events. 0-No Error, 1- Error
   sFltMan_ApplErrMoniStatus                    the functionality specific application error levels status
   ===================================   ====   ================================================================================================

    Detailed Description
    --------------------
    The FltManInputAdapter component maps HardwareLib signals such as ActuatorState, ChipsetSafetyFault, RotorPositionState, BoardTempState, TorsionBarTorqueState, 
    SystemVoltageState and Sw Error Levels into an event list based on the actual status of the signals.


.. include:: FltManInputAdapterSingleUc_CalMan_VT.irst

Fader Conn Mot Trq Sum
######################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The FaderConnector will sum the torque from the Fader component and the torques
which are bypassing the SCruiseFading functioanlity.

.. only:: confidential

   Block Diagram
   =============
   
   .. image:: FaderConnMotTrqSum_CalMan_BlockDiagram.png


Input Signals
-------------

=============================   ====   ===============================================================================
Signal Name                     Unit   Description
=============================   ====   ===============================================================================
mSCruiseFadrI_MotTrq_xds16      Nm     Motor Torque coming from the SCruiseFading functionality
mTrqSumI_TrqSumAfterSCI_xds16   Nm     Summation of all input motor torques of subconnector after SmartCruiseInterface
=============================   ====   ===============================================================================


Output Signals
--------------

=================================   ====   ======================
Signal Name                         Unit   Description
=================================   ====   ======================
mFaderConnMotTrqSumI_MotTrq_xds16   Nm     Fader connector torque
=================================   ====   ======================


Detailed Description
--------------------

The function will be the final summation point in the torque path. This will add the torque from SCI fader and Bypass torque from SCI fader.
The final summed torque is saturated the max and min of mFaderConnMotTrqSumI_MotTrq_xds16.

Calibration/Application Parameters
==================================

n.a.


.. include:: FaderConnMotTrqSum_CalMan_VT.irst

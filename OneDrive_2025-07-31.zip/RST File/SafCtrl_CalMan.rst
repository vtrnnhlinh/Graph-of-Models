Safety Controller
##################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The functionality "Loss Of Assist Prevention" is an additional safety mechanism after the functionality Motor Torque Limiter.
Since the MTL prevents violations of the safety goals "Unwanted Actuator Function" and "Blocked Steering", but might violate the safety goal "Sudden Loss of Assist" due to its design, this additional functionality is supposed to detect such a loss and prevent it before a hazardous situation can occur.
The detection is based on the ratio between Torsion Bar Torque and provided Motor Torque. A loss of assist is represented by a low Motor Torque and a high TBT, since the driver has to compensate the loss of steering assistance by manually providing the necessary steering torque.
The functionality prevents this by detecting such a case and by providing the minimum amount of steering assistance needed to control the vehicle.


Block Diagram
=============

.. only:: confidential

   .. image:: SafCtrl_CalMan_BlockDiagram.png

No block diagram for external usage.


Input Signals
-------------

======================================  ====   ======================================================================
Signal Name                             Unit   Description
======================================  ====   ======================================================================
mApplI_TorsionBarTorque_xds16            Nm     HW LIB: torsion bar torque
mMotTorLimI_ValidatedMotorTorque_xds16   Nm     limited motor torque by motortorquelimiter
======================================  ====   ======================================================================

.. only:: confidential

   ================================   ========   ===========================================================================
   Signal Name                        Unit       Description
   ================================   ========   ===========================================================================
   aApplI_RotAccelerationFilt_xds16   1/min/ms   filtered rotor accelereation
   sSsmI_DeactivateAssist_xdu8                   Set trigger to Deactivate the Assist based on the error present in errorLvl
   xApplI_GearSign_xds8                          sign of the steering gear
   mApplI_HWLMaxUsableTorque_xdf32     Nm        MaxUsableTorque
   ================================   ========   ===========================================================================


Output Signals
--------------

=============================   ====   ====================================================================================
Signal Name                     Unit   Description
=============================   ====   ====================================================================================
mSafCtrlI_MotTrq4Check_xds16    Nm     calculated controller offset which needs to be checked
mSafCtrl_TbtDeviation_xds16     Nm     TBT deviation as input for controller
=============================   ====   ====================================================================================

.. only:: confidential

   =============================   ====   ====================================================================================
   Signal Name                     Unit   Description
   =============================   ====   ====================================================================================
   mSafCtrlI_MotTrqFromMTL_xds16   Nm     limited motor torque by motortorquelimiter, which is possibly deactivated is SafCtrl
   mSafCtrl_UpperLimit_xds16       Nm     Safety controller upper limit
   mSafCtrl_LowerLimit_xds16       Nm     Safety controller lower limit
   mSafCtrl_PPart_xds16            Nm     Safety controller PPart torque
   mSafCtrl_IPart_xds32                   Safety controller IPart torque
   mSafCtrl_DPart_xds16            Nm     Safety controller DPart torque
   mSafCtrl_InertiaTorque_xds16    Nm     Safety controller inertia torque
   =============================   ====   ====================================================================================


Detailed Description
--------------------

.. only:: confidential

   The input quantities for the controller are the torsion bar torque (signed), filtered rotor acceleration,
   summed motor torque of TorqueSum1 and the gear prefix for the left-right-steer (xApplI_GearSign_xds8).
   The controller will be enabled if all input signals are valid.

   After the controller is active, it checks if the motor torque is too high and the torsion bar torque (mApplI_TorsionBarTorque_xds16) is above the configurable desired TBT limit (mSafCtrl_DesiredTorsionBarTor_XDU16).
   If this condition is true, the SafetyController will provide assistance torque (mSafCtrlI_MotTrq4Check_xds16).

   *Note1: If motor torque is inverse to torsion bar torque and torsion bar torque is above the desired TBT level, no further reaction by the SafetyController. But this case should be impossible due to the configuration of the MTL.*

   *Note2: The Input signal torsion bar torque is saturated to the value of mSafCtrl_MaxTorsionBarTor_XDU16.*

   The provided assistance torque (mSafCtrlI_MotTrq4Check_xds16) is calculated using a PID controller and a added inertia compensation part based on the characteristic curve mSafCtrl_MaxSafCtrlMotorTorque_XAU16.

   The proportional (P) part is calculated by multiplying xSafCtrl_PPart_XDU16 with the "TorsionBarTorqueDiff" (difference between the current value of mApplI_TorsionBarTorque_xds16 and the desired TBT limit mSafCtrl_DesiredTorsionBarTor_XDU16).
   The integral (I) part is calculated by multiplying xSafCtrl_IPart_XDU16 with the "TorsionBarTorqueDiff" and adding the integral part of the last call cycle. This integral part
   limitation can be enabled or disabled w.r.t to UsableMotorTorque based on the calibration switch.
   The derivative (D) part shall be calculated by multiplying xSafCtrl_DPart_XDU16 with the difference between the "TorsionBarTorqueDiff" of this call cycle and the "TorsionBarTorqueDiff" of the last call cycle.
   If the integral part is 0, the derivative part is set to 0 as well.
   The inertia modification part is calculated by multiplying xSafCtrl_InertiaFactor_XDS16 with the filtered rotor acceleration (aApplI_RotAcceleration_xds16). Be aware that this is not a compensation. The inertia torque is used as a measurement of stabilizaiton.

   In case the controller was once active and the TBT now falls below the threshold desired TBT limit (mSafCtrl_DesiredTorsionBarTor_XDU16) the calculated motor torque does not fall to 0NM but instead it ramps down due to the I-Part of the controller.
   This behavior is intentioned to prevent oscillation.

No detailed description for external usage.


Calibration/Application Parameters
==================================

.. only:: confidential

   Provide a table of internal calibration parameters.

   ====================================   =====   =====   ========================================================================================================================================================================================================
   Parameter Name                         Unit    Range   Description
   ====================================   =====   =====   ========================================================================================================================================================================================================
   mSafCtrl_MaxSafCtrlMotorTorque_XAU16   Nm      0..25   Max. SafetyController motor torque dependent on AbsTorsionBarTorque. The first two points MUST be zero due to handoff detection! The max. supporting torque MUST be below 3Nm! The curve MUST be rising!
   mSafCtrl_DesiredTorsionBarTor_XDU16    Nm      0..25   desired TorsionBarTorque
   mSafCtrl_MaxTorsionBarTor_XDU16        Nm      0..25   Max. TorsionBarTorque
   xSafCtrl_DPart_XDU16                           0..30   D Part
   xSafCtrl_IPart_XDU16                           0..1    I Part
   xSafCtrl_InertiaFactor_XDS16                   -1..1   Inertia Factor (do not considere the GearSign in this parameter)
   xSafCtrl_PPart_XDU16                           0..10   P Part
   fSafCtrl_EnableLimitation_XDU8                 0..1    Enabling the Limitation with respect to MaxUsableMotorTorque
   ====================================   =====   =====   ========================================================================================================================================================================================================

No parameters for external usage.

.. only:: confidential

   .. include:: SafCtrl_CalMan_VT.irst

Inertia Modification
####################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

InertiaModification calculates a virtual inertia torque for the rotor.
Main purpose is the stabilization of the closed loop system.



Block Diagram
=============

.. only:: confidential

   .. image:: InertiaModification_CalMan_BlockDiagram.png

Input Signals
-------------

==============================   ========   =====================================================================================
Signal Name                      Unit       Description
==============================   ========   =====================================================================================
aApplI_RotAcceleration_xds16     1/min/ms   Rotor acceleration
zcrChatterPeriodsCount_xdu8                 Counter of the chatter oscillations
vVehSpI_AbsAvgVehSpd_xdu16       km/h       Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
==============================   ========   =====================================================================================


Output Signals
--------------

==============================   ========   ====================================================================
Signal Name                      Unit       Description
==============================   ========   ====================================================================
mInCoI_InertiaComp_xds16         Nm         Motor torque offset from inertia compensation and rotor damping
mInCo_InertiaCompFilt_xdu16      Nm         Measurement variable: Bandpass-filtered Inertia compensation torque
mInCo_InertiaCompRaw_xdu16       Nm         Measurement variable: Unfiltered Inertia compensation torque
vInCo_AbsAvgVehSpd_xdu16         km/h       Measurement variable: Validated input average vehicle speed
==============================   ========   ====================================================================

Detailed Description
====================

Inertia Modification calculates a motor torque to compensate system related inertia of the steering system as well as to increase stability and improve steering feel.
This compensation torque is tuned with a factor (xInCo_RotAccFactor_XAS16) dependent on the vehicle speed. 
In case of Chattering, where zcrChatterPeriodsCount_xdu8 exceeds the tunable limit zInCo_ChatterCountLimitInertia_XDU8, another factor xInCo_ChatterRotAccFactor_XAS16 is used
to calculate an individual compensation torque in the chatter case. 

**Rotor Damping:**
To compensate spikes in the compensation torque due to sudden changes in the rotor acceleration and further increase stability, a second order Bandpass-filter (xInCo_Bandpass_S1_XDF32, xInCo_Bandpass_A2_XDF32, xInCo_Bandpass_A3_XDF32_XDF32)
is used to limit the generated damping torque to a signal within a defined frequency range. The input signal in the Bandpass-filter (Compensation Torque) is individually calculated and scaled with
xInCo_RotAccFactorFilt_XAS16 and xInCo_ChatterRotAccFactorFilt_XAS16 respectively to modify the influence of the filter on the output torque. These parameters can also be used to disable Rotor Damping.

The output of the InertiaModification mInCoI_InertiaComp_xds16 is calculated as the sum of the raw and filtered compensation torque. To ensure safety, it is limited to mInCo_InertiaCompLimit_XDS16.


Calibration/Application Parameters
==================================

=======================================  ========   ====================   ============================================================================
Parameter Name                           Unit       Range                  Description
=======================================  ========   ====================   ============================================================================
xInCo_RotAccFactor_XAS16                 g*m^2      -2..1.99993896484375   inertia torque factor dependant on vehicle speed
xInCo_ChatterRotAccFactor_XAS16          g*m^2      -2..1.99993896484375   inertia torque factor dependant on vehicle speed in case of chatter detected
aInCo_RotAccDeadZone_XDU16               1/min/ms   0..500                 dead zone for rotor acceleration
mInCo_InertiaCompLimit_XDS16             Nm         0..1                   max allowed inertia compensation torque
xInCo_InvalidInputSigRotAccFactor_XDS16  g*m^2      -2..1.99993896484375   inertia torque factor in case of invalid input signals
zInCo_ChatterCountLimitInertia_XDU8                 0..255                 switch inertia torque factor dependent on chatter cycles
xInCo_RotAccFactorFilt_XAS16             g*m^2      -2..1.99993896484375   inertia torque factor for BP-filter dependant on vehicle speed
xInCo_ChatterRotAccFactorFilt_XAS16      g*m^2      -2..1.99993896484375   inertia torque factor for BP-filter dependant on vehicle speed in case of chatter detected
aInCo_RotAccDeadZoneFilt_XDU16           1/min/ms   0..500                 dead zone for rotor acceleration for BP-filter
xInCo_Bandpass_S1_XDF32                             -10..10                coefficient S1 of bandpass filter of rotor speed
xInCo_Bandpass_A2_XDF32                             -10..10                coefficient A2 of bandpass filter of rotor speed
xInCo_Bandpass_A3_XDF32                             -10..10                coefficient A3 of bandpass filter of rotor speed
zInCo_ChatterCountLimitInertiaFilt_XDU8             0..255                 switch inertia torque factor dependent on chatter cycles for BP-filter
=======================================  ========   ====================   ============================================================================

.. include:: InertiaModification_CalMan_VT.irst


Some default values for Bandpass filter tuning
==============================================

===================  ==============  ========================  ========================  ========================
mid frequency [Hz]   bandwidth [Hz]  xInCo_Bandpass_S1_XDF32   xInCo_Bandpass_A2_XDF32   xInCo_Bandpass_A3_XDF32
===================  ==============  ========================  ========================  ========================
22.0                 4.0             0.012352144176909         -1.956513895431489        0.975295711646182
25                   4               0.012335270876563         -1.951109210518216        0.975329458246873
28                   4               0.012316298754442         -1.945032252240999        0.975367402491115
33                   4               0.012280068554815         -1.933427361121976        0.975439862890370
35                   4               0.012263982072419         -1.928274701776637        0.975472035855161
22.0                 6.0             0.018414487065773         -1.944504495491012        0.963171025868453
25                   6               0.018389486665197         -1.939149244915161        0.963221026669607
28                   6               0.018361376035267         -1.933127762712959        0.963277247929466
33                   6               0.018307692969848         -1.921628496286335        0.963384614060305
35                   6               0.018283856663461         -1.916522602358283        0.963432286673078
22.0                 8.0             0.024402860700121         -1.932641627407455        0.951194278599758
25                   8               0.024369932040168         -1.927335011086579        0.951260135919665
28                   8               0.024332906166969         -1.921368108598245        0.951334187666063
33                   8               0.024262195683348         -1.909972764634436        0.951475608633303
35                   8               0.024230798071687         -1.904912884313891        0.951538403856627
===================  ==============  ========================  ========================  ========================

Sketch of bandpass
------------------

.. only:: confidential

   .. image:: InertiaModification_CalMan_BP_magnitude.png
   .. image:: InertiaModification_CalMan_BP_structure.png
	














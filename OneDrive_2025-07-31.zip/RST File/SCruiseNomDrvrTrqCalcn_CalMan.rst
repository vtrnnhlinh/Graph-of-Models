Smart Cruise Interface | Nominal Driver Torque Calculation
###########################################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component provides the nominal driver torque.

Block Diagram
=============

.. only:: confidential

   .. image:: SCruiseNomDrvrTrqCalcn_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SCruiseNomDrvrTrqCalcn_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

==============================   ======   ===================================================================================================================
Signal Name                      Unit     Description
==============================   ======   ===================================================================================================================
lSCruiseI_NomRackPosn_xds32      mm       Requested rack position for SCruise controller (after input limitation (position+gradient))
lSCruiseI_RackPosn_xds16         mm       SCruise current Rackposition
vSCruiseI_AbsAvgVehSpd_xdu16     km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
xSCruiseI_HandsOnFadrFac_xdu16   --       Fading factor HandsOn (1) to HandsFree (0)
==============================   ======   ===================================================================================================================

.. only:: confidential

   ==============================   ======   ===================================================================================================================
   Signal Name                      Unit     Description
   ==============================   ======   ===================================================================================================================
   xSCruiseI_StfnFac_xdu16          --       signal processed stiffness factor for SCruise
   ==============================   ======   ===================================================================================================================

Output Signals
--------------

=============================   ====   ==============================================================================================================================================
Signal Name                     Unit   Description
=============================   ====   ==============================================================================================================================================
lSCruiseI_RackPosnDelta_xds16   mm     This signal shows the rack position deviation between filtered rack position and nominal rack position
mSCruiseI_NomSteerTrq_xds16     Nm     This signal is the TorsionBarTorque which was interpolated and factorized and will be send to the SCruiseSteeringTorqueConnector for summation
=============================   ====   ==============================================================================================================================================

.. only:: confidential

   Detailed Description
   --------------------

   With the given calibration tables the nominal driver torque can be specified depending on vehicle speed and rack position delta. There are independent calibration
   curves available for HandsOn and HandsFree mode. According to the currently present SCruise mode the corresponding torque is provided as the
   nominal driver torque (and also faded from one mode into the other). The torque output is linearly scaled by the stiffness factor.


Calibration/Application Parameters
==================================

===================================   ====   =======   =========================================================================================
Parameter Name                        Unit   Range     Description
===================================   ====   =======   =========================================================================================
mSCruise_SteerTorqueHandsOn_XAU16     Nm     0..25     Nominal steer torque in HandOn mode depending on vehicle speed and rack position delta
mSCruise_SteerTorqueHandsFree_XAU16   Nm     0..25     Nominal steer torque in HandFree mode depending on vehicle speed and rack position delta
===================================   ====   =======   =========================================================================================


.. only:: confidential

   ===================================   ====   =======   =========================================================================================
   Parameter Name                        Unit   Range     Description
   ===================================   ====   =======   =========================================================================================
   mSCruise_NomSteerTrqLim_XDU16         Nm     0..25     Limitation of NomSteerTrq
   ===================================   ====   =======   =========================================================================================

   .. include:: SCruiseNomDrvrTrqCalcn_CalMan_VT.irst

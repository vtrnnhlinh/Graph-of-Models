VehSp_Avg
#########

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

Calculate the average vehicle speed which is supposed to be close to
the actual speed over ground but does not fulfill any safety requirements.


Block Diagram
=============

.. image:: VehSp_Avg_CalMan_BlockDiagram.png


Input Signals
-------------

==============================   ====   ====================================================================
Signal Name                      Unit   Description
==============================   ====   ====================================================================
sApplI_SteeringAngleState_xdu8          steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit)
vEpsInI_VehicleSpeedRaw_xds16    km/h   Vehicle Speed Raw Value
vEpsInI_WheelSpeedFLDiv_xds16    km/h   Diverse Wheel Speed Front Left
vEpsInI_WheelSpeedFRDiv_xds16    km/h   Diverse Wheel Speed Front Right
vEpsInI_WheelSpeedRLDiv_xds16    km/h   Diverse Wheel Speed Rear Left
vEpsInI_WheelSpeedRRDiv_xds16    km/h   Diverse Wheel Speed Rear Right
vazReqVehSpeed_xdu8                     Values in residuum
wApplI_SteeringAngle_xds16        °     corrected steering angle
==============================   ====   ====================================================================


Output Signals
--------------

==========================   ====   =====================================================================================
Signal Name                  Unit   Description
==========================   ====   =====================================================================================
vVehSpI_AbsAvgVehSpd_xdu16   km/h   Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
==========================   ====   =====================================================================================


Detailed Description
--------------------

*Calc Speeds* uses two algorithms

  * Average value of the wheel speeds.
  * Select the input speed (including the raw speed) which is closest to the last calculated speed.
  
The former is used during normal driving conditions while the latter is used in extreme driving
situations. Extreme driving is detected when the difference between the smallest and largest wheel
speeds exceeds the threshold calculated in *Calc Threshold for Normal Driving*. The threshold is
based on a simple vehicle model which considers the speed and the steering angle. The formula is as
follows::

  thresh = min(v * steeringAngle * xVehSp_Factor4MaxSpeedDiff4NormalDriving_XDU8 + vVehSp_TolMaxSpeedDiff4NormalDriving_XDU8, vVehSp_MaxSpeedDiff4NormalDriving_XDU16)

The factor incorporates the geometric influences like wheel base and track. The formula also allows
to specify a tolerance (since there will always be slight differences in the individual wheel
speeds) and to limit the threshold to a maximum value.

If the steering angle is unavailable, this simplified formula is used::

  thresh = 0.5 * vVehSp_MaxSpeedDiff4NormalDriving_XDU16

The averaging algorithm can be restricted to allow its use only if a sufficient number of wheel
speeds is valid using the parameter zVehSp_MinValidWheelSpeeds4Avg_XDU8. For example it can make
sense to require at least 3 valid wheel speeds so that the speed difference compared to the
threshold is calculated using at least one wheel speed from each side.

Note that the overall algorithm is setup for high availablity. That is, a speed will be output if at
least one of the input speeds is available.

The output value of *Calc Speed* is rate-limited using the calibratable gradient limits.

If all input speeds are invalid and production mode is set, the output speed is set to the input vazReqVehSpeed.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=============================================   ====   =========   ================================================================================================================================================================
Parameter Name                                  Unit   Range       Description
=============================================   ====   =========   ================================================================================================================================================================
aVehSp_MaxNegGradientVAvg_XAU16                 km/h   0..3.9844   Max negative gradient of the vehicle speed v_Avg [km/h/10ms]
aVehSp_MaxPosGradientVAvg_XAU16                 km/h   0..3.9844   Max positive gradient of the vehicle speed v_Avg [km/h/10ms]
vVehSp_MaxSpeedDiff4NormalDriving_XDU16         km/h   0..500      max diff between smallest and biggest wheel speed to detect a normal driving situation and to calculate the vehicle speed out of the average of all wheel speeds
vVehSp_TolMaxSpeedDiff4NormalDriving_XDU8       km/h   0..3.9844   Additional tolerance offset on calculated max difference between min/max wheel speeds
xVehSp_Factor4MaxSpeedDiff4NormalDriving_XDU8          0..0.0077   factor for calculation of max diff between smallest and biggest wheel speed to detect a normal driving situation (MaxDiff = Factor * VehSp * SteerAngle)
zVehSp_MinValidWheelSpeeds4Avg_XDU8                    1..4        Minimum number of valid wheel speed signals required to provide the average output speed (v_Avg)
=============================================   ====   =========   ================================================================================================================================================================


.. include:: VehSp_Avg_CalMan_VT.irst

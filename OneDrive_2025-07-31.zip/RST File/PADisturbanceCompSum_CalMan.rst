PA Disturbance Comp Sum
#######################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
The component PADisturbanceCompSum  provides an Infrastructure component to sum motor torques.

Block Diagram
=============

.. only:: confidential

   .. image:: PADisturbanceCompSum_CalMan_BlockDiagram.png


Input Signals
-------------

================================   =====   ================================================================================
Signal Name                        Unit    Description
================================   =====   ================================================================================
mOCCI_MotorTorque_xds16            Nm      motor torque of OnCenterConnection
mTrqSumI_TrqSumBeforeMTL_xds16     Nm      summation of all input motor torques of sub connector before MotorTorqueLimiter
mTrqSumI_TrqSumAfterMTL_xds16      Nm      summation of all input motor torques of sub connector after MotorTorqueLimiter
mTrqSumI_TrqSumAfterSCI_xds16      Nm      summation of all input motor torques of subconnector after SmartCruiseInterface
mInCoI_InertiaComp_xds16           Nm      motor torque offset from inertia compensation
================================   =====   ================================================================================


Output Signals
--------------

=================================   ====   ==========================================================
Signal Name                         Unit   Description
=================================   ====   ==========================================================
mTrqSumI_DisturbanceComp_xds16      Nm     totalized motor torque of disturbance compensation for RG3
=================================   ====   ==========================================================


Detailed Description
--------------------

The component PADisturbanceCompSum  provides an Infrastructure component to sum motor torques.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

======================================   =====   ======   ===========================================================
Parameter Name                           Unit    Range    Description
======================================   =====   ======   ===========================================================
xTrqSum_InertiaModFactor_XDU16                   0..2     Factor on InertiaModification motor torque
======================================   =====   ======   ===========================================================


.. include:: PADisturbanceCompSum_CalMan_VT.irst

Understeer
##########

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
The described special function Understeer is an AddOn function to realize dynamic torque reduction characteristics of
the steering system and the feedback the driver experiences during the driving condition understeer.

The cornering forces that can be transmitted by the tires are reduced with an increasing degree of understeering. That results in a drop in the rack force. In mechanical and hydraulic steering systems, this is indicated to the driver by a decreasing 
level of steering force and the return behavior of the steering system.

There is already an implicit return signal with regard to this well-known behavior because of the basic steering torque application function. This return signal can be amplified 
in an applicable fashion by the special function of torque reduction in the physical driving conditions.

The return behavior is reduced with an increasing degree of understeering because of the basic steering torque factor in the level of steering force and because of
the return torque factor in the active return torque and the center feel torque.

A return signal is sent to the driver in a transparent way with regard to this critical driving situation.


.. only:: confidential

   Block Diagram
   =============

   .. image:: UnderSteer_CalMan_BlockDiagram.png


Input Signals
-------------

================================   ====   ======================
Signal Name                        Unit   Description
================================   ====   ======================
vVehSpI_AbsAvgVehSpd_xdu16         km/h   Abs. vehicle speed: processed
xApplI_DegreeOfUndersteer_xdu16           degree of understeer
mApplI_DriverTorque_xds16          Nm     calculated driver torque
mApplI_AbsDriverTorque_xdu16       Nm     abs calculated driver torque
xApplI_GearSign_xds8                      steering gear sign
================================   ====   ======================

.. only:: confidential

   ================================   ====   ======================
   Signal Name [Internal]             Unit   Description
   ================================   ====   ======================
   fUnStI_MonSafeOk_xdb                      indicates whether the MonitorSafe checks report OK (true), or if they have detected a problem
   SY_USC_FUNCT_ACTIVATED                    understeer functionality is activated via coding switch
   ================================   ====   ======================

Output Signals
--------------

=======================================   ====   =====================
Signal Name                               Unit   Description
=======================================   ====   =====================
mUnStI_SteeringTorqueOffset4Check_xds16   Nm     understeer torsionbartorque offset 
mUnStI_MotorTorqueOffset4Check_xds16      Nm     understeer motortorque offset 
=======================================   ====   =====================

.. only:: confidential

   =======================================   ====   =====================
   Signal Name [Internal]                    Unit   Description
   =======================================   ====   =====================
   xUnSt_DegUnStFilt_xdu16                          filtered signal degree of understeer
   fUnSt_Activate_xdb                               indicates whether understeer is calculating and requesting a torque
   sUnSt_FeatureState_xdu8                          internal feature state for functioncoordinator
   =======================================   ====   =====================

Detailed Description
--------------------

The task of the software module is to improve the return signal for the driving situation of understeering in dependence upon the degree of understeering in the dynamic limit area.

A basic steering torque factor is generated to influence the steering force level, and a factor in the return torques of the active return and center feel application functions is
generated to influence the return behavior. The essential effect of the understeering function is achieved via the influence on the basic steering torque. The influence on the return
torques is additionally dependent upon the basic active return application (withdrawal of the active return via the vehicle speed and hand torque) and is therefore likely to be small.
It is mainly relevant at low coefficients of friction.

First off, the degree of understeering can be rescaled via a characteristic curve in dependence upon the vehicle speed. That could be necessary when the progression of the degree
of understeering in a speed range does not correspond to the subjectively expected degree of understeering.

A characteristic curve in dependence upon the degree of understeering is to be applied in the path for calculating the basic steering torque factor. This characteristic curve 
establishes the course that the basic steering torque factor will have when going into the applicable full-scale value. In addition, the amount of the full-scale value by which the
basic steering torque will be reduced can be influenced by a characteristic curve in dependence upon the vehicle speed.

A reduction factor will likewise be applied for the factor involving the return torques. This takes place here via a scalable application quantity for the increase that represents
a ramp up to the applicable full-scale value. The amount of the full-scale value by which the return torques can be reduced can also be varied here by means of a characteristic curve 
in dependence upon the vehicle speed.

An example of the application of the two factors to understeering at a constant speed is shown in the following illustration

.. image:: UndersteerGradient_blockDiagram.png


Calibration/Application Parameters
==================================

======================================   =====   ======   =============================================
Parameter Name                           Unit    Range    Description
======================================   =====   ======   =============================================
xUnSt_FilterFactOfUndersteer_XDU16               0...1    filter factor understeer
xUnSt_RampUpDownGradUndersteer_XDS16             0...10   max gradient understeer
xUnSt_DegUnStFiltFact_XAU16                               factor depending on understeer
xUnSt_VehSpeedFact_XAU16                                  factor understeer depending on vehicle velocity
mUnSt_WeightingDriverTorque_XAU16        Nm               weighting driver torque
xUnSt_MaxFactorOnTBTUndersteer_XDU16     Nm      0...1    factor limitation
======================================   =====   ======   =============================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   ======================================   =====   =======    =============================================
   Parameter Name                           Unit    Range      Description
   ======================================   =====   =======    =============================================
   xUnSt_ActivateUndersteerFeedback_XDU8            0..1       acivate understeer
   xUnSt_BypassFactMmot_XDU16               Nm      0...0.9    factor for the understeer bypass motor torque
   mUnSt_LimitTBTOffset_XDU16               Nm      0...3      limit of understeer steering torque offset
   mUnSt_LimitMMotOffset_XDU16              Nm      0...1      limit of understeer motor torque offset
   ======================================   =====   =======    =============================================

.. include:: Understeer_CalMan_VT.irst

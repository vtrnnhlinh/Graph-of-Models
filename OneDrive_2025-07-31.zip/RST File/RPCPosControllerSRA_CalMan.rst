﻿RPCPosControllerSRA
#########################

Short Description
=================

The RPC is a cascaded controller to control the rackposition.
If RPC is activated and the calculation of derivation is enabled,the derivation of NominalRackPosition is calculated.
The output of the rackposition controller and the output of the derivation of the nominal rackposition are added and the result is saturated.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RPCPosControllerSRA.PNG

   Input Signals
   -------------

   =======================================   ==========   =========   ==========================================================================
   Signal Name                               Unit         Range       Description
   =======================================   ==========   =========   ==========================================================================
   lApplI_RackPosition_xds16                 mm           -200..200   current rack position [mm]
   lEndStopI_RackPosition_xds16              mm           -125..125   distance from end stop
   fRPCI_Activate_xdu8                        n.a          0..1        flag for the activation of the RPC controller
   sFltManI_EcuChannelRole_xdu8              n.a          0..1        indicated whether current channel is Master
   lRPCI_NominalRackPosition_xds16           mm           -200..200   Requested rack position for RPC controller (after EndStop limitation)
   =======================================   ==========   =========   ==========================================================================

   Output Signals
   --------------

   ======================================   ======   =============   =======================================================================================
   Signal Name                              Unit     Range           Description
   ======================================   ======   =============   =======================================================================================
   vRPCI_NominalRackSpeedLimited_xds16      -        -250..250       Nominal rack speed for RPC controller
   ======================================   ======   =============   =======================================================================================

   Measurement Signals
   -------------------

   ==========================================   ======   =============   ====================================================================================================
   Signal Name                                  Unit     Range           Description
   ==========================================   ======   =============   ====================================================================================================
   aRPC_NominalRackAcceleration_xdf32           mm/s^2   -10000..10000   Nominal rack acceleration [mm/s^2]
   vRPC_SaturationCutOffPart_xds32              -        -3000..3000     Saturation overhang NominalRackSpeedLimited. Used for antiwindup of I-part of RackPos-controller
   vRPC_NominalRackSpeedP_xds16                 mm/s     -250..250       P-part position controller
   vRPC_NominalRackSpeedI_xdf32                 mm/s     -250..250       I-part position controller
   vRPC_NominalRackSpeedD_xds16                 mm/s     -250..250       D-part position controller
   lRPC_RackPositionDiff_xdf32                  mm       -500..500       difference of nominal and actual rack position
   vRPC_NominalRackPositionDerivative_xds16     mm/s     -250..250       Derivative nominal rack position
   ==========================================   ======   =============   ====================================================================================================

   Detailed Description
   --------------------
   The RPC is a cascaded controller to control the rackposition.
   It consists of an outer controlloop which feedbacks the error between nominal and real rackposition via PID-parameters to an inner controlloop.
   The feedback of the outer controlloop is used as nominal rackspeed for the inner controlloop.
   The inner controlloop feedbacks the error between nominal and real rackspeed via PID-paramters and generates a motortorque.

   In this Component RPCPosControllerSRA, the nominal rackspeed for the rackspeed-controller is calculated.
   If RPC is activated and the calculation of derivation is enabled,the derivation of NominalRackPosition is calculated.
   The output of the rackposition controller and the output of the derivation of the nominal rackposition are added and the result is saturated.
   Furthermore the rackacceleration is also limited to avoid big jerks

   Calibration/Application Parameters
   ----------------------------------

   =====================================================   =====   ==============   ====================================================================
   Parameter Name                                          Unit    Range            Description
   =====================================================   =====   ==============   ====================================================================
   vRPC_MaxGradRackSpeed_XDU16                             mm/s    0..500           gradient limitation rackspeed HAD
   fRPC_EnableNominalRackPositionDerivative_XDU8           n.a     0..1             Activation derivation of nominal rackposition
   qRPC_FiltFreqNominalRackPositionForDerivative_XDU16     -       0..1000          Filter frequency for nominal rack position for derivative
   xRPC_RackPosCtrlP_XDF32                                 l/s     0..2000          p-part positioncontroller HAD
   xRPC_RackPosCtrlI_XDF32                                 1/s^2   0..1000          i-part positioncontroller HAD
   vRPC_NominalRackSpeedIMax_XDF32                         -       0..250           saturation i-part positioncontroller HAD
   xRPC_RackPosCtrlD_XDF32                                 n.a     0..15            d-part positioncontroller HAD
   qRPC_FrequencyCycle_XDU16                               hz      0..1000          Filter frequency for nominal rack position for derivative
   fRPC_EnableRackSpeedLimitation_XDU8                     -       0.0..1.0         Activation limitation of nominal rack speed
   tRPC_TimeCycle_XDU8                                     s       1..10            RPC time cycle
   xRPC_DerivativeRackSpeedFactorDepOnDist2Endstop_XAU16   l/s     0..1             Rack speed factor dependent on distance 2 Endstop
   =====================================================   =====   ==============   ====================================================================

.. include:: RPCPosControllerSRA_CalMan_VT.irst

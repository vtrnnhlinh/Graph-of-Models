﻿TorqueSignalConditioningMain
############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component implements the extrapolation of torsion bar torque, which is required for doing the averaging of the TBT signals.



Block Diagram
=============

.. only:: confidential

   .. image:: TrqSigCond_Main_CalMan_BlockDiagram.png
  
Input Signals
-------------

=============================================          =======   ====================================================================================
Signal Name                                            Unit      Description
=============================================          =======   ====================================================================================
mApplI_LimitedMotorTorque_xds16                        Nm        limited motor torque
zcrChatterPeriodsCount_xdu8                            -         Counter of the chatter oscillations
vVehSpI_AbsAvgVehSpd_xdu16                             km/h      Average vehicle speed. Goal: be as close to the actual speed over ground as possible
nApplI_RotorSpeedFilt_xds16                            1/min     filtered rotor speed
fTscI_DisAvgBackUpMonFail_xdb                          -         Averaging disabled due to Back check fail
tHwlWrapI_TaskActSysTime_xdu16                          µs       system time in µs [0µs .. 65535µs] 
=============================================          =======   ====================================================================================

.. only:: confidential

=============================================          =======    ===========================================================================================
Signal Name [Internal]                                 Unit       Description
=============================================          =======    ===========================================================================================
sHwlWrapI_TorsionBarTorqueState_xde                    -          Validity state of the torsion bar torque
mHwlWrapI_TorsionBarTorqueRed_xds16                    Nm         Torsion Bar Torque of the passive TBT sensor
yHwlWrapI_TorqueSensorVariant_xde                      -          Torsion bar torque sensor variant
tHwlWrapI_TorsionBarTorqueSampleTime_xdu16             µs         Time stamp when the raw data used for the torsion bar torque calculation are sampled
tHwlWrapI_TorsionBarTorqueSampleTimeRed_xdu16          µs         Time stamp of the passive torsion bar torque sensor value
mHwlWrapI_TorsionBarTorque_xds16                       Nm         Torsion bar torque
=============================================          =======    ===========================================================================================  
    

Output Signals
--------------

=============================================          =======    ==============================================================
Signal Name                                            Unit       Description
=============================================          =======    ==============================================================
xTscI_PT1tauGradTBT_xdu16                              -          vehicle speed dependant PT1 filter const GradTBT
mTscI_ExtrapolTBT_xds16                                Nm         extrapolated torsion bar torque
=============================================          =======    ==============================================================

.. only:: confidential

=============================================          =======    ==============================================================
Signal Name                                            Unit       Description
=============================================          =======    ==============================================================
tTscI_GradTBTST_xdu16                                  us         Time difference of TBT sample time
tTscI_GradTBTSTred_xdu16                               us         Time difference of TBTred sample time
fTscI_TbtSensor_provides_TBTred_xdu8                   -          0-no channel exist,1-Backup channel exist
mTscI_HysteresisTBT_xdu16                              Nm         HysteresisTBT: DeadZone TBT Gradient
=============================================          =======    ==============================================================


Detailed Description
--------------------

TscMain additionally extrapolates TorsionBarTorque using TorsionBarTorqueSampleTime and known SystemDelay.
The component processes the torsion bar torque signal using extrapolation.
If a redundant TBT channel is provided (TorqueSensorVariant dependent), and both channels are valid (shown in TorsionBarTorqueState)averaging can be disabled.

Calibration/Application Parameters
==================================
.. Please note:: the following list of parameters will always be visible in the generated documentation!

.. only:: confidential

=========================================   =======   ==========   =======================================================================================================
Parameter Name                              Unit      Range        Description
=========================================   =======   ==========   =======================================================================================================
yTsc_Disable_Extrapol_TBT_XDU8              -         0..1         0-enable averaging and does extrapolation,1-disable averaging and still does extrapolation
yTsc_Disable_TscI_TBT_Avg_XDU8              -         0..1         1-Disable the Averaging for the extrapolate signal,0-Enable averaging for the extrapolate signal
fTsc_SingleDMS_provides_TBTred_XDU8         -         0..1         2nd SingleDMS TBT channel exists
fTsc_DualDMS_provides_TBTred_XDU8           -         0..1         2nd DualDMS TBT channel exists
fTsc_SingleMMT_provides_TBTred_XDU8         -         0..1         2nd SingleMMTTBT channel exists
fTsc_DualMMT_provides_TBTred_XDU8           -         0..1         2nd DualMMT TBT channel exists
fTsc_CustomerTypeA_provides_TBTred_XDU8     -         0..1         2nd CustomerTypeA TBT channel exists
fTsc_OtherSensor_provides_TBTred_XDU8       -         0..1         2nd TBT channel exists
vTsc_SubstituteSpeed_XDU16                  km/h      0..500       If the vehicle speed is invalid, substitute speed is considered for TSC
tTscI_NominalTaskTimeDiff_us_XDU16          us        1000..5000   Depending upon the frequency at which the functionality is running,task time diff to be set accordingly
tTsc_DeadZonThreshold_XDU16                 us        0..30000     in 2 microcontroller system ,the system time lags the timestamp and this parameter  is   setaccordingly
=========================================   =======   ==========   =======================================================================================================

Short Description
-----------------

Tune the respective switch to 1 depending upon the type of Sensor used as per the below table

.. only:: confidential   
   
  .. image:: TSC_calman.PNG




.. only:: confidential

TSC Extrapolation to account for System delay
=============================================

.. only:: confidential

===========================================      =======   ==========   ===========================================================================================================================================
Parameter Name                                   Unit      Range        Description
===========================================      =======   ==========   ===========================================================================================================================================
zTsc_ChatteringDetected_XDU8                     -         0..30        chatter periods counter threshold to react when chattering detected
xTsc_SubstExtrapolFactChatter_XDU16              -         0..1         Substitute extrapolation factor in the event of chatter detected
tTsc_SystemDelay_us_XDU16                        us        0..10000     It is the total time to be accounted for which the TBT request is placed and a actual reaction happens in the motor(refer Diagram 1.1)
fTsc_EnableAtlowDyn_XDU8                         -         0..1         Enable Extrapol to future only at low dyn,Extrapolation to the futue is enabled at high dyn then tune it to 0 otherwise it is 1
xTsc_TorqueGradLowDyn_XDU16                      ms        0..0.1       TorqueGradient border for detection of low steering dynamic beyond which low steering dynamic is set to 0
tTsc_DebounceTimeLowDyn_XDU8                     ms        1..250       debounce time for which low dynamics conditions should fulfill and set low dynamics to 1
nTsc_MaxRotSpdLowDyn_XDU16                       1/min     0..13000     RotorSpeed border for detection of low steering dynamic beyond which low steering dynamic is set to 0
mTsc_MaxTBTLowDyn_XDU16                          Nm        0..20        TorsionbarTorque border for detection of low steering dynamic beyond which low steering dynamic is set to 0
mTsc_MaxMMotLowDyn_XDU16                         Nm        0..20        MotorTorque border for detection of low steering dynamic beyond which low steering dynamic is set to 0
===========================================      =======   ==========   ===========================================================================================================================================

Diagram 1.1
===========

.. only:: confidential

  .. image:: SystemTimeDelay.PNG

Diagram 1.2
===========

.. only:: confidential

  .. image:: TSCExtrapolation.png

.. include:: TrqSigCond_Main_CalMan_VT.irst
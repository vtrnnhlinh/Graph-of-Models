EndStopHsd
##########

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
The steering function EndStopHsd (HighSpeedDamping) is responsible for the calculation of a damping torque.


Block Diagram
=============

.. image:: EndStopHsd_CalMan_BlockDiagram.png


Input Signals
-------------

=======================================   =====   =========================================================================================================
Signal Name                               Unit    Description
=======================================   =====   =========================================================================================================
fEndStopHsdI_EnableUndervoltOffset_xdb            Enable undervolt offset in EndStopHsd if set to true
lEndStopI_DistanceToEndstop_xds16         mm      distance from end stop in mm
nApplI_RotorSpeedFilt_xds16               1/min   filtered rotor speed
nApplI_RotorSpeed_xds16                   1/min   unfiltered rotor speed
sApplI_SteeringAngleLinState_xdu8                 state of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
sApplI_VehicleSpeedState_xdu8                     Validflag for vehicle speed vApplI_AbsVehicleSpeedFilt_xdu16 (1 = valid; 0 = invalid or substitute speed)
uApplI_SupplyVoltage_xdu16                V       SupplyVoltage, unfiltered
vApplI_AbsVehicleSpeedFilt_xdu16          km/h    Abs. vehicle speed: processed
vVehSpI_AbsMaxSafeVehSpd_xdu16            km/h    Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
xApplI_VehDirection_xds8                          Sign of vehicle direction forward: 1, reverse: -1
=======================================   =====   =========================================================================================================


Output Signals
--------------

================================   =====   ==============================================================
Signal Name                        Unit    Description
================================   =====   ==============================================================
nEndStopHsd_HystRotorSpeed_xds16   1/min   used rotor speed for HighSpeedDamping, with applied hysteresis
fEndStopHsd_ForwardDrv_xdb                 Internal fwd driving flag (0=bwd; 1=fwd)
mEndStopHsdI_MotTrq4Check_xds16    Nm      damping torque at high rotor speeds to be checked
================================   =====   ==============================================================


Detailed Description
--------------------

The function is activated if the rotor speed is high, the calculated torque effects a deceleration of the rotor and therefore reduces the rotatory energy with the aim to protect the mechanical end stops.
It can be selected if either the unfiltered or filtered rotor speed signal shall be used as input. This leads to differences in functional performance (delay) and acoustics.
A hysteresis can be applied to the falling rotor speed. This improves function performance and acoustics.
For low rotor speeds the function is inactive. If the absolute rotor speed exceeds a certain rotor speed border ("start speed", characteristic curve, based on distance to endstop), the difference between abs. rotor speed and
start speed is calculated. There is an additional possibility to start high speed damping at lower rotor speeds when voltage is low ("undervoltage start offset"), this may be used to improve system behavior (FOC performance, acoustics, ...) at low voltages.
The difference [1/min] is multiplied with a tunable damping factor [Nm*min] (characteristic curve, based on vehicle speed)and the resulting torque is multiplied
with the opposite sign of the rotor speed to effect the deceleration of the rotor.
When driving backwards, the axis configuration typically leads to a rackforce pushing towards the endstops, so that higher damping forces may be needed. Therefore a separate parameter set is used when driving backwards.
Use of the backwards driving parameter set is initiated when xApplI_VehicleDirection_xds8 is indicating backwards for at least tEndStopHsd_VehDirDebounceTime_XDU16 and vApplI_AbsVehicleSpeedFilt_xdu16 is above vEndStopHsd_BackwardEnableTh_XDU8.
It is aborted when xApplI_VehicleDirection_xds8 is pointiindicatingng forwards or vApplI_AbsVehicleSpeedFilt_xdu16 is below vEndStopHsd_BackwardDisableTh_XDU8 or vVehSpI_AbsMaxSafeVehSpd_xdu16 is above vEndStopHsd_MaxAllowedBackward_XDU8 for at least tEndStopHsd_SpeedTooHighTol_XDU16.





Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

====================================================   =====   ============   ======================================================================================================================
Parameter Name                                         Unit    Range          Description
====================================================   =====   ============   ======================================================================================================================
fEndStopHsd_EnableUnFiltRotSpeed_XDU8                          0..1           0 = filtered rotorspeed; 1 = use unfiltered rotorspeed in highspeeddamping
lEndStopHsd_SubstDistToES_XDU16                        mm      0..125         subst value - distance to endstop used if steering angle is invalid
nEndStopHsd_HighSpeedDampingStartReverse_XAS16         1/min   0..5000        rotor speed border to switch on the highspeed damping when reversing
nEndStopHsd_HighSpeedDampingStart_XAS16                1/min   0..5000        rotor speed border to switch on the highspeed damping
nEndStopHsd_RotSpeedFallingHysteresisReverse_XAU16     1/min   0..5000        hysteresis applied on start speed when reversing
nEndStopHsd_RotSpeedFallingHysteresis_XAU16            1/min   0..5000        hysteresis applied on start speed
nEndStopHsd_UnderVoltageStartOffset_XAU16              1/min   0..5000        rotor speed reduction for start speed during undervoltage
tEndStopHsd_SpeedTooHighTol_XDU16                      s       0.001..5       Time that exceeding the speed threshold is tolerated before cancelling backward driving
tEndStopHsd_VehDirDebounceTime_XDU16                   s       0.001..10      Reverse driving flag is debounced by this amount of time before changing to forward
vEndStopHsd_BackwardDisableTh_XDU8                     km/h    0..50          Disable backward driving flag when speed falls below this threshold
vEndStopHsd_BackwardEnableTh_XDU8                      km/h    0..50          Backward driving is only detected above this speed threshold
vEndStopHsd_MaxAllowedBackward_XDU8                    km/h    10..100        Cancel backward driving detection above this speed
xEndStopHsd_HighSpeedDampingFactorReverse_XAU16                0..0.0048828   factor of highspeed damping Nm*min dependent on vehicle speed when reversing
xEndStopHsd_HighSpeedDampingFactor_XAU16                       0..0.0048828   factor of highspeed damping Nm*min dependent on vehicle speed
xEndStopHsd_SubstHighSpeedDampingFactorReverse_XDU16           0..0.0048828   subst value - factor of highspeed damping Nm*min when reversing
xEndStopHsd_SubstHighSpeedDampingFactor_XDU16                  0..0.0048828   subst value - factor of highspeed damping Nm*min
====================================================   =====   ============   ======================================================================================================================


.. include:: EndStopHsd_CalMan_VT.irst

Hysteresis Torque
#################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The hysteresis torque is generated in dependence upon the speed of the steering wheel angle,the torsion bar torque and the vehicle speed. The hysteresis function brings about a torque
in opposition to the direction of steering and thus generates a defined turning behavior / steering behavior when driving in a curve.This torque is required when driving in a curve
to increase the cornering predictability. When traveling straightaway, in contrast, a hysteresis torque is unwanted. With the dependence upon the torsion bar torque, the hysteresis 
torque is consequently suppressed during straightaway travel or when there are low torsion bar torques and the full hysteresis torque is applied incurves or more precisely when there
are high torsion bar torques.

.. image:: HysteresisTorqueCurve_blockDiagram.png

The hysteresis torque can be completely suppressed during parking, for instance, independence upon the vehicle speed.

Block Diagram
=============

.. image:: HysteresisTorque_CalMan_BlockDiagram.png

Input Signals
-------------

================================   ====   ===========================
Signal Name                        Unit   Description
================================   ====   ===========================
vApplI_AbsVehicleSpeedFilt_xds16   Km/h   Abs.vehicle speed:processed
mApplI_TorsionBarTorque_xds16      Nm     HW LIB: torsion bar torque
vApplI_SteeringAngleSpeed_xds16    °/s    Steering wheel angle speed
================================   ====   ===========================


Output Signals
--------------

==================================   ====   =====================
Signal Name                          Unit   Description
==================================   ====   =====================
mHystTorI_NominalSteerTorque_xds16   Nm     Hysteresis torque
==================================   ====   =====================

   
Detailed Description
--------------------
The task of the software module is to calculate the hysteresis component of the target torsion bar torque in dependence upon the torsion bar torque, the steering wheel speed and 
the vehicle speed.A dead zone that suppresses this noise band around a steering wheel angle speed of 0 can be applied to prevent interference from a noisy steering wheel angle speed 
signal. The hysteresis torque increase is to be applied via an amplification factor. This factor should be applied to the greatest extent possible. But factors that are too large will
result in vibration because even very small speeds of the steering wheel angle will lead to virtual jumps in the application of the hysteresis torque.After that, there is a limitation
to a maximum hysteresis torque that can be adjusted by a factor dependent upon the torsion bar torque. The hysteresis torque should only be applied in a very minimal way when there 
are torsion bar torques close to 0 Nm, because the steering behavior or center feel is also influenced by this. When there is an increasing torsion bar torque, the hysteresis torque 
is to likewise be raised to improve cornering predictability in curves. After the limitation, an applicable low-pass filtering of the hysteresis torque is required to suppress 
high-frequency interference or instability caused by the dead zone and the limitation. Finally, the amount of the hysteresis torque can be varied in dependence upon the vehicle speed
via a further characteristic curve.



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

======================================   =====   ======   =============================================
Parameter Name                           Unit    Range    Description
======================================   =====   ======   =============================================
xHystTor_DeadZoneStSpeed_XDU16                   0..50    deadzone steering angle speed
xHystTor_StSpeed2TorFact_XDU16                   0..1     amplification factor Hysteresis
xHystTor_HystTorFact_XDU16                       0..2     factor on characteristic xHystTor_TBTFact_XAU16 for max hysteresistorque
xHystTor_TBTFact_XAU16                           0..1     factor depending on torsionbartorque formaximal hysteresetorque
xHystTor_VehicleFact_XAU16                       0..1.2   factor on hysteresistorque depending onvehiclespeed
======================================   =====   ======   =============================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   
   ======================================   =====   ==========   =====================================================
   Parameter Name                           Unit    Range        Description
   ======================================   =====   ==========   =====================================================
   mHystTor_MaxHystTor_XDU16                Nm      0 ... 2      limit for maximal hseresis torque
   xHystTor_LowPassFilterFact_XDU16                 0.01 ... 1   time constant low pass filter(value*1000 equals [Hz])
   xHystTor_TBTFilterFact_XDU16                     0.01 ... 1   filter factor for torsion bar torque     
   xHystTor_FactOfNominalTorque_XDS16               -1 ... 1     factor on nominal hysterese steer torque
   ======================================   =====   ==========   =====================================================



.. include:: HysteresisTorque_CalMan_VT.irst

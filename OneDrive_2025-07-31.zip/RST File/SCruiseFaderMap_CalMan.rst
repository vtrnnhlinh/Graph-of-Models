.. only:: confidential

   Smart Cruise Fader Map
   ######################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   This component is used to map the motor torque received from the "Main Connector" onto the Smart Cruise Fader Motor Torque.
   This ensures for system environments not using the Smart Cruise Fader a consistent torque flow.
   All subsequent receiving components can read the Smart Cruise Fader Motor Torque.


   Block Diagram
   =============

   Mapping of input to output signal.

   Input Signals
   -------------

   ================================   ====   ==================================================================
   Signal Name                        Unit   Description
   ================================   ====   ==================================================================
   mTrqSumI_MotTrqSum1_xds16           Nm    Summation of all input motor torques of main controller
   ================================   ====   ==================================================================


   Output Signals
   --------------

   ================================   ====   ==================================================================
   Signal Name                        Unit   Description
   ================================   ====   ==================================================================
   mSCruiseFadrI_MotTrq_xds16          Nm    Motor torque coming from the Smart Cruise Fader functionality
   ================================   ====   ==================================================================


   Detailed Description
   --------------------

   The input signal is mapped onto the output signal. In case the input signal is invalid, the output signal is set to 0 Nm.



   Calibration/Application Parameters
   ==================================

   No calibration parameters.

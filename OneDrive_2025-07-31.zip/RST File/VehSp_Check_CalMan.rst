VehSp_Check
###########

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

Monitor the safe speeds. Set output signals to SNA if the check fails.


Block Diagram
=============

.. image:: VehSp_Check_CalMan_BlockDiagram.png

Input Signals
-------------

================================   ====   ===================================================================================================================
Signal Name                        Unit   Description
================================   ====   ===================================================================================================================
vVehSpI_AbsAvgVehSpd4Check_xdu16   km/h   Average vehicle speed to be read by check component. Note: this is just a simple average used for plausibilization.
vVehSpI_AbsMaxVehSpd4Check_xdu16   km/h   Maximum vehicle speed to be read by check component.
vVehSpI_AbsMinVehSpd4Check_xdu16   km/h   Minimum vehicle speed to be read by check component.
================================   ====   ===================================================================================================================


Output Signals
--------------

==============================   ====   ==========================================================================
Signal Name                      Unit   Description
==============================   ====   ==========================================================================
vVehSpI_AbsMaxSafeVehSpd_xdu16   km/h   Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
vVehSpI_AbsMinSafeVehSpd_xdu16   km/h   Minimum vehicle speed. Goal: actual speed over ground >= AbsMinSafeVehSpd.
fVehSp_MonOk_xdb                        Min/Max speeds have passed the plausibility check
==============================   ====   ==========================================================================


Detailed Description
--------------------

The component monitors the numerical relationship v_min <= v_avg <= v_max. If the check fails, the
output signals are set to SNA.



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

This component does not possess any calibration parameters.


.. include:: VehSp_Check_CalMan_VT.irst

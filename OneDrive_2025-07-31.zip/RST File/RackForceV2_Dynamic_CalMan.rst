RackForceV2_Dynamic
###################

Short Description
=================

The rack force module RackForce Dynamic (RFM-D) calculates the actual external force on the rack using a summation of torques of the EPS system
(torques acting on moving parts of the steering system and the resulting acceleration)

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Block Diagram
=============

.. only:: confidential

 .. image:: RackForceV2_Dynamic_CalMan_BlockDiagram.png


Input Signals
-------------

======================================        =======   =========================================================================================
Signal Name                                   Unit      Description
======================================        =======   =========================================================================================
mApplI_LimitedMotorTorque_xds16                Nm       Readback of the motor torque which is input into the FOC
mApplI_TorsionBarTorque_xds16                  Nm       Torsion Bar Torque Value
nApplI_RotorSpeed_xds16                       1/min     Rotor Speed
xApplI_GearSign_xds8                           -        Gear Sign represent the direction in which the steering system is assembled in the car
wApplI_AbsSteeringAngle_xdu16                  °        Absolute corrected steering angle
xSgcI_Torque2RackForceCorrFact_xdu16           -        I-Var Correction Factor
xDetIncFricI_AdaptedLoadFactor_xdu16           -        calculated Load Factor for RackForce
mDetIncFricI_AdaptedBaseFriction_xdu16         Nm       calculated Base Friction for RackForce
======================================        =======   =========================================================================================


Output Signals
--------------

=================================   ====   ============================
Signal Name                         Unit   Description
=================================   ====   ============================
kApplI_RackForce_xds16               N     computed rack force
kApplI_AbsRackForce_xdu16            N     Absolute computed rack force
kRackForceI_RackForceSimple_xds16    N     computed rack force simple
=================================   ====   ============================

Detailed Description
--------------------
RFMD calculates Rack force based on the equation of motion. It takes Motor torque and TBT applied on the rack and convertes the same into force.
To get the actual external force applied, friction force and inertia is subtracted from it.

Calibration/Application Parameters
==================================

============================================================     =====   ============================    ==========================================================================
Parameter Name                                                   Unit    Range                           Description
============================================================     =====   ============================    ==========================================================================

xRackForce_MMOTFilterFact_XDU16                                  -       0.001 .. 1                      filter 1 and 2 of the motor torque
xRackForce_TBTFilterFact_XDU16                                   -       0.001 .. 1                      filter 1 and 2 of the torsion bar torque
jsyInvSteeringRatio_XDU16                                        -       900 .. 3000                     1/steeringratio * 2^15
xRackForce_Ginv_N1_XDF32                                         -       -5000 .. 5000                   coefficient N1 of the FIR filter
xRackForce_Ginv_N2_XDF32                                         -       -5000 .. 5000                   coefficient N2 of the FIR filter
xRackForce_Ginv_N3_XDF32                                         -       -5000 .. 5000                   coefficient N3 of the FIR filter
wRackForce_MaxMotVelFric_XDU16                                   °/s     1 .. 1000                       Limit of rotor velocity for full activation friction compensation [°/s]
xRackForce_LoadFactor_XDU16                                      -       0 .. 1                          load factor for friction compensation [Nm/Nm]
xRackForce_FricFilterFact_XDU16                                  -       0.001 .. 1                      filter of the friction compensation
xRackForce_RotAccFilterFact_XDU16                                -       0.001 .. 1                      filter 1 and 2 of the rotor acceleration
xsyRotorInertia_XDU16                                            -       0 .. 1.0e-3                     relevant inertia of rotor [kgm^2]
xsyNoEffDepEngTorqueToRackForce_XDU16                            -       0 .. 5000                       Factor from Engine Torque to Rack Force without efficiency
xsyInvSteeringRatioVarFact_XAU16                                 -       0.0009765625 .. 2 0 .. 710      Adaptation factor translation for i variable
mRackForce_BaseFriction_XDU16                                    Nm      0 .. 1                          base friction for friction compensation [Nm]
mRackForce_MinAdaptedBaseFriction_XDU16                          Nm      0 .. 2                          Lower Limit of the base friction for friction compensation[Nm]
mRackForce_MaxAdaptedBaseFriction_XDU16                          Nm      0 .. 2                          Upper Limit of the base friction for friction compensation[Nm]
============================================================     =====   ============================    ==========================================================================

.. include:: RackForceV2_Dynamic_CalMan_VT.irst

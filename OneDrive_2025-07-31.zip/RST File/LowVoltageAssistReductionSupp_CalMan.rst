LowVoltageAssistReductionSupp
##############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

   NOTE: This is a project specific component and the details shall be updated by respective customer project teams.

.. only:: confidential
   
   This component checks the activation conditions required for enabling the Low Voltage Assist Reduction functionality and calculates the corresponding flag for the LowVoltAssistReduction component. 
   The customer projects are free to alter these conditions, based on thier project architecture.



Block Diagram
=============

.. only:: confidential

   .. image:: LowVoltageAssistReductionSupp_CalMan_BlockDiagram.png
   

Input Signals
-------------

.. only:: confidential

   ================================   ====   ======================
   Signal Name                        Unit   Description
   ================================   ====   ======================
   sApplI_EngineRunning_xdu8                  State of combustion engine (0 == EngineNotRunning, 1 == EngineRunning, 2 == EngineRunningStable)
   ================================   ====   ======================


Output Signals
--------------

.. only:: confidential

   ====================================   ====   =====================
   Signal Name                            Unit   Description
   ====================================   ====   =====================
   sLowVoltAssRedI_EnableReduction_xdb           LowVoltageAssistReduction component activation Signal (0 == Disable, 1 == Enable)
   ====================================   ====   =====================


Detailed Description
--------------------

.. only:: confidential

   The customer projects are free to alter these conditions, based on thier project architecture.



Calibration/Application Parameters
==================================

.. only:: confidential

.. To be used incase customer projects have calibration parameters. 

..   Provide a table of internal calibration parameters.
   
..   ======================================   =====   =====   =============================================
..   Parameter Name                           Unit    Range   Description
..   ======================================   =====   =====   =============================================
..
..   ======================================   =====   =====   =============================================

.. include:: LowVoltageAssistReductionSupp_CalMan_VT.irst

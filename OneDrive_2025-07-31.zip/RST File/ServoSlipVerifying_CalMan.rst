Servo Slip Verifying
####################


Short Description
=================

The ServoSlipVerifying component is responsible for the verification of a possible slipping clutch event. The component has the VerifyRealSlip server. 

The input for the VerifyRealSlip server is the RotAngOffsetCalibNVR and the SteeringAngleLinState. The previous valid RotAngOffsetCalibNVR is stored temporary
for the component when the SteeringAngleLinState becomes 1 OR 2 (RP_RAW OR RP_EXACTLY). The server increments the LifeTimeCounter if the syncronisation of the rack position
was initiated by the SSD (by incrementing the DetectionCounter) and when it finishes (the SteeringAngleLinState becomse 1 or 2) the RotAngOffsetCalibNVR change is greater
than a specified limit. The server also increments the LifeTimeCounter once within a time window if the SteeringAngleLinState is 0 (RP_INVALID) and the DetectionCounter incremented. 
The LifeTimeCounter and the last temporary stored RotAngOffsetCalibNVR are stored in the NvM.
LifeTimeCounterReachedLim indicates if the LifeTimeCounter reaches the maximum allowed mechanical slip.


Block Diagram
=============

.. image:: ServoSlipVerifying_CalMan_MaxAngleOffsetChange.png
.. image:: ServoSlipVerifying_CalMan_MaxAllowedMechanicalSlip.png
.. image:: ServoSlipVerifying_CalMan_TimeWindow.png


Input Signals
-------------

===================================  ======  ===================================================================================================
Signal Name                          Unit    Description
===================================  ======  ===================================================================================================
zSSDetI_DetectionCounter_xdu16               Counter of the already detected slippings in an ignition cycle
wRpSyncI_RotAngOffsetCalibNVR_xds16  °       Calib position within single turn rotor angle
sApplI_SteeringAngleLinState_xdu8            Steering angle status from rotor angle 0-invalid 1-raw 2-exactly
zSSVer_LifeTimeCounter_xdu16                 The NvM stored value of the LifeTimeCounter
PrevRotAngOffsetCalib                °       The NvM stored value of the last calib position of the rotor angle in the previous Ignition cycle
===================================  ======  ===================================================================================================


Output Signals
--------------

=======================================   ====  ============================================================================================================
Signal Name                               Unit  Description
=======================================   ====  ============================================================================================================
fSSVerI_LifeTimeCounterReachedLim_xdb           The flag of the LifeTimeCounter which indicates that the maximum allowed mechanical slip has been reached.
zSSVer_LifeTimeCounter_xdu16                    The NvM stored value of the LifeTimeCounter
PrevRotAngOffsetCalib                     °     The NvM stored value of the previous calib position of the rotor angle
wSSVer_StoredRotAngOffset_xds16           °     The last valid value of the calib position within single rotor angle
=======================================   ====  ============================================================================================================


Detailed Description
--------------------

The VerifyRealSlip server verify that a possible, suspicious slipping event caused a significant change in the wRpSyncI_RotAngOffsetCalibNVR.

When the sApplI_SteeringAngleLinState becomes 1 OR 2 (RP_RAW OR RP_EXACTLY) the wRpSyncI_RotAngOffsetCalibNVR_xds16 is stored in the wSSDet_StoredRotAngOffset
internal signal if it is in the valid range. The previously stored wSSDet_StoredRotAngOffset is written to the NVM.
If the zSSDetI_DetectionCounter changes, it triggers the re-synchronization of the rack position. This process is finished when the 
sApplI_SteeringAngleLinState becomes 1 OR 2 (RP_RAW OR RP_EXACTLY). The zSSVerI_LifeTimeCounter shall be incremented if the re-syncronisation of
the rack position was started by the SSD and when it finished the change in the wRpSyncI_RotAngOffsetCalibNVR is greater than
a calibration parameter (wSSVer_MaxAngleOffsetChange_XDU16).

When the sApplI_SteeringAngleLinState is 0 (RP_INVALID) and the zSSDetI_DetectionCounter changes within a time window (which size can be set by a a calibration parameter
(zSSVer_InitWWTDetWindowSize_XDU16)), the zSSVerI_LifeTimeCounter shall be incremented by 1 only once in the give time window.

The LifeTimeCounter is stored in the NvM.
LifeTimeCounterReachedLim shall be 1 if the LifeTimeCounter is greater than the calibration parameter (zSSVer_MaxAllowedMechanicalSlip_XDU16).

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=======================================  ====  ========  =================================================
Parameter Name                           Unit  Range     Description
=======================================  ====  ========  =================================================
wSSVer_MaxAngleOffsetChange_XDU16        °     0..360    Allowed Rotor Angle offset change for slip clutch
zSSVer_MaxAllowedMechanicalSlip_XDU16          0..2500   Maximum allowed mechanical slip during life-time
zSSVer_InitWWTDetWindowSize_XDU16        ms    1..60000  Time window size in PR_INVALID state 
=======================================  ====  ========  =================================================



.. include:: ServoSlipVerifying_CalMan_VT.irst
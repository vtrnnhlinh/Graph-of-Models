Keep Last Angle
################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component provides a mechanism to keep last angle (KLA) for a calibrateable amount of time based on an average rotor position calculation as an input to a PID controller providing a motor torque request. 

.. only:: confidential

   Block Diagram
   =============

   .. image:: KeepLastAngle_CalMan_BlockDiagram.png


.. only:: confidential

   Input Signals
   -------------

   ========================================   ====   =============================================
   Signal Name                                Unit   Description
   ========================================   ====   =============================================
   sFltManI_EcuChannelStateReq_xdu8           --     GDU control request
   wApplI_RotorPosition_xds32         	       °      HW LIB: integrated, compensated rotorposition 
   ========================================   ====   =============================================


.. only:: confidential

   Output Signals
   --------------

   ========================   =======   =====================================================================
   Signal Name                Unit      Description
   ========================   =======   =====================================================================
   mKLAI_NomMotTq4Chk_xds16   Nm        Nominal motor torque request for check of keep last angle calculation
   mKLA_PPart_xds16           --        P-Part of the KLA controller
   mKLA_IPart_xds32           --        I-part of the KLA controller
   mKLA_DPart_xds32           --        D-part of the KLA controller
   tKLA_ActvnTmr_xdu16        s         Activation timer of KLA function after Backup ECU went into the lead
   wKLA_AvrgRotorPosn_xds16   °         Average rotor position used and hold while KLA is active.
   wKLA_BlkBuf_xds16          °         Block buffer KLA rotor position
   wKLA_RotorPosnDe_xds16     °         Rotor position deviation as controller input.
   wKLA_SampleAvrg_xds16      °         Sample average KLA rotor position
   wKLA_SampleBuf_xds16       °         Sample buffer KLA rotor position
   xKLA_ActvnFac_xdu16        --        Factor of KLA torque output
   zKLA_idxBlkNxt_xdu8        --        Counter index next block
   zKLA_idxSampleNxt_xdu8     --        Counter index next sample
   ========================   =======   =====================================================================

.. only:: confidential

   Detailed Description
   --------------------

   When the Main µC is active, this component continuously calculates an average rotor position based on the rotor position values of the last 300ms provided by the HwLib.
   When a switch to the Backup µC is recognised, this component freezes the last calculated rotor position value and gives it as input to a PID controller.
   The PID controller provides a motor torque, which is limited to mKLA_MaxMotTq_XDU16 with the target to keep the rotor position constant (keep last angle).
   The torque is applied for the complete activation time (tKLA_Actvn_XDU16), and it is then ramped down to 0 Nm within a fade-out time (tKLA_Fadeout_XDU16). 


   Calibration/Application Parameters
   ==================================

.. only:: confidential

   =======================   ====   ============   ================================================================================
   Parameter Name            Unit   Range          Description
   =======================   ====   ============   ================================================================================
   mKLA_MaxMotTq_XDU16       Nm     0.4..6         Maximum KLA motor torque output
   tKLA_Actvn_XDU16          s      1..4           Activation time of KLA (followed by fade-out time)
   tKLA_Fadeout_XDU16        s      0.001..2       Fade-out time of KLA (after elapsed activation time)
   xKLA_IPart_XDU16          --     0..1           I-part of KLA rotor position controller
   xKLA_PPart_XDU16          --     0..7           P-part of KLA rotor position controller
   xKLA_DPart_XDU16          --     0..5           D-part of KLA rotor position controller
   xKLA_DPartFiltFac_XDU8    --     0.0078125..1   Low-pass filter factor for D-part
   =======================   ====   ============   ================================================================================

.. only:: not confidential

   ======================   ====   ========   ================================================================================
   Parameter Name           Unit   Range      Description
   ======================   ====   ========   ================================================================================
   mKLA_MaxMotTq_XDU16      Nm     0.4..6     Maximum KLA motor torque output
   tKLA_Actvn_XDU16         s      1..4       Activation time of KLA (followed by fade-out time)
   tKLA_Fadeout_XDU16       s      0.001..2   Fade-out time of KLA (after elapsed activation time)
   ======================   ====   ========   ================================================================================

.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: KeepLastAngle_CalMan_VT.irst

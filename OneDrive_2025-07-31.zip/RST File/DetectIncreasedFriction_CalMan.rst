﻿DetectIncreasedFriction
#######################

.. only:: confidential


.. only:: confidential

Short Description
=================
Positive and negative edge of hysteresis is identified from RotorPosition using a hysteresis filter. A valid event is set when proper learning conditions met during a valid event.
Software figures out upper and lower value of torque corresponding to positive and negative hysteresis edge along with upper and lower value of torque, delta time difference between edge detection is fed a to Kalman filter.
Kalman filter provided adapted base friction and load factor load factor ratio provides information about change in load factor to that of an unlearned load factor.

Block Diagram
=============

.. only:: confidential
.. image:: DetectIncreasedFriction_CalMan_BlockDiagram.png

To reduce varying friction levels an adaptive approach is needed. A Kalman filter is able to learn the actual friction value and to make the best fit from the measurement (Limited Motor Torque) and the estimator (estimated friction levels).
At a first step, the task is to write the estimation problem in a way that it fits to the given formula:

y(n) = phi(n)*Theta(n)

Therefore we consider the friction as the the vertical hysteresis. The following picture shows a typical hysteresis (the displayed hysteresis  is a parking maneuver but hysteresis is also present while driving)

.. only:: confidential
.. image:: Hysteresis.png

In the corner of the hysteresis, there is a huge difference between the limited morot torque and the external torque (which is calulated from a real tie rod measurement, a value which is not available in the vehicle).

.. only:: confidential
.. image:: Hysteresis_parameter.png

Remarks:
y(n) amount of friction torque (Limited Motor Torque hysteresis P1-P2), scalar
phi(n) =[P1+P2 ; 2], 2x1 vector, input signal for estimation
P1 represents the torque before the change in the rotor direction
P2 represents the torque afterwards
P3 is the unknown external force calculated into a motor torque
Theta(n) = [Estimated Load Factor; Estimated Base Friction], 2x1 vector
Theta(n) = [ xDetIncFricI_AdaptedLoadFactor_xdu16; mDetIncFricI_AdaptedBaseFriction_xdu16]
Initial values for Theta(n-1) = [{Factor_InitialLoadFactor_DIF} ; {Factor_InitialBaseFriction_DIF}]
e(n) is the estimation error based on measured friction Torque y(n), phi(n) and the previous estimated friction parameters
K(n) is the Kalman Term vector 2x1, with its dependencies:
P(n-1), which describes the Covariance
Initial values for P(n-1) = [{P0_11_initial} {P0_12_initial};{P0_21_initial} {P0_22_initial}]
R(n) describes the accuracy and trust in the previous measurement values respectivly, this scalar value is depending on Absolute Steering Angle:
R(n) = {Variance_R_DIF} * Scaling_R with:
Scaling_R = LuT{Factor_Scaling_R_TimeBetweenEdges_DIF} depending on TimeBetweenEdges  which represents the time between the points P1&P2
Pd is a constant Matrix 2x2 with the values:
Pd = [{Pd_11_DIF} {Pd_12_DIF} ; {Pd_21_DIF} {Pd_22_DIF}];
Pd describes the desired variance and covariance and modifies Q(n) in a way, so that absolute values of Pd-P(n) is minimized.
Q(n) variance matrix for processed signal.

Input Signals
--------------

======================================   ====   ===============================================================================
Signal NameUnit Description              Unit   Description
======================================   ====   ===============================================================================
mApplI_TorsionBarTorque_xds16            Nm     HW LIB: torsion bar torque
sHwlWrapI_TorsionBarTorqueState_xde             HW LIB: torsion bar torque state
mApplI_LimitedMotorTorque_xds16          Nm     limited motor torque
wApplI_RotorPosition_xds32                      HW LIB: integrated, compensated rotorposition
sApplI_SteeringAngleState_xdu8                  steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit, 4=Fallback
vVehSpI_AbsAvgVehSpd_xdu16Kph                   Abs. vehicle speed: processed
wApplI_SteeringAngle_xds16               °      corrected steering angle
======================================   ====   ===============================================================================

Output Signals
---------------

=======================================   ====    ===================================
Signal Name                               Unit    Description
=======================================   ====    ===================================
xDetIncFricI_AdaptedLoadFactor_xdu16              Adapted Load Factor for RackForce
mDetIncFricI_AdaptedBaseFriction_xdu16    Nm      Adapted Base Friction for RackForce
=======================================   ====    ===================================

Measurement Signals
--------------------
=========================================   ====    ===============================================================================================================================
Signal Name                                 Unit    Description
=========================================   ====    ===============================================================================================================================
tDetIncFric_TimeBetweenEdges_xdu16           s      Time between two edges in sec
xDetIncFric_OnlineCalcLoadFactor_xdu16              Online calculated Load Factor for RackForce
mDetIncFric_OnlineCalcBaseFriction_xdu16     Nm     Online calculated Base Friction for RackForce
fDetIncFric_LearnStatus_xdu8                        bit 0 - fDetIncFric_LearnCondOK, bit 1 - fDetIncFric_PosAngGrad, bit 2 - fDetIncFric_NegAngGrad, bit 3 - fTriggerNewCalculation
=========================================   ====    ===============================================================================================================================


Detailed Description
---------------------
The Functionality DetectIncreasedFriction dynamically calculates base friction and load factor by making use of a Kalman filter, when desired learning conditions met.

Base Friction and Load factor are input to RackForce Module and these are further used to calculate the torque dependant on friction.


Calibration/Application Parameters
==================================


.. Please note: the following list of parameters will always be visible in the generated documentation!

=====================================================       ====     ========    ==================================================================================================
Parameter Name                                              Unit     Range       Description
=====================================================       ====     ========    ==================================================================================================
mDetIncFric_MaxAllowedTBT4Learn_XDU16                       Nm       0..8        Max allowed TBT for learning
mDetIncFric_MaxAllowedMMotGrad4Learn_XDU16                  Nm/s     0..63       Max allowed motor torque gradient for learning
wDetIncFric_MaxRotorPos4Learn_XDU16                         °        0..30000    Max allowed RotorPos for learning
vDetIncFric_MaxGradRotorPos_XDU32                           °/s      0..60       Max allowed rotor speed in deg/s to allow learning
vDetIncFric_MinVehSpd4Learn_XDU16                           Kph      0..50       Min vehicle speed for learn
wDetIncFric_OnlineCalibHysteresis_XDU16                     °        0..600      Hysteresis for online calib
vDetIncFric_MinGradRotorPos4EdgeDetection_XDU16                      0..63       Minimal gradient of rotorpos for edge detection
aDetIncFric_MinRotAccAfterTurning4EdgeDetection_XDU16                0..63       Minimal acc of rotorpos for edge detection after turn round
xDetIncFric_Deadzone_y_k_depOnSteeringAngle_XAU16                    0..20       Deadzone of y(k) dependant on Steering Angle
xDetIncFric_RScale_XAU16                                             0..3556     Scaling of R dependant on TimeBetweenEdges
xDetIncFric_VarR_XDF32                                               0..1        Variance R, time independent part
xDetIncFric_Pd11_XDF32                                               0..1        Element 11, Matrix Pd
xDetIncFric_Pd12_XDF32                                               0..1        Element 12, Matrix Pd
xDetIncFric_Pd21_XDF32                                               0..1        Element 21, Matrix Pd
xDetIncFric_Pd22_XDF32                                               0..1        Element 22, Matrix Pd
xDetIncFric_LoadFactor_XDU16                                         0..1        load factor for DetectIncreasedFriction[Nm/Nm] (it should be same as xRackforce_LoadFactor_XDU16)
fDetIncFric_UseDefaultValueLoadFactor_XDU8                           0..1        Flag to use default value of Load Factor (xDetIncFric_LoadFactor_XDU16)
mDetIncFric_BaseFriction_XDU16                               Nm      0..1        Base friction for DetectIncreasedFriction[Nm] (it should be same as mRackForce_BaseFriction_XDU16)
fDetIncFric_UseDefaultValueBaseFriction_XDU8                         0..1        FLag to use default value of Base Friction (mDetIncFric_BaseFriction_XDU16)
fDetIncFric_UseOnlySameSignTorque_XDU8                               0..1        If Set to 1, new calculation is only started if hysteresis torque has same sign
xDetIncFric_P0_11_XDF32                                              0..1        Element 11, Matrix P0
xDetIncFric_P0_12_XDF32                                              0..1        Element 12, Matrix P0
xDetIncFric_P0_21_XDF32                                              0..1        Element 21, Matrix P0
xDetIncFric_P0_22_XDF32                                              0..1        Element 22, Matrix P0
=====================================================       ====     ========    ==================================================================================================


.. include:: DetectIncreasedFriction_CalMan_VT.irst

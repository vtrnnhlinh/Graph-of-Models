Stick Slip Warning V2 Supp
###########################

.. only:: confidential

   .. warning:: The following Description is for internal use only and is rated as **confidential**!
        
        Parts of this confidential description are in the "official" version as well. Have a look in the NON Confidential Manual for a comparison.
        
Short Description
=================
Serves the main part of StickSlipWarningV2 with input signal, regarding RPC-mode.


Block Diagram
=============

Main Function
-------------  
.. image:: StickSlipWarningV2Supp.png
   

Input Signals
-------------

=================================   =====   ========================================================================================
Name                                Unit    Description
=================================   =====   ========================================================================================
No input signals
=================================   =====   ========================================================================================
 

Output Signals
--------------

=======================================   ====   =================================================================================
Signal Name                               Unit   Description
=======================================   ====   =================================================================================
sSSWarnSuppI_RpcStatus_xdu8                      Current status of RPC
=======================================   ====   =================================================================================

    
   
Detailed Description
====================

Currently used project dependant RPC-mode is set by customer project, through this component.

RPC status is represented by enumeration: 0 - SFC 1 - modechange 2 - RPC

If project does not have RPC mode, the mode is fixed to 0 (SFC-mode). 
If needed, the whole enumeration can be used.


Calibration/Application Parameters
==================================

.. note: the following list of parameters will always be visible in the generated documentation!

Currently there are no implemented calibration options, however every customer project has a chance to increase the functional-wise contribution through this component. 
The following initial examples could be set up: time delay between mode changes, direct activation. 
Initially the RpcStatus is driven by 0, considering no RPC mode is applied. 
The corresponding functionality could be implemented based on project needs.

.. include:: StickSlipWarningV2Supp_CalMan_VT.irst

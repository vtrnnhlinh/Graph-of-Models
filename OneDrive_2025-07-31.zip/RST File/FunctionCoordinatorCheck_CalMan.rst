.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

   Function Coordinator Check
   ###########################
   Short Description
   =================

   Checks if the customer specific functions/Addon functions are allowed to act together.

   Input Signals
   -------------

   ================================   ====   ============================================
   Signal Name                        Unit   Description
   ================================   ====   ============================================
   sFctCoI_ChannelStateArray_xau8            Status   Array of the actual channel states
   ================================   ====   ============================================


   Output Signals
   --------------

   =================================   ====   ================================================================================================================================
   Signal Name                         Unit   Description
   =================================   ====   ================================================================================================================================
   sFctCoI_ArbitrationIsValid_xau8            is arbitration valid for this channel?
   sFctCoI_ArbitrationResult_xau8             Arbitration state of the channels:0= Arbitration Not OK; 1= Arbitration OK, Channel Active; 2= Arbitration OK, Channel Passive
   =================================   ====   ================================================================================================================================


   Detailed Description
   --------------------

   Here a check for which customer specific functions/Addon functions are active is done. 
   Then it is verified if the activated channels are allowed to act together.


   Calibration/Application Parameters
   ==================================
   
   ======================================   =====   =====   =======================================================================================
   Parameter Name                           Unit    Range   Description
   ======================================   =====   =====   =======================================================================================
   sFctCo_ParallelActingAllowed_XAU8                0..1    which features are allowed to apply torque in parallel (Continue | ParallelRamping)
   ======================================   =====   =====   =======================================================================================


.. include:: FunctionCoordinatorCheck_CalMan_VT.irst

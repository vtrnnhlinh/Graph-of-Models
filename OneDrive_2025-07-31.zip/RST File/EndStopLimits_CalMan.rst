﻿EndStopLimits
###################

Short Description
=================

EndStopLimits calculates EndstopLeft, EndstopRight and Distance2Endstop in "mm" based on the learned and stored Endstop values (TPO) from NvM.
These values are used in RackPositionControl functionality to limit the final requested rack position and reduce dynamics near end stop area.
The end stop values in degree is used for caluclating the current rack position.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: EndStopLimits.PNG

   Input Signals
   -------------

   =======================================   ==========    ===========    =============================================================================================================
   Signal Name                               Unit          Range          Description
   =======================================   ==========    ===========    =============================================================================================================
   lApplI_RackPosition_xds16                 mm            -200..200      Current Rack Position
   wHwlWrapI_PowerOnSteeringAngle_xdf32      rad           0..2016        True power on steering angle[rad]
   sHwlWrapI_PowerOnSteeringAngleState_xde   n.a           0..32768       State of true power on steering angle
   sApplI_SteeringAngleState_xdu8            n.a           0..4           Steering angle state
   sTesI_LearnRequest_xdu8                   n.a           0..4           EndStop learn request
   mApplI_LimitedMotorTorque_xds16           Nm            -12..12        Limited motor torque from HwLib
   xApplI_GearSign_xds8                      n.a           -1..1          Steering gear sign
   =======================================   ==========    ===========    =============================================================================================================

   Output Signals
   --------------

   =========================================================   =========   ==========   ===============================================================================================
   Signal Name                                                 Unit        Range        Description
   =========================================================   =========   ==========   ===============================================================================================
   lEndStopI_EndstopPosLeft_xds16                              mm          -200..200    Left End stop position in mm
   lEndStopI_EndstopPosRight_xds16                             mm          -200..200    Right End stop position in mm
   lEndStopI_DistanceToEndstop_xds16                           mm          -200..200    Distance to end stop position in mm
   wEndStopI_LearnLeftTPOAngle_xdu16                           deg         0..2016      Left End stop position in degree
   wEndStopI_LearnRightTPOAngle_xdu16                          deg         0..2016      Right End stop position in degree
   =========================================================   =========   ==========   ===============================================================================================

   EndStop Learning
   ----------------

   The learning of the end stops is critical for SRA system, since it is used for calculating the mechanical center which in turn used for calculating
   current rack position.

   The learning of the EndStop in SRA system with TPO sensor (DMS6AD) is done manually via XCP. With XCP a motor torque is applied to move the rack to left and right.
   After the motor hits the end stops, the learning is triggered via XCP (e.g. if the motor torque is given in left direction, then after hitting the endstop,
   the learning of the left end stop is triggered and similarly right end stop is learned).

   After learning the left and right end stops, a safety check is performed. The median of the end stops is checked whether it is in allowed range. If not
   relearning of the end stops should be triggered.

   The motor torque via XCP is directly given to HwLib through TorqueFaderSRA component, overriding the RackPositionControl motor torque.
   The trigger of the learning state via XCP will set the TeachEndStops interface "sTesI_LearnRequest_xdu8". Via XCP it is also possible to reset the end stop
   values to SNA in NvM.

   With the fresh SCU, the initial values of the EndStops will be SNA and monid "MONID_SWE_ENDSTOP" will be logged.

   The learning and storing of the EndStops can be done only once per ignition cycle.

   After learning the new EndStops, the system should be switched off and on. Id.f the EndStops are learned correctly then the monid "MONID_SWE_ENDSTOP" will be cleared.

   If the EndStops are reset to SNA, then in the next ignition cycle, the monid "MONID_SWE_ENDSTOP" will be logged.

   .. warning:: Both EndStopLeft and EndStopRight should be learned at the same routine, learning of any one of the EndStop should be avoided.

   .. warning:: Since the trigger is manual to learn the EndStop, EndStops should be learned for the both the ECU's at the same time.

   =========================================================   ====   ==========   ===============================================================================================
   Signal Name                                                 Unit   Range        Description
   =========================================================   ====   ==========   ===============================================================================================
   sTes_StoreEndStopLearnedAngle_XDU8                          n.a    0..4         0 = Deactivate learning, 1 = Learn Left EndStop, 2 = Learn Right EndStop,
                                                                                   3 = Reset ES to SNA in NvM
   mTes_RequestedMotorTorque_XDU8                              Nm     -12..12      Motor torque request to learn EndStop
   =========================================================   ====   ==========   ===============================================================================================

   Measurement Signals
   -------------------

   =========================================================   ====   ==========   ===============================================================================================
   Signal Name                                                 Unit   Range        Description
   =========================================================   ====   ==========   ===============================================================================================
   sEndStop_LimitsNvWriteState_xdu8                            n.a    0..3         State to trigger NvM write
   zEndStop_JobCallCounter_xdu16                               n.a    0..65535     Job status call counter
   sEndStop_LimitsJobResultOK_xdu8                             n.a    0..2         Status of NvM read and write
   =========================================================   ====   ==========   ===============================================================================================

   Calibration/Application Parameters
   ----------------------------------
   Internal calibration parameters.

   =================================================          ==========   =========     ======================================================================================
   Parameter Name                                             unit         Range         Description
   =================================================          ==========   =========     ======================================================================================
   lEndStop_Offset4Endstop_XDU16                              mm           0..10         Offset to reduce learned endstop
   wEndStop_MaxEndstopAngleDiff_XDU16                         deg          0..2016       Maximum distance between newly learned Endstops
   wEndStop_MinEndstopAngleDiff_XDU16                         deg          0..2016       Minimum distance between newly learned Endstops
   mEndStop_MotTorThreshold_XDU16                             Nm           0..2          Motor torque threshold for learning end stops
   =================================================          ==========   =========     ======================================================================================

.. include:: EndStopLimits_CalMan_VT.irst

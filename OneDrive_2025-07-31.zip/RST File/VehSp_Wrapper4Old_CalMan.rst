VehSp_Wrapper4Old
#################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

Provide the legacy speed signals based on the new signals.


Block Diagram
=============

Temporary wrapper component. No blockdiagram provided.


Input Signals
-------------

==============================   ====   =====================================================================================
Signal Name                      Unit   Description
==============================   ====   =====================================================================================
vVehSpI_AbsAvgVehSpd_xdu16       km/h   Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
vVehSpI_AbsMaxSafeVehSpd_xdu16   km/h   Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
==============================   ====   =====================================================================================


Output Signals
--------------

===================================   ====   =========================================================================================================
Signal Name                           Unit   Description
===================================   ====   =========================================================================================================
sApplI_VehicleRunning_xdu8                   state vehicle running(0 Vehicle stopp, 1 Vehicle is moving)
sApplI_VehicleSpeedState_xdu8                Validflag for vehicle speed vApplI_AbsVehicleSpeedFilt_xdu16 (1 = valid; 0 = invalid or substitute speed)
tVehSp_VehicleRunningTimer_xdu8       ms     Timer for vehicle running detection
vApplI_AbsSafeNssVehicleSpeed_xdu16   km/h   Abs. vehicle speed: Secured near stand still
vApplI_AbsSafeVehicleSpeed_xdu16      km/h   Abs. vehicle speed: Secured over hole vehicle speed range
vApplI_AbsVehicleSpeedFilt_xdu16      km/h   Abs. vehicle speed: processed
vVehSp_LastAbsSafeNssVehSpd_xds16     km/h   Value of vApplI_AbsSafeNssVehicleSpeed_xdu16 in previous cycle
vVehSp_LastAbsVehSpeedFilt_xds16      km/h   Value of vApplI_AbsVehicleSpeedFilt_xdu16 in previous cycle
===================================   ====   =========================================================================================================


Detailed Description
--------------------

Note, this is just a temporary wrapper component, which provides the legacy signals until all
receiving components have been migrated to the new signals.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

==========================================   ====   =========   ==================================================================================================================================================================
Parameter Name                               Unit   Range       Description
==========================================   ====   =========   ==================================================================================================================================================================
aVehSp_MaxNegGradientVAvg_XAU16              km/h   0..3.9844   Max negative gradient of the vehicle speed v_Avg [km/h/10ms]
aVehSp_MaxPosGradientVAvg_XAU16              km/h   0..3.9844   Max positive gradient of the vehicle speed v_Avg [km/h/10ms]
tVehSp_VehicleRunningDelay_XDU8              ms     0..1000     Delay for vehicle running detection
vVehSp_MaxSpeedGradientNearStandStill_XDU8   km/h   0..3.9844   Max gradient for the vehicle speed in near stand still region (km/h/10ms). Has to allow larger changes than the other gradients (i.e. the value has to be larger).
vVehSp_NearStandStillBorder_XDU16            km/h   0..500      Threshold for vehicle near stand still
vVehSp_SubstituteSpeed_XDU16                 km/h   0..500      Substitute value for vehicle speed vApplI_AbsVehicleSpeedFilt
vVehSp_VehicleRunningBorder_XDU16            km/h   0..500      Threshold for vehicle running detection
vVehSp_AbsVehSpeedFiltInit_XDU16             km/h   0..50       Initial value for vehicle speed vApplI_AbsVehicleSpeedFilt
==========================================   ====   =========   ==================================================================================================================================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: VehSp_Wrapper4Old_CalMan_VT.irst

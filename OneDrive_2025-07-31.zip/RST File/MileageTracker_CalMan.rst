Mileage Tracker
###############

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The component Mileage Tracker is used to track how many kilometres that car with EPS steering system is travelled. 
 
Block Diagram
=============
.. image:: MileageTracker_CalMan_BlockDiagram.png

Input Signals
-------------

================================   ====   =====================================================================================
Signal Name                        Unit   Description
================================   ====   =====================================================================================
vVehSpI_AbsAvgVehSpd_xdu16         km/h   Average vehicle speed. Goal: be as close to the actual speed over ground as possible
================================   ====   =====================================================================================


Output Signals
--------------

=================================   ====   ============================================
Signal Name                         Unit   Description
=================================   ====   ============================================
lLdTrkI_KMTravelled_xdu32           m      Distance the steering travelled [1/1000 km]
=================================   ====   ============================================

.. only:: confidential

   ====================================   ====   ========================
   Signal Name [Measurement Signals]      Unit   Description
   ====================================   ====   ========================
   fLdTrk_MileageTrackerJobResultOK_xdb          Flag for NvM read status
   ====================================   ====   ========================


   Detailed Description
   --------------------
   The distance travelled has been calculated by using the actual value of Vehicle Speed signal, and accumulate with previous value stored in dataflash.
   The new value of distance travelled shall be updated to dataflash when the system is shutdown properly. In case that the dataflash storage cannot read 
   to update in current ignition cycle, the distance travelled shall retain the previous value. 
 
   
   Calibration/Application Parameters
   ==================================

   Provide a table of internal calibration parameters.
   
   ==========================================   =====   ==================   ================================================
   Parameter Name                               Unit    Range                Description
   ==========================================   =====   ==================   ================================================
   lLdTrk_MaxDistanceLimit_XDU32                m        0 .. 600000000       Saturation Limit for Maximum Distance Travelled
   ==========================================   =====   ==================   ================================================


.. include:: MileageTracker_CalMan_VT.irst

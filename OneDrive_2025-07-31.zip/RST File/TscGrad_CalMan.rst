TorqueSignalConditioningGradient
################################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component TscGrad calculates the steering torque gradient.

.. only:: confidential

Block Diagram
=============

   .. image:: TscGrad_CalMan_BlockDiagram.png


Input Signals
-------------

=====================================     =======   ==========================================================================================================
Signal Name                               Unit      Description
=====================================     =======   ==========================================================================================================
mHwlWrapI_TorsionBarTorqueRed_xds16       Nm        Torsion bar torque redundant
mHwlWrapI_TorsionBarTorque_xds16          Nm        Torsion bar torque
sHwlWrapI_TorsionBarTorqueState_xde       -         Validity state of the torsion bar torque
vVehSpI_AbsAvgVehSpd_xdu16                km/h      Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
=====================================     =======   ==========================================================================================================
  
.. only:: confidential
  
=====================================     =======   ==========================================================================================================
Signal Name [Internal]                    Unit      Description
=====================================     =======   ==========================================================================================================
tTscI_GradTBTST_xdu16                     us        Time difference of TBT sample times
tTscI_GradTBTSTred_xdu16                  us        Time difference of TBTred sample times
fTscI_TbtSensor_provides_TBTred_xdu8      -         0-no channel exist,1-Backup channel exist
xTscI_PT1tauGradTBT_xdu16                 -         vehicle speed dependant PT1 filter constant GradTBT
fTscI_Use_GradXtplTBT_xdb                 -         flag to use gradient extrapol TBT
mAppll_TorsionBarTorque_xds16             Nm        Torsion bar torque(application layer)
mTscI_HysteresisTBT_xdu16                 Nm        HysteresisTBT: DeadZone TBT Gradient
fTscI_DisAvgBackUpMonFail_xdb             -         Averaging disabled due to Back check fail
=====================================     =======   ==========================================================================================================
	
	
Output Signals
--------------

======================================      =========   ====================================================================================
Signal Name                                 Unit        Description
======================================      =========   ====================================================================================
mApplI_GradTorsionBarTorque_xds16           Nm          gradient of torsion bar torque         
======================================      =========   ====================================================================================

.. only:: confidential

======================================      =========   =============================================================================================================================
Signal Name  [Internal]                     Unit        Description
======================================      =========   =============================================================================================================================
mTsc_HystTorsionBarTorque_xds16             Nm          torsion bar torque(main), hysteresis filtered
mTsc_HystTorsionBarTorqueRed_xds16          Nm          torsion bar torque (redundant), hysteresis filtered
mTsc_FiltGradTBTmain_xds16                  Nm          gradient of (main) torsion bar torque
mTsc_FiltGradTBTred_xds16                   Nm          gradient of torsion bar torque (redundant)
mTsc_HystXtplTorsionBarTorque_xds16         Nm          extrapolated torsion bar torque, hysteresis filtered
mTsc_FiltGradXtplTBT_xds16                  Nm          gradient of extrapolated torsion bar torque
mTsc_AvgFiltGradTBT_xds16                   Nm          average gradient of torsion bar torque filtered
mTsc_FiltGradTBT_xds16                      Nm          either be average filtered gradient TBt or filtered gradient main TBT based on the usage of averaging
======================================      =========   =============================================================================================================================

Detailed Description
--------------------
The component TscGrad calculates a torsion bar torque Gradient (TBTGradient), a torsion bar torque red gradient (TBTredGradient)and Extrapolation of torsion
bar torque Gradient(XpTBTGradient)in their subsystems respectively by passing input signals through first Hysteresis filter and then through PT1 Filter to 
avoid Signal noise ,then the average steering torque gradient is calculated.Apart from PT1 filter, ring buffer based gradient also has been implemented which
can be enable by proper tuning selection.  

.. only:: confidential

Calibration/Application Parameters
==================================


======================================      =========   =========   ============================================================================================================
Parameter Name                              Unit    	Range       Description
======================================      =========   =========   ============================================================================================================
yTsc_Disable_HwlI_TBT_Grad_Avg_XDU8         -           0…1         Averaging of the gradient calucation from each channel
tTscI_NominalTaskTimeDiff_us_XDU16          us          1000…5000   Depending upon the frequency at which the functionality is running,task time diff to be set accordingly
zTsc_TBTDiffDelaySelector_XAU8              -           0…7         Time difference for calculating gradient
vTsc_VehicleSpeedLimit4LowSample_XDU16      km/h        0…500       Speed limit to change the sample points to calculate the grad
vTsc_VehicleSpeedHysteresis_XDU16           km/h        0…15        Vehicle Speed hysteresis for switching the delay selector
======================================      =========   =========   ============================================================================================================

Note
====

yTsc_Disable_HwlI_TBT_Grad_Avg_XDU8-
0 - calculate gradient of individual channels and then take average in gradient caluclation
1 - calculate gradient from prim channel and make it availabe to the final gadient

zTsc_TBTDiffDelaySelector_XAU8 -
When the elements of the array are tuned to 0, the gardient will be calculated out of the PT1 filter.
When tuned other than 0, gradient will be calculated from the circular or ring buffer.
When vVehSpI_AbsAvgVehSpd_xdu16 is greater than vTsc_VehicleSpeedLimit4LowSample_XDU16, 1st element of the zTsc_TBTDiffDelaySelector_XAU8 will be selected 
and when vVehSpI_AbsAvgVehSpd_xdu16 is less than or equal to vTsc_VehicleSpeedLimit4LowSample_XDU16, 0th element of the zTsc_TBTDiffDelaySelector_XAU8 will be selected.
vVehSpI_AbsAvgVehSpd_xdu16 is filtered with hysteresis fiter with hysteresis of vTsc_VehicleSpeedHysteresis_XDU16.
0th and 1st element should have consecutive numbers, like [2,3] or [3,4].

fTscI_Use_GradXtplTBT_xdb -
0 - Gradient will be calculated from the individual torque channel
1 - Gradient will be calculated from the extrapolated and limited tbt

.. include:: TscGrad_CalMan_VT.irst

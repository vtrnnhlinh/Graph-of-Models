Shimmy Compensation Check
#########################


Short Description
=================
This component receives motor torque offset from Shimmy Compensation component, and checks if it is within the safe limits and the corresponding result of the arbitration is passed.
Every failed situation will lead to an immediate 0 Nm torque on the output as a safe reaction.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Input Signals
   -------------
   ================================   ====   ===================================================
   Signal Name                        Unit   Description
   ================================   ====   ===================================================
   mShimmyI_MotorTorque4Check_xds16   Nm     Motor torque Shimmy Compensation for check
   sFctCoI_ArbitrationResult_xau8    		 Is arbitration valid for this channel?
   ================================   ====   ===================================================

   Output Signals
   --------------

   ===================================   ====   =========================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   =========================================================================================
   mShimmyI_DesMotTrqOffset_xds16        Nm     Shimmy Compensation desired motor torque offset
   fShimmyI_MonSafeOk_xdb                       Indicates whether MonitorSafe checks report OK (1) or if they have detected a problem (0)
   ===================================   ====   =========================================================================================
   
   ===================================   ====   =========================================================================================
   Signal Name[Internal]                 Unit   Description
   ===================================   ====   =========================================================================================
   mShimmy_MotorTorqueChecked_xds16      Nm     Shimmy-motortorque checked by MakeSafe. Still needs to be validated by Monitor
   ===================================   ====   =========================================================================================


   Detailed Description
   ====================

   This component performs the safety limitation for the motor torque offset from Shimmy Compensation.
   It deactivates the function until the end of the key cycle  which represents an irreversible behavior within the framework of the key cycle. 
   Otherwise, in a new ignition cycle the sw functionality can work as intended whenever all of the preconditions are fulfilled again.
   
   
   Calibration/Application Parameters
   ==================================

   ================================   ====   =========   ============================================
   Parameter Name                     Unit   Range       Description
   ================================   ====   =========   ============================================
   mShimmy_MaxSafetyMotorTorq_XDU16   Nm     0..0.5      Max. allowed motor torque considering safety
   ================================   ====   =========   ============================================

.. include:: ShimmyCompensationCheck_CalMan_VT.irst

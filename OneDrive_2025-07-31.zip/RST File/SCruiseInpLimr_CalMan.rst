Smart Cruise Signal Processor | Input Limiter
##############################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component limits the received requested rack position, depending on the Vehicle Speed, to avoid jumps in the calculated SCruise Motortorque.
In situations of low Vehicle Speeds higher limits are allowed. In case of high Vehicle Speeds lower limits in the rack position are used.
Also the component is able to slow down the rack speed when the rack position is getting close towards the endstop.


Block Diagram
=============

.. only:: confidential

   .. image:: SCruiseInpLimr_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SCruiseInpLimr_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

.. only:: confidential

   =================================   ======   ====================================================================================================
   Signal Name                         Unit     Description
   =================================   ======   ====================================================================================================
   lSCruiseI_NomRackPosnIntrpn_xds32   mm       Requested Rack Position Interpolated
   lSCruiseI_RackPosn_xds16            mm       SCruise filtered current Rackposition
   sSCruiseI_State_xdu8                Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   vSCruiseI_AbsAvgVehSpd_xdu16        km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   vSCruiseLimrI_RackSpdLim_xdu16      mm/s     max. allowed rack speed checked
   lEndStopI_EndstopPosLeft_xds16      mm       current sw-endstop-position left
   lEndStopI_EndstopPosRight_xds16     mm       current sw-endstop-position right
   lEndStopI_DistanceToEndstop_xds16   mm       distance from end stop
   =================================   ======   ====================================================================================================

.. only:: not confidential

   =================================   ======   ====================================================================================================
   Signal Name                         Unit     Description
   =================================   ======   ====================================================================================================
   lEpsInI_SCruiseReqdRackPosn_xds32   mm       Requested Rack Position
   vSCruiseI_AbsAvgVehSpd_xdu16        km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   =================================   ======   ====================================================================================================


Output Signals
--------------

===============================   ====   =====================================================================================================
Signal Name                       Unit   Description
===============================   ====   =====================================================================================================
lSCruiseI_NomRackPosnLimd_xds32   mm     Nominal rack position for Rack Position Feed Forward (after input limitation)
vSCruise_NomRackSpd_xds32                acceleration limited nominal rack speed which will be used to integrate nominal rack position
===============================   ====   =====================================================================================================

.. only:: confidential

   Detailed Description
   --------------------

   The component has a calibration parameter to disable the use of Input Limiter calculation. In this case the input received from Input Interpolation is fed directly to the output.
   In case of SCruise State is not in FadeIn/Active/Fadeout then we use the lSCruise_RackPosn instead of lSCruiseI_NomRackPosnIntrpn for the calculation.
   The nominal rack position will be limited in a) absolute value, b) speed and c) acceleration via the state variable filter to avoid steps in the nominal rack position.
   Also the component is able to slow down the rack speed if the rack position is getting in a range close towards the endstop witch can be specified with the parameters lSCruise_EndStopBuf_XDU8 and lSCruise_EndStopRedRange_XDU8.
   The limitation in this range is defined by a linear slope falling towards the endstop with a start value of vSCruiseLimrI_RackSpdLim and a final value of vSCruise_TargetRackSpdLim_XDU8.


Calibration/Application Parameters
==================================

.. only:: not confidential

   ===================================   ====   =========   =================================================================================================
   Parameter Name                        Unit   Range       Description
   ===================================   ====   =========   =================================================================================================
   lSCruise_MaxNomRackPosn_XAU16                0..200      max. allowed nominal rack position dependent on vehicle speed
   xSCruise_MaxRackSpdLimFact_XDU8              0.5..2      Factor to apply for rack speed limit to reduce or have a reserve to SCruiseLimiter
   ===================================   ====   =========   =================================================================================================

.. only:: confidential

   ===================================   ====   =========   ====================================================================================================================
   Parameter Name                        Unit   Range       Description
   ===================================   ====   =========   ====================================================================================================================
   fSCruise_EnaInpLimr_XDU8                     0..1        activation of input limitation (absolute and gradient)
   xSCruise_NomRackSpdCutOffFrq_XDU16           0.1..50     cut-off frequency of state variable filter for nominal rack speed to limit the rack speed
   lSCruise_MaxNomRackPosn_XAU16                0..200      max. allowed nominal rack position dependent on vehicle speed
   xSCruise_MaxRackSpdLimFact_XDU8              0.5..2      Factor to apply for rack speed limit to reduce or have a reserve to SCruiseLimiter
   lSCruise_EndStopBuf_XDU8              mm     0..10       Buffer for determining EndStopPosition
   lSCruise_EndStopRedRange_XDU8         mm     0.1..30     Determine the range of distance to end stop to start limiting the rack speed towards endstop direction
   vSCruise_TargetRackSpdLim_XDU8        mm/s   0..10       Parameter to limit the target RackSpeed towards EndPosition direction within a certain range
   ===================================   ====   =========   ====================================================================================================================

   .. include:: SCruiseInpLimr_CalMan_VT.irst

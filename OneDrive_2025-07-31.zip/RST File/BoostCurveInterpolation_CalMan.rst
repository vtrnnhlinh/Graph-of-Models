Boost Curve Interpolation
#########################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The BoostCurveInterpolation realize the calculation of the basic steer torque curve. This curve describes the nominal steering torque in dependence of the rack force.
The calculation is done considering the vehicle speed and the basic steer torque postscaler value.

The function realize also the calculation of the assistance torque curve. This curve describes the assistance torque in dependence of torsion bar torque. The assistance torque curve
is based on the basic steer torque curve and calculated considering the (steering angle dependent) steering ratio and the rack force to motor ratio.

The assistance torque curve is used by the component Assistance. As the assistance function calculates
the assistance torque as a component of the motor torque in dependence upon the steering torque and the vehicle speed, the application of the BoostCurveInterpolation is therefore
responsible for the assistance level and the steering feeling.

Finally, the limitation curve of the MotorTorqueLimiter is based on the assistance torque curve.

System Overview
===============
Component BoostcurveInterpolation is responsible for calculation the current assitance torque curve and the basic steer torque curve out of the calibrated dataset, with respect to the
vehicle speed.Both curves are inputs to the steering controller (RG3) and therefore responsible for steering assistance and the steering feeling. The steering controller calculates
the nominal motor torque.

The assistance torque curve is also an input to the MotorTorqueLimiter used as the basis for the current limitation curve. The MotorTorqueLimiter limits
the nominal motor torque to values defined by the limitation curve, considering the driving situation (e.g. current steering torque, vehicle speed). The limited motor torque is passed
to the motor control (FOC).

AddOn-functions may additionally request a steering torque offset and/or an motor torque offset. An steering torque offset can be considered within MTL (by shifting the limiter curve x-axis),
but motor torque offsets has to be secured separately (ASIL D), if they are bypassing the MotorTorqueLimiter.




Block Diagram
=============

.. image:: BoostCurveInterpolation_CalMan_BlockDiagram.png

Input Signals
-------------

===================================   ====   ============================================
Signal Name                           Unit   Description
===================================   ====   ============================================
vApplI_AbsSafeNssVehicleSpeed_xdu16   kph    Absolute safe vehicle speed near stand still
xFctCoI_AssistPostscaler_xdu16               Factor on requested torque after Assist/BST
wApplI_SteeringAngle_xdu16            °      steering angle
sApplI_SteeringAngleState_xdu8               steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit)
===================================   ====   ============================================


Output Signals
--------------

====================================   ====   ============================================================
Signal Name                            Unit   Description
====================================   ====   ============================================================
kBciI_BSTCurveRackForceXAxis_xau16      N     Actual basic steer torque curve (x-axis, rackforce)
mBciI_BSTCurveSteerTorqueYAxis_xau16   Nm     Actual basic steer torque curve (y-axis, torsionbar torque)
mBciI_AssistCurveTBTXAxis_xau16        Nm     Actual assistance torque curve (x-axis, torsionbar torque)
mBciI_AssistCurveMMotYAxis_xau16       Nm     Actual assistance torque curve(y-axis, motor torque)
====================================   ====   ============================================================


Detailed Description
--------------------
The component consists of several parts:
  1. Interpolation of basic steer torque curve (raw)
     The function is responsible for the interpolation of the actual basic steer torque curve (raw) out of a set of calibrateable vehicle speed dependent characteristics.
  2. Basic Steer Torque Curve Calculation:
     Calculation of the basic steer torque curve out of the interpolated basic steer torque curve (raw) and calculation of the assistance torque curve.
     The curves are calculated considering the assist scalers (see below)), a vehicle speed dependent maximum rackforce and the safety limitation parameters (see below).
  3. Safety limitation of assist scaler (Postscaler)
     The assist scaler is limited to a minimum and maximum value. If the input values change, the limited values changes regarding a maximum allowed gradient.
     There is a deadband zone defined, where no gradient limitation is done.
  4. Safety limitation of basic steer torque curve
     To avoid an extensive oversteering, the rescaled basic steer torque curve is limited to a minimum required torsionbar torque level.
     If the basic steer torque curve is below a calibrateable torsionbar torque level, it will be shiftet up to a defined safety limitation level. This safety limitation works from
     an calibrateable vehicle speed limit up to maximum vehicle speed.
  5. Level2 monitoring of the calculation of the assistance torque curve.
     As the assistance torque curve is input to the MotorTorqueLimiter, a level2 monitoring of its calculation is necessary to ensured assistance torque curve is calculated correct.
     This calculation is done by a backward calculation from the resulting assistance torque curve to a expected basic steer torque curve and the comparison of that curve with the
     interpolated one.



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

Curve Calcualtion parameters
----------------------------

=====================================   =====   =========== ====================================================================================
Parameter Name                           Unit   Range       Description
=====================================   =====   =========== ====================================================================================
zBci_BaseTorqueCharSelect_XAS16          kph    0 .. 500    selection of vehicle speed dependent characteristic curves
mBci_V0BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v0
mBci_V1BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v1
mBci_V2BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v2
mBci_V3BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v3
mBci_V4BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v4
mBci_V5BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v5
mBci_V6BaseTorque_XAS16                  Nm     0 .. 15     nominal basic steering torque depending on rack force v6
kBci_MaxRackForceOnVehicleSpeed_XAU16    N      0 .. 30000  vehicle speed dependend maximum rack force for basic steer torque curve calculation
kBci_MaxRackForce_XDU16                  N      0 .. 30000  maximum rack force for basic steer torque curve calculation
mBci_MaxAssistanceTorque_XDU16           Nm     0 .. 12     maximum assistance torque for assist curve calculation
=====================================   =====   =========== ====================================================================================

Assist scaler Calcualtion parameters
------------------------------------

============================================   =======   ===========      ======================================================================================================
Parameter Name                                  Unit      Range           Description
============================================   =======   ===========      ======================================================================================================
xBci_MaxAssistPostscaler_XDU16                           1 .. 2           maximum allowed postscaler value
xBci_MinAssistPostscaler_XDU16                           0.2 .. 1         minimum allowed postscaler value
xBci_MinAssistXxxscalerNoGradient_XDU16                  0.2 .. 1         postscaler lower limit of no gradient limitation area
xBci_MaxAssistXxxscalerNoGradient_XDU16                  1 .. 2           postscaler upper limit of no gradient limitation area
xBci_MaxGradAssistXxxscalerOnExceeding_XDU16   %/10ms    0.001 .. 2       postscaler maximum gradient if scaler value moves away from no gradient limitation area
xBci_MaxGradAssistXxxscalerOnEntering_XDU16    %/10ms    0.001 .. 2       postscaler maximum gradient if scaler value moves towards no gradient limitation area
============================================   =======   ===========      ======================================================================================================

Safety Limiter Calcualtion parameters
-------------------------------------

============================================   =====   ===========  ================================================================================================================
Parameter Name                                 Unit    Range        Description
============================================   =====   ===========  ================================================================================================================
zvBci_SafetyLimiterMinSpeed_XDU16              kph     0 .. 500     vehicle speed limit for safety limitation of boost curve against very easy motion
kBci_SafetyLimiterMinRackForce1_XDU16          N       0 .. 30000   rack force threshold for safety limitation of torsion bar torque to mBci_SafetyLimiterMinTorsionBarTorque1_XDU16
mBci_SafetyLimiterMinTorsionBarTorque1_XDU16   Nm      0 .. 15      minimum torsion bar torque, that is required at kBci_SafetyLimiterMinRackForce1_XDU16
kBci_SafetyLimiterMinRackForce2_XDU16          N       0 .. 30000   rack force threshold for safety limitation of torsion bar torque to mBci_SafetyLimiterMinTorsionBarTorque2_XDU16
mBci_SafetyLimiterMinTorsionBarTorque2_XDU16   Nm      0 .. 15      minimum torsion bar torque, that is required at kBci_SafetyLimiterMinRackForce2_XDU16
============================================   =====   ===========  ================================================================================================================

Level2 monitoring parameters
----------------------------
=============================================   =====   ===================  ===============================================================================================================================================================
Parameter Name                                  Unit    Range                Description
=============================================   =====   ===================  ===============================================================================================================================================================
kBci_MaxRackForceOnVehicleSpeed_XAF32           N       0 .. 30000           vehicle speed dependend maximum rack force for basic steer torque curve calculation(shall be identical to the values of kBci_MaxRackForceOnVehicleSpeed_XAU16)
xBci_InvSteeringRatioVarFact_XAF3                       0.0009765625 .. 2    factor for adaptation of variable ratio - level2(shall be identical to the values of xsyInvSteeringRatioVarFact_XAU16)
fBci_Level1CheckActivated_XDU8                          0 .. 1               Switch to deactivate compare of backward calculated BasisSteerTorque-curve on Level2 (integer): 0=disabled 1=enabled(shall be enabled)
fBci_Level2CheckActivated_XDU8                          0 .. 1               Switch to deactivate compare of backward calculated BasisSteerTorque-curve on Level2 (float): 0=disabled 1=enabled(shall be enabled)
=============================================   =====   ===================  ===============================================================================================================================================================



.. only:: confidential

   Internal calibration parameters
   -------------------------------

   ===================================================== =====   ============  ==================================================================================
   Parameter Name                                        Unit    Range         Description
   ===================================================== =====   ============  ==================================================================================
   xsyNoEffDepEngTorqueToRackForce_XDU16                 N/Nm    1 .. 5000     Factor from Engine Torque to Rack Force without efficiency
   jsyInvSteeringRatio_XDU16                                     900 .. 3000   1/steeringratio * 2^15
   msyAbsTorsionBarTorque_XDU16                          Nm      3 .. 10       Absolute steering torque limit
   mBci_ErrorInjectionMotorTorqueOnAssistChar_XAS16      Nm      -1 .. 1       Motortorque offset on Assist-curve for testing the Level2-check (test switch)
   mBci_ErrorInjectionTorsionBarTorqueOnAssistChar_XAS16 Nm      -1 .. 1       Torsionbartorque offset on Assist-curve for testing the Level2-check (test switch)
   ===================================================== =====   ============  ==================================================================================


.. include:: BoostCurveInterpolation_CalMan_VT.irst

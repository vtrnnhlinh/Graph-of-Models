FltMan Input Adapter Dual UcSymm
################################

Short Description
=================

The FltManInputAdapter component maps the following HardwareLib signals into an event list based on the actual status of the signals.

.. only:: confidential

   Block Diagram
   =============

   .. image:: FltManInputAdapterDualUcSymm_CalMan_BlockDiagram.png


Input Signals
-------------

.. only:: confidential

   ===================================   ====   =========================================================================================================
   Signal Name [for internal usage]                         Unit   Description
   ===================================   ====   =========================================================================================================
   sFltManI_MonSafeOk_xdb                       Indicates whether the MonitorSafe checks report OK (1) or if they have detected a problem (0).
   sHwlWrapI_ActuatorState_xde                  HwLib Actuator State
   sHwlWrapI_ChipsetSafetyFault_xde             HwLib Chipset SafetyFault State
   sHwlWrapI_RotorPositionState_xde             HwLib Rotor Position State
   sHwlWrapI_BoardTempState_xde                 HwLib Board Temp State
   sHwlWrapI_TorsionBarTorqueState_xde          HwLib TorsionBar Torque State
   sHwlWrapI_SystemVoltageState_xde             HwLib System Voltage State
   sHwlWrapI_PhaseCurrentState_xde              Status of the phase current measurement
   sHwlWrapI_UcTempState_xde                    HwLib Uc Temp State
   yIpcInI_PsEn_xdb                             Power Stage enable Status . Values are 0-Disabled,1-Enabled.
   yIpcInI_RemoteFaultMode_xdu8                 Remote Fault Mode obtained from HwLib Interface yHwlI_RemoteSyncMessage_gau32 . Values are 0-Init,1- Healthy,2-Disabled,3-Exclusive,4-SNA
   yIpcInI_IntConnCommState_xdu8				Power Stage enable Status . Values are 0-Init,1-Valid,2-MsgFailing,3-MsgFailed,4-LineFailing, 5-LineFailed
   ===================================   ====   =========================================================================================================


Output Signals
--------------

.. only:: confidential

   ===================================   ====   ================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ================================================================================================
   sFltManI_Events_xau8                         An array of error events. 0-No Error, 1- Error
   ===================================   ====   ================================================================================================

Detailed Description
--------------------
The FltManInputAdapter component maps HardwareLib signals such as ActuatorState, ChipsetSafetyFault, RotorPositionState, BoardTempState, TorsionBarTorqueState, 
SystemVoltageState and Sw Error Levels into an event list based on the actual status of the signals.


.. include:: FltManInputAdapterDualUcSymm_CalMan_VT.irst

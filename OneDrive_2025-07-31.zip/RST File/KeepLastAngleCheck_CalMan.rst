Keep Last Angle Check
######################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component limits the output motor torque of Keep Last Angle to a controllable value. 
Furthermore in case of a driver intervention indication the motor torque output will be set to 0Nm to hand-over to the driver.

.. only:: confidential

   Block Diagram
   =============
   .. image:: KeepLastAngleCheck_CalMan_BlockDiagram.png

.. only:: confidential

   Input Signals
   -------------

   ================================   ====   ======================================================================
   Signal Name                        Unit   Description
   ================================   ====   ======================================================================
   mApplI_TorsionBarTorque_xds16      Nm     HW LIB: torsion bar torque
   mKLAI_NomMotTq4Chk_xds16           Nm     Nominal motor torque request for check of keep last angle calculation
   sFltManI_EcuChannelStateReq_xdu8          GDU control request
   ================================   ====   ======================================================================


Output Signals
--------------

.. only:: confidential

   =========================================================   ====   ====================================================================================================
   Signal Name                                                 Unit   Description
   =========================================================   ====   ====================================================================================================
   fKLA_EmgyEveIndcn_xdb                                              Emergency event due to high torsion bar torque indicated
   mMotTorLimI_ValidatedMotorTorque_xds16                      Nm     Limited KLA motor torque request on Backup µC
   tKLA_ElpdDeadTiTbt_xdu8                                     s      Elapsed dead time of TBT evaluation after transition from Main to Backup ECU
   tKLA_EmgyEveIndcnTmr_xdu8                                   s      Debounce timer of emergency event indication
   =========================================================   ====   ====================================================================================================

.. only:: not confidential

   ======================================   ====   ====================================================================================================
   Signal Name                              Unit   Description
   ======================================   ====   ====================================================================================================
   mMotTorLimI_ValidatedMotorTorque_xds16   Nm     Limited KLA motor torque request on Backup µC
   ======================================   ====   ====================================================================================================


.. only:: confidential

   Detailed Description
   --------------------

   This component checks whether the KLA motor torque request does not exceed the calibrated maximum torque the requested motor torque is set to 0Nm.
   Furthermore the steering torque is evaluated once a deadtime after the Backup µC activation is elapsed. This deadtime is integrated to filter out
   possible steering torque peaks due to a short motor torque interruption while switching from the Main µC to the Backup µC. In case the
   steering torque exceeds its threshold for the debounce time, KLA is aborted and the motor torque request is set to 0Nm.
   The driver has to take over the control supported by LoAP.
   The steering torque threshold to deactivate KLA shall be set to the threshold of LoAP activation.

.. only:: confidential

   Calibration/Application Parameters
   ==================================

   =============================   ====   ========   ==============================================================================================================================================================
   Parameter Name                  Unit   Range      Description
   =============================   ====   ========   ==============================================================================================================================================================
   mKLA_MaxMotTq_XDU16             Nm     0.4..6     Maximum KLA motor torque output
   mKLA_TbtThdEmgyEveIndcn_XDU16   Nm     0..15      TBT threshold to start emergency event debouncing. Shall be calibrated to threshold of LoAP activation.
   tKLA_DeadTiTbt_XDU8             s      0..0.25    Deadtime of the TBT evaluation applied after the transition from Main to Backup ECU to prevent false emergency indications caused by the transition itself [s]
   tKLA_DebTmrEmgyEveIndcn_XDU8    s      0..0.1     Debouncing time to detect an emergency event [s]
   =============================   ====   ========   ==============================================================================================================================================================


.. include:: KeepLastAngleCheck_CalMan_VT.irst

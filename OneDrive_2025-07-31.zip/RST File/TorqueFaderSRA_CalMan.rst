﻿TorqueFaderSRA
###################

Short Description
=================

The component TorqueFaderSRA coordinates between different requested motor torques and calculates the final requested motor torque which is send to HwLib.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: TorqueFaderSRA.png

   Input Signals
   -------------

   ======================================    ==========    ===========    =============================================================================================================
   Signal Name                               Unit          Range          Description
   ======================================    ==========    ===========    =============================================================================================================
   mRPCI_NominalMotorTorque_xds16            Nm            -12..12        RPC Nominal Requested Motor Torque
   SY_PRODUCTION                             -             0..1           Production flag
   mTesI_NominalMotorTorque_xds16            Nm            -12..12        Teach End Stop Nominal Requested Motor Torque
   fTesI_Activate_xdu8                       -             0..1           Teach End Stop Flag
   ======================================    ==========    ===========    =============================================================================================================

   Output Signals
   --------------

   =========================================================   =========   ==========   ===============================================================================================
   Signal Name                                                 Unit        Range        Description
   =========================================================   =========   ==========   ===============================================================================================
   mFadrI_NominalMotorTorque_xds16                             Nm          -12..12      Requested Motor Torque to Hwlib
   sFadrI_Mode_xdu8                                            -           0..2         Torque Fader Mode. 0 - TorqueFader RPC; 1- TorqueFader TeachEndStop; 2- TorqueFader Fade
   =========================================================   =========   ==========   ===============================================================================================

.. include:: TorqueFaderSRA_CalMan_VT.irst

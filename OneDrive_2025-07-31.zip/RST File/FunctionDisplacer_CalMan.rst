Function Displacer
##################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

FunctionDisplacer deactivates/disables the "comfort functions"  (APC, DSR, etc.; AddOn functions) depending on the current ECU state.

.. only:: confidential

   Block Diagram
   =============
   .. image:: FunctionDisplacer_CalMan_BlockDiagram.png

Input Signals
-------------

======================   ====   ======================
Signal Name              Unit   Description
======================   ====   ======================
sApplI_EcuState_xdu8            Ecu safe state
======================   ====   ======================

.. only:: confidential

   ==========================   ====   ======================
   Signal Name                  Unit   Description
   ==========================   ====   ======================
   fFuncDisplI_MonSafeOk_xdb           Indicates whether MonitorSafe checks report OK (1) or if they have detected a problem (0)
   ==========================   ====   ======================

Output Signals
--------------

===================================   ====   ==============================================
Signal Name                           Unit   Description
===================================   ====   ==============================================
mFuncDisplI_MotorTorque4Check_xds16   Nm     The motor torque offset that shall be checked
===================================   ====   ==============================================

.. only:: confidential

   ===================================   ====   ==============================================
   Signal Name [Internal]                Unit   Description
   ===================================   ====   ==============================================
   sFuncDispl_FeatureState_xdu8                 FunctionCoordinator state for FunctionDisplacer
   sFuncDispl_FctCoCtrlState_xdu8               Return value of the Function Coordinator
   fFuncDispl_Activate_xdb                      Indicates whether Function Displacer shall actively calculate and request a torque.
   ===================================   ====   ==============================================


Detailed Description
--------------------
The function checks the EcuState( = FailOp) and dispalces the other add-on functions, once function displacer is active it is not possible for the other Add-on functions to move into "Active" state unless function displacer is deactivated.
Based on the Enablevibration tuning value status, a vibration torque with an amplitude of +/- MaxAllowedVibrationTorque and with a pre-configured netural frequency of 25Hz will be sent via MotorTorque4Check sender.

Calibration/Application Parameters
==================================
=======================================   =====   ======   =====================================================
Parameter Name                            Unit    Range    Description
=======================================   =====   ======   =====================================================
mFuncDispl_MaxAllowedVibrationTrq_XDU16   Nm      0..0.5   The maximum allowed motor torque
fFuncDispl_EnableVibration_XDB                    0...1    FunctionDisplacer-Vibration activation 0=off, 1=on
=======================================   =====   ======   =====================================================

.. include:: FunctionDisplacer_CalMan_VT.irst


.. only:: not confidential

   Smart Cruise Fading
   ###################

   Short Description
   =================

   The functionality is responsible to ensure the correctness of the functionality SCruise Fading

   Input Signals
   -------------

   ====================================   ======   ===============================================================================================================================
   Signal Name                            Unit     Description
   ====================================   ======   ===============================================================================================================================
   sSCruiseI_State_xdu8                   Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   sEpsInI_SCruiseReqdState_xdu8                   SCruise requested state: 0=Off, 1=HandsOn, 2=HandsFree, 3=Parking, 4=HandsOnInc
   tEpsInI_SCruiseCmftFadeOutTi_xdu16     s        SCruise fade out time comfort fading (SFC<=SCI)
   mSCruiseLimrI_MotTrq_xds16             Nm       SCruise Limiter Motor Torque
   mTrqSumI_MotTrqSum1_xds16              Nm       summation of all input motor torques of main connector
   vVehSpI_AbsMaxSafeVehSpd_xdu16         km/h     Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd
   ====================================   ======   ===============================================================================================================================

   Output Signals
   --------------

   ==============================   ======   ========================================================================================================================================================
   Signal Name                      Unit     Description
   ==============================   ======   ========================================================================================================================================================
   mSCruiseFadrI_MotTrq_xds16       Nm       faded motor torque
   sSCruiseFadrI_State_xdu8         Status   FaderState (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=ERR)
   xSCruiseFadrI_Prgs2SCI_xdu16              Factor indicates fading progress (0=SFC; 1=SCI)
   ==============================   ======   ========================================================================================================================================================

.. only:: confidential

   Smart Cruise Fading | Check
   ###########################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   The functionality is responsible to ensure the correctness of the functionality SCruise Fading.

   This component monitors the fading process of the desired fading factor based on a gradient tolerance range band as well as the fader state.
   In case the component detects an error a monitoring flag is set and the MONID_SCRUISEFADER_CHK is reported.
   The component maps the valid actual torque and status to the corresponding outputs dependent on the actual state of the component Fader.
   In case of monitoring error, a replacement torque (mSCruiseFadr_ReplcmtTrq_xds16) and replacement progress (xSCruiseFadr_ReplcmtPrgs_xdu16) are calculated and set as output.


   Block Diagram
   =============

   .. image:: SCruiseFaderChk_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ====================================   ======   ============================================================================================================================================================================================================================================================================================
   Signal Name                            Unit     Description
   ====================================   ======   ============================================================================================================================================================================================================================================================================================
   fSCruiseFadrI_EmgyEveIndcn_xdb                  Emergency event due to high torsion bar torque indicated
   fSCruiseLimrI_MonSafeOk_xdb                     Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   lSCruiseI_RackPosn_xds16               mm       SCruise filtered current Rackposition
   lSCruiseI_ReqdRackPosn_xds32           mm       Requested Rackposition for SCruise from Bus, mapped to internally
   mSCruiseLimrI_MotTrq_xds16             Nm       SCruise Limiter Motor Torque
   mTrqSumI_MotTrqSum1_xds16              Nm       summation of all input motor torques of main connector
   sFctCoI_ArbitrationResult_xau8                  Arbitration state of the channels :0= Arbitration Not OK; 1= Arbitration OK, Channel Active; 2= Arbitration OK, Channel Passive
   sSCruiseFadrI_Reas_xdu8                         Fading reason of unexpected FadeOut or suppressed FadeIn: Bit0=ExtReq, Bit1=SCruiseState, Bit2=EMGY_DII
   sSCruiseFadrI_St4Chk_xdu8              Status   Desired state of Scruise Fader to be read by Check component only (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=SCI2SFCPND)
   sSCruiseI_CnclCdn_xdu16                         Cancel conditions indicating why active control mode of statemachine cannot be reached: Bit0=RedLvlTooLo, Bit1=FctCoOverruled, Bit2=SigInvld, Bit3=CtrlErr, Bit4=LimrErr, Bit5=FaderErr, Bit6=FaderEmgcy, Bit7=EcuSt, Bit8=VehSpd, Bit9=BlkdSteer, Bit10=SigPrcrReqOff, Bit11=SteerTrqReqOff
   sSCruiseI_ReqdState_xdu8               Status   Requested State for SCruise from Bus, mapped to internally. 0-Inactive, 1-HandsOn, 2-HandsFree, 3-Parking, 4=HandsOnInc
   tEpsInI_SCruiseCmftFadeOutTi_xdu16     s        SCruise fade out time comfort fading (SFC<=SCI)
   tSCruiseFadrI_FadeOutPndRmngTi_xds16   s        Remaining time in Fader state Pending before fade out starts (SFC <= SCI)
   vSCruiseI_RackSpd_xds32                mm/s     PT2 filtered rack speed [mm/s]
   vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16   km/h     Maximum vehicle speed
   xApplI_GearSign_xds8                            sign of the steering gear
   xSCruiseFadrI_Fac4Chk_xdu16                     Desired fading factor (0=SFC; 1=SCI) of Scruise Fader to be read by Check component only
   ====================================   ======   ============================================================================================================================================================================================================================================================================================


   Output Signals
   --------------

   =========================================   ======   =======================================================================================================
   Signal Name                                 Unit     Description
   =========================================   ======   =======================================================================================================
   fSCruiseFadrI_MonSafeOk_xdb                          Indicate whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   fSCruiseFadr_DebDetdErrDly_xdb                       Indicates the delayed value of debouncing detected error
   lSCruiseFadr_ReqdRackPosnLimd_xds32                  Rate limited requested rack position
   mSCruiseFadrI_MotTrq_xds16                  Nm       faded motor torque
   mSCruiseFadr_IReplcmtCtrlrTrq_xds32                  I-part of the replacement controller rack speed cascade [Nm]
   mSCruiseFadr_PReplcmtCtrlrTrq_xds16         Nm       I-part of the replacement controller rack speed cascade
   mSCruiseFadr_ReplcmtTrq_xds16               Nm       Replacement torque in case of a MonSafeOk
   sSCruiseFadrI_State_xdu8                    Status   FaderState (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=SCI2SFCPND; 6=REPLCMT; 7=ERR)
   sSCruiseFadr_MonSafeErr_xdu16                        Error state indicating which Fader monitoring is currently active
   vSCruiseFadr_NomReplcmtCtrlrRackSpd_xds16   mm/s     Nominal rack speed of the replacement controller cascade
   xSCruiseFadrI_Prgs2SCI_xdu16                         Factor indicates fading progress (0=SFC; 1=SCI)
   xSCruiseFadr_ReplcmtPrgs_xdu16                       Progress of replacement function: 1 = Damping ongoing; 0 = Damping Done (SFC)
   zSCruiseFadr_CntrReplcmtCtrlrActive_xdu16   s        Replacement controller activation timer
   =========================================   ======   =======================================================================================================


   Detailed Description
   --------------------

   See SCruiseFading Main.

   Replacement measure controller:
   The controller is used to calculate a replacement torque in order to follow the desired trajectory (lSCruiseI_ReqdRackPosn_xds32) which is rate limited to (vSCruiseLimr_MaxRackSpdHandsFree_XAU16).
   The target rack position (lSCruiseI_ReqdRackPosn_xds32) is initialized with the current rack position (lApplI_RackPosition_xds16) as long as no monitoring failure occurs.
   After a monitoring event has occurred the the current rack position will be ramped to the requested rack position with a rate of (vSCruiseLimr_MaxRackSpdHandsFree_XAU16).

   It has an outer P-Part Rackposition controller based on the rack position deviation between the requested (lSCruiseI_ReqdRackPosn_xds32) and current (lSCruiseI_RackPosn_xds16) rack position.
   The output is a requested rack speed. The rack speed deviation compared to the current rack speed (vSCruiseI_RackSpd_xds32) is input to a PI Rackspeed controller to calculate the output
   replacement motor torque. The replacement motor torque is applied for a defined time (tSCruiseFadr_HandsFreePndTi_XDU8) or can be kept active forever using the parameter fSCruiseFadr_KeepReplCtrlrActv_XDB.
   After the time has elapsed the replacement motor torque is faded out to SFC motor torque (mTrqSumI_MotTrqSum1_xds16) based on the replacement progress (xSCruiseFadr_ReplcmtPrgs_xdu16).
   The replacement progress is faded out based on a defined time (tSCruiseFadr_ReplcmtFadeOutTime_XDU16).
   If a driver intervention is detected (fSCruiseFadrI_EmgyEveIndcn_xdb) then the fade out time is tSCruiseFadr_EmgcyFadeOutTime_XAU16.

   In case of invalid current rack position during the replacement controller activation time, the requested rack speed (vSCruiseFadr_NomReplcmtCtrlrRackSpd_xds16) = 0 mm/s to prevent the rack position from deviating.
   After a certain time threshold (Replacement controller time > tSCruise_DlyCntrThdRstReqRackPosn_XDU16)
   and the calibration flag to reset request rack position is set (fSCruise_RstReqRackPosnEna_XDB)
   and the rate limited requested rack position is above the threshold (lSCruiseFadr_ReqdRackPosnThdEnhdKLA_XDU8) KLA enhanced is activated.
   In KLA enhanced requested rack speed calculated based on the formula:
   vSCruiseFadr_NomReplcmtCtrlrRackSpd_xds16 = -1* sign (lSCruiseFadr_ReqdRackPosnLimd_xds32) * vSCruiseLimr_MaxRackSpdHandsFree_XAU16.

   In case of invalid requested rack position during the replacement controller, the requested rack position is substituted to 0mm and the replacement controller tries to bring to the center position.
   If a driver intervention is detected (fSCruiseFadrI_EmgyEveIndcn_xdb) then the fade out time is tSCruiseFadr_EmgcyFadeOutTime_XAU16.

   In case of invalid current rack speed during the replacement controller, Switch directly to SFC by setting the replacement progress to 0.
   Invalid rack speed should not be possible (defensive programming) but would lead to not working controller and possible UAF.

   Calibration/Application Parameters
   ==================================

   ===========================================   ==========   ==========   ================================================================================================================================
   Parameter Name                                Unit         Range        Description
   ===========================================   ==========   ==========   ================================================================================================================================
   fSCruiseFadr_KeepReplCtrlrActv_XDB            Bitanzeige   0..1         Keep ReplCtrlr active independent from HandsFreePndTi - just for testing purpose
   fSCruise_RstReqRackPosnEna_XDB                Bitanzeige   0..1         Flag to enable reseting of Requested Rack Position 1: Enabled 0: Disabled
   lSCruiseFadr_ReqdRackPosnThdEnhdKLA_XDU8      mm           0..30        Threshold of requested rack position to activate enhanced KLA for repacement controller in case of invalid current rack position
   tSCruiseFadr_EmgcyFadeOutTime_XAU16           s            0.001..1     Emergency fade out time in case of DII (SCI -> SFC)
   tSCruiseFadr_FadeInTime_XDU16                 s            0.001..5     Fade in time (SFC -> SCI)
   tSCruiseFadr_FadeOutTime_XDU16                s            0.001..6.2   Fade out time (SCI -> SFC)
   tSCruiseFadr_HandsFreePndTi_XDU8              s            0.5..4       SCruise pending time before fade out in HandsFree mode
   tSCruiseFadr_HandsOnIncPndTi_XDU8             s            0.1..4       SCruise pending time before fade out in HandsOnInc mode
   tSCruiseFadr_HandsOnPndTi_XDU8                s            0.1..4       SCruise pending time before fade out in HandsOn mode
   tSCruiseFadr_PrkgPndTi_XDU8                   s            0..4         SCruise pending time before fade out in Parking mode
   tSCruiseFadr_ReplcmtFadeOutTime_XDU16         s            0.001..6.2   Replacement torque fade out time (SCI -> SFC)
   tSCruise_DlyCntrThdRstReqRackPosn_XDU16       s            0.001..4     Time threshold to reset the Resqested Rack Position in advanced Fadeout
   vSCruiseLimr_MaxRackSpdHandsFree_XAU16        mm/s         0..249       maximum allowed rack speed while HandsFree is active (dependent on vehicle speed)
   xSCruiseFadr_IPartRackSpdReplcmtCtrlr_XDU16                0..1         I-Part Gain of replacement controller rack speed cascade
   xSCruiseFadr_PPartRackPosReplcmtCtrlr_XDU16                0..125       P-Part Gain of replacement controller rack position cascade
   xSCruiseFadr_PPartRackSpdReplcmtCtrlr_XDU16   1            0..7.5       P-Part Gain of replacement controller rack speed cascade
   ===========================================   ==========   ==========   ================================================================================================================================

   The parameter MaxRackSpdHandsFree_XAU16 is defined in SCruiseMaxRackSpd.


   .. include:: SCruiseFaderChk_CalMan_VT.irst

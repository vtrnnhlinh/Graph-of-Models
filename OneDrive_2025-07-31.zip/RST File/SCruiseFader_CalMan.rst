.. only:: not confidential

   Smart Cruise Fading | Main
   ##########################

   This component is responsible for determining how slow or fast the fading process should take place between SCI and SFC (normal steering) motor torque.

.. only:: confidential

   Smart Cruise Fading | Main
   ##########################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================
   This component SCruiseFader implements the state machine that determines the state and the reason for the unexpected fadeout or suppressed fadein.
   These interfaces are used in SCruiseFaderChk component where these interfaces will be overwritten only in case of monitoring issue

   Functional Diagram
   ==================
   State machine:

   .. image:: SCruiseFader_CalMan_StatesOverview.drawio.png

   Factor calculation:

   .. image:: SCruiseFader_CalMan.drawio.png


   Input Signals
   -------------

   ==================================   ======   ============================================================================================================================================================================================================================================================================================
   Signal Name                          Unit     Description
   ==================================   ======   ============================================================================================================================================================================================================================================================================================
   fSCruiseFadrI_EmgyEveIndcn_xdb                Emergency event due to high torsion bar torque indicated
   fSCruiseLimrI_MonSafeOk_xdb                   Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   sSCruiseI_CnclCdn_xdu16                       Cancel conditions indicating why active control mode of statemachine cannot be reached: Bit0=RedLvlTooLo, Bit1=FctCoOverruled, Bit2=SigInvld, Bit3=CtrlErr, Bit4=LimrErr, Bit5=FaderErr, Bit6=FaderEmgcy, Bit7=EcuSt, Bit8=VehSpd, Bit9=BlkdSteer, Bit10=SigPrcrReqOff, Bit11=SteerTrqReqOff
   sSCruiseI_ReqdState_xdu8             Status   Requested State for SCruise from Bus, mapped to internally. 0-Inactive, 1-HandsOn, 2-HandsFree, 3-Parking, 4=HandsOnInc
   sSCruiseI_State_xdu8                 Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   tEpsInI_SCruiseCmftFadeOutTi_xdu16   s        SCruise fade out time comfort fading (SFC<=SCI)
   ==================================   ======   ============================================================================================================================================================================================================================================================================================

   Output Signals
   --------------

   ====================================   ======   ============================================================================================================================
   Signal Name                            Unit     Description
   ====================================   ======   ============================================================================================================================
   sSCruiseFadrI_Reas_xdu8                         Fading reason of unexpected FadeOut or suppressed FadeIn: Bit0=ExtReq, Bit1=IntReq, Bit2=EMGY_DII
   sSCruiseFadrI_St4Chk_xdu8              Status   Desired state of Scruise Fader to be read by Check component only (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=SCI2SFCPND)
   tSCruiseFadrI_FadeOutPndRmngTi_xds16   s        Remaining time in Fader state Pending before fade out starts (SFC <= SCI)
   xSCruiseFadrI_Fac4Chk_xdu16                     Desired fading factor (0=SFC; 1=SCI) of Scruise Fader to be read by Check component only
   ====================================   ======   ============================================================================================================================


   Detailed Description
   --------------------

   The main function of the Fader Main component is to determine the fading factor which is provided to the Fader Check component.
   The fading factor decides how slow or fast the fading process should take place. Note the Fader Main only calculates the fading factor.
   The SCruiseFaderChk component is responsible for the torque calculation between the SFC and SCI torques.

   The fade out time (``tSCruiseFadr_FadeOutTime_XDU16``) can be influenced by the interface ``tSCruiseFadrI_FadeOutPndRmngTi_xds16`` if its value is
   within a valid range. While switching to FadeOut (SCI2SFC) or FadeOut Pending (SCI2SFCPND) mode the last value will be frozen.

   In case of a driver intervention detected by ``fSCruiseFadrI_EmgyEveIndcn_xdb`` the fade out time ``tSCruiseFadr_EmgcyFadeOutTime_XAU16`` will be considered.
   The intention is to fade out SCI smoothly to avoid a sudden assist. At the beginning the last fade out value of the table will be taken up to the first one
   (depending on ``xSCruiseFadrI_Prgs2SCI_xdu16``). SCI will be left step wise (`legacy behaviour`) if the last Y-value of ``tSCruiseFadr_EmgcyFadeOutTime_XAU16`` is ``0.001 s``.
   A little tuning helper is available with `SmoothTransitionToSFC.slx <https://sourcecode02.de.bosch.com/projects/ASMPAPP/repos/asmp-dev/browse/comps_repo/SCruiseFading/components/SCruiseFader/doc/SmoothTransitionToSFC.slx>`_
   to identify the total fading time.

   FadeOut Pending (SCI2SFCPND) means that due to an invalid input value a fadeout is triggered. To avoid an undershoot violation SCI will still stay active for a while.
   The pending time is dependent on the mode.

   In case of an unexpected fade out of SCI mode (from FadeIn (SFC2SCI) or Active (SCI)), an additional interface sSCruiseFadrI_Reas_xdu8
   is provided to show the reason for the fade out. The FadingReason is bit encoded::

      MASK_EXT_REQ     | bit0==1  | external request not present
      MASK_INT_REQ     | bit1==2  | unexpected internal request
      MASK_EMGY        | bit2==4  | fast intervention from driver

   The state of the SCruise Fader is provided on the interface ``sSCruiseFadrI_St4Chk_xdu8`` which is read by the SCruiseFaderChk component.


   Scaling Error of xSCruiseFadrI_Fac4Chk_xdu16
   --------------------------------------------

   With `SF1-1380 <https://rb-tracker.bosch.com/tracker07/browse/SF1-1380>`_ it was required to downscale the interface ``xSCruiseFadrI_Fac4Chk_xdu16``
   to ``RIGHTSHNP15`` (instead of ``RIGHTSHNP25``) to avoid FadrMon-issues (due to scaling of ``xSCruiseFadrI_Prgs2SCI_xdu16``).
   But this leads to a reduced pressicion of the fading time for higher fading times.

   .. image:: SCruiseFader_ScalingError.png

   The formula to calculate the error is available in `ScalingError.m <https://sourcecode02.de.bosch.com/projects/ASMPAPP/repos/asmp-dev/browse/comps_repo/SCruiseFading/components/SCruiseFader/doc/ScalingError.m>`_.

   Calibration/Application Parameters
   ==================================

   =====================================   ====   ==========   =======================================================
   Parameter Name                          Unit   Range        Description
   =====================================   ====   ==========   =======================================================
   tSCruiseFadr_EmgcyFadeOutTime_XAU16     s      0.001..1     Emergency fade out time in case of DII (SCI -> SFC)
   tSCruiseFadr_FadeInTime_XDU16           s      0.001..5     Fade in time (SFC -> SCI)
   tSCruiseFadr_FadeOutTime_XDU16          s      0.001..6.2   Fade out time (SCI -> SFC)
   tSCruiseFadr_HandsFreePndTi_XDU8        s      0.5..4       SCruise pending time before fade out in HandsFree mode
   tSCruiseFadr_HandsOnIncPndTi_XDU8       s      0.1..4       SCruise pending time before fade out in HandsOnInc mode
   tSCruiseFadr_HandsOnPndTi_XDU8          s      0.1..4       SCruise pending time before fade out in HandsOn mode
   tSCruiseFadr_PrkgPndTi_XDU8             s      0..4         SCruise pending time before fade out in Parking mode
   tSCruiseFadr_ReplcmtFadeOutTime_XDU16   s      0.001..6.2   Replacement torque fade out time (SCI -> SFC)
   =====================================   ====   ==========   =======================================================

   All SCruiseFadr parameters are defined in SCruiseFaderChk. The parameter ``sSCruise_SubState_XDU8`` is defined in SCruiseState.

   .. include:: SCruiseFader_CalMan_VT.irst

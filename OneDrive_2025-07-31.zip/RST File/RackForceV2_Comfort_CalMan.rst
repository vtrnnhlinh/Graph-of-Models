RackForceV2_Comfort
###################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

Calculates the actual rack force and PDT1 parameters based on vehicle speed.



Block Diagram
=============
.. only:: confidential

   .. image:: RackForceV2_Comfort_CalMan_BlockDiagram.png


Input Signals
-------------

=====================================     ======   ===================================================================
Signal Name                               Unit     Description
=====================================     ======   ===================================================================
vApplI_AbsVehicleSpeedFilt_xdu16          km/h     Abs. filtered vehicle speed
sApplI_VehicleSpeedState_xdu8             -        vehicle speed state
xRWConI_RatioRackPos2WheelAngle_xdu16     -        ratio between rack position and front wheel angle
wRWConI_FrontWheelAngleCorr_xds16         degree   absolute front wheel angle with long-time steering angle correction
vApplI_AbsSteeringAngleSpeed_xdu16        degree   Abs. corrected steering angle
vRackForceI_WindUpAdaption_xds32          N        WindUp out of adaptions
wApplI_RearWheelAngle_xds16               degree   Actual RAS-Angle
=====================================     ======   ===================================================================


Output Signals
--------------

=====================================    =====   ===========================================
Signal Name                              Unit    Description
=====================================    =====   ===========================================
kRackForceI_RackForceComfort_xds16       N       rack force comfort
kRackForceI_RackForceComfortRaw_xds16    N       rack force comfort raw
aRackForceI_AbsLatAccel_xdu32            m/s^2   abs. lat. acceleration out of vehicle model
=====================================    =====   ===========================================


Detailed Description
--------------------

The RackForce_CalcRFMCParam calculates PDT1 parameters based on vehicle speed and RackForce_CalcRFMC calculates actual Rack force.



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

Provide a table of external (i.e. NOT confidential) calibration parameters.

============================================================     =====   =================      ===========================================================================================
Parameter Name                                                   Unit    Range                  Description
============================================================     =====   =================      ===========================================================================================
vRackForce_VehicleSpeedSubst_XDU16                               km/h    0..500                 substitute vehicle speed when invalid
xRackForce_FilterFactorWheelAngleSpeed_XDU16                     -       0.0009765625 .. 1      filterfactor of PT1-filter for wheel angle speed
xRackForce_FactorWindUpHysteresisSaturation_XDU16                -       1 .. 50                windup factor for saturation of HysteresisForce
xRackForce_FilterFactorT1TZKstat_XDU16                           -       0.0009765625 .. 1      filterfactor for PT1-filter of factors for the PDT1
xRackForce_FilterFactorVehicleSpeedFilt_XDU16                    -       0.0009765625 .. 1      Filter factor for double PT1-filtered vehicle speed
xRackForce_FilterFactorWheelAngle_XDU16                          -       0.0009765625 .. 1      filter factor for PT1-filter of wheel angle
lRackForce_WheelBase_XDU16                                       -       0 .. 5                 WheelBase
xRackForce_FilterFactorUnderSteerGradient_XDU16                  -       0.0009765625 .. 1      filterfactor for PT1-filter of understeer gradient
xRackForce_LateralAcceleration2LateralForceFrontWheels_XDU16     -       0 .. 5000              Conversion factor for calculation of shear force on frontqheels out of lateral acceleration
xRackForce_FactorYawRateUnderSteer_XDU16                         -       0 .. 0.5               Magnification ratio for calculation of additive lateral acceleration
xRackForce_MaxPosRateReduction_XDU16                             -       0 .. 1                 max pos. change rate for reduction of the rackforce depending on the lateral acceleration
xRackForce_MaxNegRateReduction_XDU16                             -       0 .. 1                 max neg. change rate for reduction of the rackforce depending on the lateral acceleration
vRackForce_UnderSteerGradientByLateralAcceleration_XAU16         -       0 .. 1 0 .. 30         understeeer gradient depending on lateral acceleration
xRackForce_UnderSteerGradientVehicleSpeedFactor_XAU16            -       0 .. 1 0 .. 300        factor for understeer gradient depending on double filtered vehicle speed
xRackForce_SignRearWheelAngle_XDS16                              -       -1.. 1                 sign considering HAL-angle   
sRackForce_UseRearWheelAngle_XDU16                               -       0 .. 1                 Switch for using HAL-angle 
============================================================     =====   =================      ===========================================================================================

.. only:: confidential

   Provide a table of internal calibration parameters.
   
   ======================================   =====   =====   =============================================
   Parameter Name                           Unit    Range   Description
   ======================================   =====   =====   =============================================
   None
   ======================================   =====   =====   =============================================



.. include:: RackForceV2_Comfort_CalMan_VT.irst

Engine Run
###########

Short Description
=================

Detects whether the combustion engine is running or not.

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============
   
   .. image:: EngineRun_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ================================   ======   ======================
   Signal Name                        Unit     Description
   ================================   ======   ======================
   nEpsInI_EngineSpeed_xdu16          1/min    Vehicle Engine speed
   ================================   ======   ======================


   Output Signals
   --------------

   =================================   ====   ==================================================================================================
   Signal Name                         Unit   Description
   =================================   ====   ==================================================================================================
   sApplI_EngineRunning_xdu8                  State of combustion engine (0 == EngineNotRunning, 1 == EngineRunning, 2 == EngineRunningStable)
   =================================   ====   ==================================================================================================


   Detailed Description
   --------------------

   This component detects whether the combustion engine of the vehicle is running; a distinction is made among 3 statuses in the process:
   
   
   •	The combustion engine is off
   •	The combustion engine is running
   •	The combustion engine is running in a stable fashion

   A prerequisite is that a valid combustion engine speed is available to the component.


   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ======================================   ======   =========   =====================================================================================================================
   Parameter Name                           Unit     Range       Description
   ======================================   ======   =========   =====================================================================================================================
   nEngRn_EngineRunning_XDU16               1/min    0..16000    The motor speed for the change from the status EngineNotRunning to the Status EngineRunning or EngineRunningStable
   nEngRn_EngineNotRunning_XDU16            1/min    0..16000    Motor speed for the change from the status EngineRunning or EngineRunningStable to the status EngineNotRunning
   tEngRn_Running2Stable_XDU16              ms       0..10000    Time for the change from the status EngineRunning to the status EngineRunningStable
   tEngRn_Stable2NotRunning_XDU16           ms       0..10000    Time for the change from the status EngineRunningStable to the status EngineNotRunning
   ======================================   ======   =========   =====================================================================================================================

.. include:: EngineRun_CalMan_VT.irst

Assistance V3
#############

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component assistanceV3 calculates the assistance torque as a component of the motor torque in dependence upon the steering torque
and vehicle speed.The application of this function has direct influence on steering feel and assistance.


Block Diagram
=============

.. only:: confidential

   .. image:: AssistanceV3_CalMan_BlockDiagram.png

Input Signals
-------------

===================================   ====   ============================================================================
Signal Name                           Unit   Description
===================================   ====   ============================================================================
mApplI_TorsionBarTorque_xds16         Nm     Torsion bar torque
xApplI_GearSign_xds8                         sign of the steering gear
fEndStopI_EndStopActive_xdu8                 flag for EndStop active
mTrqSumI_SteerTrqSum_xds16            Nm     summation of all input steering torques of additional function
zcrChatterPeriodsCount                       counter of the chatter oscillations
vApplI_AbsSafeNssVehicleSpeed_xdu16   km/h   abs. vehicle speed: Secured near standstill
mBciI_AssistCurveTBTXAxis_xas16       N      x-axis of interpolated assistance characteristic (torsion bar torque)
mBciI_AssistCurveMMotYAxis_xas16      Nm     y-axis of interpolated assistance characteristic (nominal assistance torque)
xApplI_VehDirection_xds8                     vehicle direction
xtcActualGradientRedLevel_xau16              active reduction of the gradient reduction for every channel
mApplI_HWLMaxUsableTorque_xdf32       Nm     max usable motortorque from the HWLib
xHwlWrapI_MinRedLevel_xdu16                  Current minimum reduction factor
===================================   ====   ============================================================================


Output Signals
--------------

==================================   ====   ==============================================
Signal Name                          Unit   Description
==================================   ====   ==============================================
matAssistantTorque_xds16             Nm     Assistance torque
mApplI_MaxRequiredMotoTorque_xdu16   Nm     Max.required assistance torque
xatAssistanceGrad_xdu16                     current gradient of the assistance char. curve
==================================   ====   ==============================================

Detailed Description
--------------------
Principle Calculation of Assist curve from BST curve
-----------------------------------------------------
The AssistanceV3 function calculates the Assist curve from the Interpolated Basic Steer Torque characteristic curve (See Application Manual of Basic Steer Torque component).

.. image:: AssistanceV31_blockDiagram.png

To ensure the controller stability independent from the tuned characteristic curve gradient the maximal allowed gradient is limited by the vehicle speed dependent characteristic curve
xatMaxGradvVehicle_XAU16. Additionally the maximal allowed gradient can be limited by the characteristic curves xatMaxGradChatterActive_XAU16 (dependent on chatter counter and vehicle
speed) and xatMaxGradTorGrad_XAU16 dependent on the motor torque gradient reduction of under voltage reduction).

The assistance torque is calculated from the new gradient limited  assistance torque characteristic and the difference to the unlimited assistance torque. This difference will be added
via PT1 filter to the gradient limited part. The PT1 filter can be influenced with the characteristic curve  xatAssistFilterFrequ_XAU16 (dependent on the motor torque gradient reduction
of under voltage reduction) and the characteristic value xatAssistFilterFrequFast_XDU16.

Assistance Curve Calculation:
Unlimited Assistance Curve is calculated by the actual BST-Curve taking into account the function coordinator assist pre- and post scalers. Maximum Gradient of the Unlimited Assist Curve
and the maximum Assist Value can be specified.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

===============================   =====   =================    ====================================================================================================================================
Parameter Name                    Unit    Range                Description
===============================   =====   =================    ====================================================================================================================================
xatBSTMaxGrad_XDU16                       1..5                 maximum Gradient of the unlimited Assistance Curve
msyAbsTorsionBarTorque_XDU16      Nm      3 .. 10              Absolute steering torque limit
xatAssistFilterFrequ_XAU16                0,001 .. 0,09912     Frequency for Assistance filter
xatAssistFilterFrequFast_XDU16            0,001 .. 0,09912     Assistance filter frequency for fast filtering
fatAllowAssistReduction_XDB               0..1                 Allows a reduction of assistance due to (mApplI_HWLMaxUsableTorque + matIMaxUsableOffset_XDU16) * xHwlWrapI_MinRedLevel
fatAllowMaxReqMMotReduction_XDB           0..1                 Allows a reduction of MaxRequiredMotorTorque due to (mApplI_HWLMaxUsableTorque + matIMaxUsableOffset_XDU16) * xHwlWrapI_MinRedLevel
===============================   =====   =================    ====================================================================================================================================

.. only:: confidential

   =====================================    =====   ===========    ====================================================================================
   Parameter Name                           Unit    Range          Description
   =====================================    =====   ===========    ====================================================================================
   zcrMinChatterPeriodsCountDelayed_XDU8            0 .. 30        minimum chatter cycle counter during holing time (after chatter detection finished)
   xatMaxGradGradUp_XDU16                           0.001 .. 2     max.change of the gradient limitation in pos. direction
   xatMaxGradGradDown_XDU16                         0.001 .. 2     max.change of the gradient limitation in neg. direction
   xatMaxGradChatterActive_XAU16                    0.001 .. 5     Max gradient when chatter detected
   xatMaxGradvVehicle_XAU16                         0 .. 5         Max gradient for gradient limitation DAC dependent to v vehicle
   xatMaxGradvVehicleReverse_XAU16                  0 .. 5         Max gradient for gradient limitation DAC dependent to v vehicle when driving reverse
   xatMaxGradTorGrad_XAU16                          0 .. 5         Max gradient for gradient limitation DAC dependent to the reduction factor
   matIMaxUsableOffset_XDU16                Nm      0 .. 2         Maximum HWL Usable Torque Offset, added to mApplI_HWLMaxUsableTorque_xdf32
   =====================================    =====   ===========    ====================================================================================

.. include:: AssistanceV3_CalMan_VT.irst

Smart Cruise Steer Torque Damping
#################################

.. only:: confidential


   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component provides a damping torque on the SCruise nominal steer torque.

Block Diagram
=============

.. only:: not confidential

   .. image:: SCruiseDampg_CalMan_BlockDiagram_Customer.png
   
.. only:: confidential

   .. image:: SCruiseDampg_CalMan_BlockDiagram.png


Input Signals
-------------
.. only:: not confidential

   ==============================   =====   ====================================================================================================
   Signal Name                      Unit    Description
   ==============================   =====   ====================================================================================================
   nSCruiseI_RotSpdCoupl_xds16      1/min   SCruise mapped filtered rotor speed, gear sign adjusted
   vSCruiseI_AbsAvgVehSpd_xdu16     km/h    SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   ==============================   =====   ====================================================================================================

.. only:: confidential

   ==============================   =====   ====================================================================================================
   Signal Name                      Unit    Description
   ==============================   =====   ====================================================================================================
   xSCruiseI_HandsOnFadrFac_xdu16   --      Fading factor HandsOn (1) to HandsFree (0)
   xSCruiseI_StfnFac_xdu16          --      signal processed stiffness factor for SCruise
   ==============================   =====   ====================================================================================================

Output Signals
--------------

===========================   ====   ===========================
Signal Name                   Unit   Description
===========================   ====   ===========================
mSCruiseI_NomDampgTrq_xds16   Nm     nominal damping torque
===========================   ====   ===========================



Detailed Description
--------------------

The damping torque of the SCruise nominal steer torque is calculated dependent on vehicle speed and rotor speed.

.. only:: confidential

   Moreover it can be scaled by a factor depending on the present SCruise mode (HandOn or HandsFree) represented
   by the HandsOn fading factor. Whether the stiffness factor shall be used to linearly scale the damping torque
   can be selected via the corresponding calibration flag.


Calibration/Application Parameters
==================================
.. only:: not confidential

   =======================================   ====   =====   ===================================================================================================================================================================
   Parameter Name                            Unit   Range   Description
   =======================================   ====   =====   ===================================================================================================================================================================
   mSCruise_DampingTorque_XAU16              Nm     0..12   nominal damping torque depending on vehicle speed and rotor speed
   =======================================   ====   =====   ===================================================================================================================================================================

.. only:: confidential

   =======================================   ====   =====   ===================================================================================================================================================================
   Parameter Name                            Unit   Range   Description
   =======================================   ====   =====   ===================================================================================================================================================================
   fSCruise_DisblDamping_XDU8                --     0; 1    Damping deactivation for testing purpose
   xSCruise_DampgFacModChg_XAU16             --     0..2    damping factor depending on SCruise HandsOn fading factor
   fSCruise_DampgAndJTrqDpdtOnStfnFac_XDU8   --     0; 1    flag to enable dependency of damping and inertia (in component SCruiseActvJ) torque on stiffness factor (both torque values will be scaled with stiffness factor).
   xSCruise_DampgStfnFacX_XAU16              --     0; 1    Modify StiffnessFactor (x-axis) depending on xSCruiseI_StfnFac_xdu16
   xSCruise_DampgStfnFacHndOnY_XAU16         --     0; 1    Modify StiffnessFactor (Y-axis) depending on xSCruiseI_StfnFac_xdu16 and SCruise HandsOn fading factor in HandOn mode
   xSCruise_DampgStfnFacHndFreeY_XAU16       --     0; 1    Modify StiffnessFactor (Y-axis) depending on xSCruiseI_StfnFac_xdu16 and SCruise HandsOn fading factor in HandFree mode
   =======================================   ====   =====   ===================================================================================================================================================================

.. include:: SCruiseDampg_CalMan_VT.irst

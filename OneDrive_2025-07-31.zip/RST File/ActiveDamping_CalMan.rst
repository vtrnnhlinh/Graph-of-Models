Active Damping
##############

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The Active Damping is a function that stabilizes the rotor in high dynamic steering situations.
Parallel to the damping part in the “Active Return” component exists an additional damping.

Damping torque is increases or decreases depend upon the steering angle, rotor speed, vehicle speed, damping fact from the function coordination and driver torque.


Block Diagram
=============

.. only:: confidential

   .. image:: ActiveDamping_CalMan_BlockDiagram.png


Input Signals
-------------

===================================   =====   =========================================================================
Signal Name                           Unit    Description
===================================   =====   =========================================================================
mApplI_DriverTorque_xds16             Nm      calculated driver torque
nApplI_RotorSpeedFilt_xds16           1/min   filtered rotor speed
sApplI_SteeringAngleState_xdu8                state of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
vVehSpI_AbsAvgVehSpd_xdu16            km/h    Average vehicle speed. Close to the actual speed over ground as possible.
wApplI_SteeringAngle_xds16            °       corrected steering angle
xFactMinI_ActiveDampingFactor_xdu16           minimized active damping factor
===================================   =====   =========================================================================


Output Signals
--------------

=================================   ====   =================================================================
Signal Name                         Unit   Description
=================================   ====   =================================================================
mActDampI_MotorTorque_xds16         Nm     motor torque of active damping component
=================================   ====   =================================================================

.. only:: confidential

   =================================   ====   ===================================================================================================
   Signal Name  [Internal]             Unit   Description
   =================================   ====   ===================================================================================================
   xActDamp_RateLimitedFactors_xdu16          rate limited factor dependent on vehicle speed and steering angle
   xActDamp_TotalDampingFactor_xdu16          total damping factor dependent on vehicle speed, steering angle, driver Torque, ActiveDampingFactor
   =================================   ====   ===================================================================================================
   

Detailed Description
--------------------

   
The additional damping component is coordinated via four characteristic curves:    
    1.xActDamp_FactorDepOnVehSpeed_XAU16 (weighting due to vehicle speed)
	
    2.xActDamp_FactorDepOnDriverTorque_XAU16 (weighting due to driver torque)
	
    3.xActDamp_FactorDepOnSteerAngle_XAU16 (weighting due to steering angle)
	
    4.xActDamp_TorqueDepOnRotorSpeed_XAU16 (damping torque dependent upon the steering speed)
	
The driver torque factor and the vehicle speed factor will ramped with the value xActDamp_FactorGrad_XDU16.
	
The resulting torque of the "active damping" function is limited in the end by the characteristic curve mActDamp_MaxMotorTorqueDepOnRotorSpeed_XAU16.

   
Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

============================================   ====   ========   ==================================================================================================================================================================
Parameter Name                                 Unit   Range      Description
============================================   ====   ========   ==================================================================================================================================================================
mActDamp_MaxMotorTorqueDepOnRotorSpeed_XAU16   Nm     0..1       limitation of active return torque depending on rotor speed
xActDamp_FactorDepOnDriverTorque_XAU16                0..2       active damping factor depending on driver torque
xActDamp_FactorDepOnSteerAngle_XAU16                  0..1.5     active damping factor depending on steering angle
xActDamp_FactorDepOnVehSpeed_XAU16                    0..2       active damping factor depending on vehicle speed
xActDamp_FactorGrad_XDU16                             0.001..1   Maximum gradient of vehicle speed and steering angle dependent factor. Primarily done to ramp to substitute value. [factor/cycle] (BE AWARE: depends on CycleTime)
xActDamp_TorqueDepOnRotorSpeed_XAU16                  0..2       active damping torque depending on rotor speed
============================================   ====   ========   ==================================================================================================================================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: ActiveDamping_CalMan_VT.irst

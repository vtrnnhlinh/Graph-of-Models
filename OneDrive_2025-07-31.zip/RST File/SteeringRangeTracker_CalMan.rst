SteeringRangeTracker
#####################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

.. only:: confidential
   
   The component shall classify the relative steering angle using level crossing counting.

.. only:: not confidential

   The component performs the classification of steering angle.


Block Diagram
=============

.. only:: confidential

   .. image:: SteeringRangeTracker_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SteeringRangeTracker_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

================================   ====   ======================
Signal Name                        Unit   Description
================================   ====   ======================
wApplI_SteeringAngle_xds16         deg    corrected steering angle
sApplI_SteeringAngleState_xdu8            steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit)       
================================   ====   ======================


Output Signals
--------------

=================================   ====   ============================================================
Signal Name                         Unit   Description
=================================   ====   ============================================================
zLdTrkI_SteerRangeCounter01_xdu32          Steering Range Counter Left (>100%)
zLdTrkI_SteerRangeCounter02_xdu32          Steering Range Counter Left (>=90%)
zLdTrkI_SteerRangeCounter03_xdu32          Steering Range Counter Left (>=80%)
zLdTrkI_SteerRangeCounter04_xdu32          Steering Range Counter Left (>=70%)
zLdTrkI_SteerRangeCounter05_xdu32          Steering Range Counter Left (>=60%)
zLdTrkI_SteerRangeCounter06_xdu32          Steering Range Counter Left (>=50%)
zLdTrkI_SteerRangeCounter07_xdu32          Steering Range Counter Left (>=40%)
zLdTrkI_SteerRangeCounter08_xdu32          Steering Range Counter Left (>=30%)
zLdTrkI_SteerRangeCounter09_xdu32          Steering Range Counter Left (>=20%)
zLdTrkI_SteerRangeCounter10_xdu32          Steering Range Counter Left (>=10%)
zLdTrkI_SteerRangeCounter11_xdu32          Steering Range Counter Crossing from Left to Right (0%)
zLdTrkI_SteerRangeCounter12_xdu32          Steering Range Counter Crossing from Right to left (0%)        
zLdTrkI_SteerRangeCounter13_xdu32          Steering Range Counter Right (>=10%)
zLdTrkI_SteerRangeCounter14_xdu32          Steering Range Counter Right (>=20%)
zLdTrkI_SteerRangeCounter15_xdu32          Steering Range Counter Right (>=30%)
zLdTrkI_SteerRangeCounter16_xdu32          Steering Range Counter Right (>=40%)
zLdTrkI_SteerRangeCounter17_xdu32          Steering Range Counter Right (>=50%)
zLdTrkI_SteerRangeCounter18_xdu32          Steering Range Counter Right (>=60%)
zLdTrkI_SteerRangeCounter19_xdu32          Steering Range Counter Right (>=70%)
zLdTrkI_SteerRangeCounter20_xdu32          Steering Range Counter Right (>=80%)
zLdTrkI_SteerRangeCounter21_xdu32          Steering Range Counter Right (>=90%)
zLdTrkI_SteerRangeCounter22_xdu32          Steering Range Counter Right (>100%)
=================================   ====   ============================================================

.. only:: confidential

   Internal Signals
   -----------------

   =======================================   ====   =====================
   Signal Name                               Unit   Description
   =======================================   ====   =====================
   hLdTrk_SteeringPercent_xds32               %     Steering Percent (Steering Angle/wLdTrk_MaxSteeringRange_XDU16)*100
   fLdTrk_HysteresisLvlCrossed_xau8                 Flag to indicate Hysteresis Limit was crossed
   zLdTrk_SteeringRangeCounterArray_xau32           Steering Range Counter Array
   fLdTrk_SteerRangeJobResultOK_xdb                 Job Result of NVM Read all operation
   =======================================   ====   =====================


Detailed Description
--------------------

For the classification of the steering angle the maximum possible steering angle of the steering system till mechanical endstop is considered.

.. only:: confidential

   Straight ahead position shall be 0%; steering angles clockwise (cw) from straight ahead will be positive values, counterclockwise (ccw) will be negative ones.
   
   It is possible to get higher relative values than +100% resp. lower than -100%:
	* in case of damper compression
	* for detection of defective steering system, e.g. deflected / deformed end stop
	
   As the calculated steering angle considers counter clockwise as positive and clockwise as negative, the direction of steering angle signal is reversed and
   then considered for classification.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

The table of calibration parameters.

======================================   =====   =========   =============================================
Parameter Name                           Unit    Range       Description
======================================   =====   =========   =============================================
wLdTrk_MaxSteeringRange_XDU16             deg    1 .. 1000   Maximum Steering Range within Mechanical EndStops
======================================   =====   =========   =============================================

.. only:: confidential

   The table of internal calibration parameters.
   
   =============================================   =====   ================   =============================================
   Parameter Name                                  Unit    Range              Description
   =============================================   =====   ================   =============================================
   hLdTrk_SteeringAngleLevelCrossingLimit_XAS16      %     -100 .. 100        Limits for detecting the level crossing
   hLdTrk_StAngleLvlCrossingHysteresis_XDU16         %     1 .. 5             Hysteresis limit for Steering Angle Level Crossing (Classwidth*Hysteresis percentage)
   zLdTrk_MaxCountRange_XDU32                              0 .. 4294967295    Maximum value for Range Counters
   =============================================   =====   ================   =============================================

.. include:: SteeringRangeTracker_CalMan_VT.irst

Steering Control V2
###################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This function steering control provides a phase compensation in the steering system control loop.


Block Diagram
=============

.. only:: confidential

   .. image:: SteeringControlV2_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SteeringControlV2_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

=================================   =====   =========================================================================================================
Signal Name                         Unit    Description
=================================   =====   =========================================================================================================
fEndStopI_EndStopActive_xdu8                flag for EndStop active
mApplI_GradTorsionBarTorque_xds16   Nm/ms   HW LIB: torque gradient
nApplI_RotorSpeedFilt_xds16         1/min   filtered rotor speed
sApplI_VehicleSpeedState_xdu8               Validflag for vehicle speed vApplI_AbsVehicleSpeedFilt_xdu16 (1 = valid; 0 = invalid or substitute speed)
vApplI_AbsVehicleSpeedFilt_xdu16    km/h    Abs. vehicle speed: processed
xatAssistanceGrad_xdu16             Nm/Nm   current gradient of the assistance char. curve
mApplI_TorsionBarTorque_xds16       Nm      HW LIB: torsion bar torque
=================================   =====   =========================================================================================================

.. only:: confidential

   =====================================   =====   ===================================
   Signal Name [for internal usage only]   Unit    Description
   =====================================   =====   ===================================
   xApplI_GearSign_xds8                            sign of the steering gear
   zcrChatterPeriodsCount_xdu8                     counter of the chatter oscillations
   =====================================   =====   ===================================

Output Signals
--------------

=====================================  ====   =================================================================
Signal Name                            Unit   Description
=====================================  ====   =================================================================
mSteerCtrlI_MotorTorque_xds16          Nm     totalized motor torque (D-part and D-offset)
=====================================  ====   =================================================================

.. only:: confidential

   =====================================   =====   ===================================
   Signal Name [for internal usage only]   Unit    Description
   =====================================   =====   ===================================
   mSteerCtrl_DOffset_xds16                Nm      D-part offset calculated out of GradTorsionBarTorque
   mSteerCtrl_AbsDOffset_xdu16             Nm      abs value of D-part offset calculated out of GradTorsionBarTorque
   mSteerCtrl_DPart_xds16                  Nm      D-part calculated out of the assistance torque
   mSteerCtrl_FiltSCGradTBT_xds16          Nm      gradient TBT calculated in SteerCtrl
   mSteerCtrl_HystTorsionBarTorque_xds16   Nm      hysteresis torsion bar torque
   =====================================   =====   ===================================

Detailed Description
--------------------
This component is realized with a PD controller. The P part is represented by the assistance function. The D part is comprised of two parts. 

In D-Part calculation, if chatter measure is set while the steering system is at EndStop, then D-Part is set to zero, otherwise it's calculated as "The actual D part is weighted with the increase in the current operating point of the characteristic 
assistance curves and is consequently dependent upon their application".

The D-Offset part (dependent upon the vehicle speed) is directly derived from the calculated steering torque and is therefore independent of the characteristic assistance curve that is set.

To stabilize the rotor due to chattering the motor torque shall be reduced. The torque reduction level set to xSteerCtrl_ChatterReduction_XAU16 if vehicle speed is lower the threshold and the input signals are valid.
Otherwise set "100 %".

The application of this function has a very strong influence on the system stability and the system noises. 
These influences, especially the controller stability, are to be set and checked under all of the operating conditions (parking at high and low coefficients of friction, behaviour at high steering speeds) and should no longer be changed after that.


Calibration/Application Parameters
==================================

================================================   =====   =======   ============================================================================================================
Parameter name                                     Unit    Range     Description
================================================   =====   =======   ============================================================================================================
fSteerCtrl_DeactivateDPartAtEndstop_XDU16                  0..1      deactivate D-part (due to assistance torque) at EndStop in case of NO chattering
xSteerCtrl_DPartFactor_XAU16                               0.5..25   DPartFactor: characteristic field dependent on VehicleSpeed and RotorSpeed, this replaces 3D-interpolation
xSteerCtrl_DOffsetFactor_XAU16                             0.5..25   DOffsetFactor: characteristic field dependent on VehicleSpeed and RotorSpeed, this replaces 3D-interpolation
mSteerCtrl_DOffsetDeadband_XDU16                   Nm      0..2      dead band D-part offset (due to TorsionBarTorqueGradient)
================================================   =====   =======   ============================================================================================================

.. only:: confidential

   ================================================   =====   ========  ======================================================================================================================
   Parameter name [for internal usage only]           Unit    Range     Description
   ================================================   =====   ========  ======================================================================================================================
   fSteerCtrl_DeactivateDPartAtEndstopChatter_XDU16           0..1      deactivate D-part (due to assistance torque) at EndStop in case of CHATTERING
   vSteerCtrl_MaxVehSpeedRedDueChatter_XDU16          km/h    0..255    minimum vehicle speed limit to deactivate the reduction
   vSteerCtrl_SubstituteSpeed_XDU16                   km/h    0..500    substitute value for vehicle speed interpolation
   xSteerCtrl_SubstDOffsetFactChatter_XDU16           ms      0..25     substitute value of D-part offset factor (due to TorsionBarTorqueGradient) if chattering is detected
   xSteerCtrl_SubstDPartFactChatter_XDU16             ms      0..25     substitute value of D-part factor (due to assistance torque) if chattering is detected
   ySteerCtrl_RampDownRedLevDueChatter_XDU16          1/1ms   0..1      negative gradient of reduction due to chattering
   ySteerCtrl_RampUpRedLevDueChatter_XDU16            1/1ms   0..1      positive gradient of reduction due to chattering
   zSteerCtrl_ChatteringDetected_XDU8                         0..30     chatter periods counter threshold to detect chattering (shall be identically to zscMinChatterPeriodsCountDelayed_XDU8)
   xSteerCtrl_ChatterReduction_XAU16                          0..1      reduction level in dependency of chatter cycles counter
   fSteerCtrl_NoRotSpDoffLockstop_XDU8                        0..1      RotorSpeed Independent Doffset enable at endstop
   xSteerCtrl_DOffsetFactorFactorMechStuck_XAU16              0..25     D-Offset-Part torque over D-Offset-Part torque when mech stuck prevention active
   xSteerCtrl_HysteresisTBT_XAU16                     Nm      0..1      DeadZone TBT: characteristic field dependent on VehicleSpeed and RotorSpeed
   xSteerCtrl_FilterGradTBT_XAU16                             0.001..1  Filter GradTBT: characteristic field dependent on VehicleSpeed and RotorSpeed
   fSteerCtrl_UseSteerCtrlTBTGrad_XDB                         0..1      SteerCtrl Use internal TBT gradient calculation
   xSteerCtrl_DOffsetFactorEndStop_XAU16              ms      0..5      vehicle speed dependant d-offset factor at endstop (independant rotorspeed)
   ================================================   =====   ========  ======================================================================================================================

.. include:: SteeringControlV2_CalMan_VT.irst

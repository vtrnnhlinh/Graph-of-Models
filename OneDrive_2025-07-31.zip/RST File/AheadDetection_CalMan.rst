Ahead Detection
###############

Short Description
=================

The component Ahead Detection detects driving straight ahead situations.
Therefore two different strategies are available:

* Ahead Detetion from wheel speeds:

   * Calculates the quotients from diagonally opposite wheelspeeds and detects driving ahead if they are approximately 1.

* Ahead Detection from yawrate, vehicle speed and torsionbar torque:

    * If the vehicles speed is above a certain threshold and the torsionbar torque approximately 0 Nm the vehicle is likely driving straight.
      In addition, the yawrate and the lateral acceleration have to be also ~0.

The detection is debounced in both algorithms for ~0.5 sec. The outputs can also be set by the supp-component (--> disable, enable, enforce detection).
The outputs of the Ahead Detection are used by the steering angle calculation for initialization, correction and monitoring.


.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

Block Diagram
=============

.. image:: AheadDetection_CalMan_BlockDiagram.png


Input Signals
-------------

=====================================     ======   =============================================================================
Signal Name                               Unit     Description
=====================================     ======   =============================================================================
vEpsInI_WheelSpeedFLDiv_xds16              kph     Diverse Wheel Speed Front Left
vEpsInI_WheelSpeedFRDiv_xds16              kph     Diverse Wheel Speed Front Right
vEpsInI_WheelSpeedRLDiv_xds16              kph     Diverse Wheel Speed Rear Left
vEpsInI_WheelSpeedRRDiv_xds16              kph     Diverse Wheel Speed Rear Right
mApplI_TorsionBarTorque_xds16              Nm      HW LIB: torsion bar torque
sHwlWrapI_TorsionBarTorqueState_xde                HW LIB: state / validity of torsion bar torque
vVehSpI_AbsAvgVehSpd_xdu16                 kph     Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
aApplI_LateralAcceleration_xds16           m/s^2   lateral acceleration of vehicle
vApplI_YawVelocity_xds16                   °/s     yaw rate of vehicle
vApplI_AbsSteeringAngleSpeed_xdu16         °/s     steering speed at steering wheel(absolute value)
sAhaDetI_DetDemandWhlsSupp_xdu8                    detection request from supp-component for wheelspeed-algorith
sAhaDetI_DetDemandYawSupp_xdu8                     detection request from supp-component for yawrate-algorithm
=====================================     ======   =============================================================================


Output Signals
--------------

==========================================   ====   ===================================================================================================================
Signal Name                                  Unit   Description
==========================================   ====   ===================================================================================================================
sAhaDetI_AheadFromWheels_xdu8                       1 = straight ahead from wheels detected; 0 = not detected
sAhaDetI_AheadFromYaw_xdu8                          1 = straight ahead from yawrate, vehicle speed and torsionbar torque detected; 0 = not detected
==========================================   ====   ===================================================================================================================


Detailed Description
--------------------

Both algorithms work independently from each other and are used for separate functions in the software:

* Ahead from wheelspeeds - initialization of iSAS and monitoring of iSAS (internal Steering Angle Sensor)
* Ahead from yawrate, vehicle speed, torsionbar torque - steering angle correction


Ahead from wheelspeeds
""""""""""""""""""""""

To detect straight ahead the ratios of both front wheelspeeds towards the opposite rear wheelspeed are evaluated. If the vehicle is driving straight, these quotients are within a certain range around 1.
To avoid false detections, there are several additional conditions checked:

* low deviation of average front axle and rear axle speed
* low gradients of all four diverse wheelspeeds
* low deviation of front left and front right diverse wheelspeed
* low deviation of rear left and rear right diverse wheelspeed
* all four wheelspeeds must be higher than a threshold
* low deviation of all four diverse wheelspeeds from average speed of slower axle (no slip)
* low deviation of front axle speed to vehicle speed from ESP


Ahead from yawrate
""""""""""""""""""

To detect straight ahead the torsionbar torque must be below a threshold when the vehicle is driving faster than a minimum speed (low torque at high speed).
This condition can be fulfilled for a longer time (debouncing) only when driving straight or on low friction ground.
To avoid false detections, there are some additional conditions checked:

* yawrate below threshold (or signal invalid)
* lateral acceleration below threshold (or signal invalid)
* steering speed below threshold (must be valid)

As these conditions might be fulfilled erroneously, this algorithm is only used in the steering angle correction, which is learning quite slowly.
However, the used input signals might have a higher availability than wheelspeeds, which are not always provided (dep. on project).


Safety mechanism
""""""""""""""""

There is no special safety mechanism for the AheadDetection implemented, only the different checks of the conditions and a redundant storage auf the outputs.
Depending on the integrity of the used input signals it is possible to fulfill up to ASIL-B. For "higher" requirements the AheadDetection must not be used.



Calibration/Application Parameters
==================================

=========================================   =====   ===========   ====================================================================================================================
Name                                        Unit    Range         Description
=========================================   =====   ===========   ====================================================================================================================
tAhaDet_AheadDetectionTimer_XDU8            s       0 .. 2.5      Ahead detection timer
vAhaDet_MaxAbsYawVelocity_XDU16             °/s     0 .. 30       threshold of yawrate for ahead detection
aAhaDet_MaxAbsLateralAccel_XDU16            m/s^2   0 .. 1        threshold of lateral acceleration for ahead detection (exclude road banking)
xAhaDet_RatioLimitAhead_XDU16                       0 .. 2        upper threshold for wheelspeed ratios for straight ahead detection
xAhaDet_LowerRatioLimitAhead_XDU16                  0 .. 2        lower threshold for wheelspeed ratios for straight ahead detection
xAhaDet_SlipLimit_XDU16                             0 .. 2        limit of slip for ratio front/rear in straight ahead detection
aAhaDet_AccLimit_XDU16                      kph     0 .. 20       limit of acceleration for straight ahead detection
vAhaDet_MinRotationLimit_XDU16              kph     0 .. 20       all 4 wheelspeeds must be above this threshold for straight ahead detection
vAhaDet_FrontRearRotationLimit_XDU16        kph     0 .. 20       maximum deviation of front and rear axle speed for straight ahead detection
vAhaDet_FrontESPvLimit_XDU16                kph     0 .. 20       maximum deviation of front axle speed and VehicleSpeedFilt for straight ahead detection
vAhaDet_LeftRightRotationLimit_XDU16        kph     0 .. 20       maximum deviation of wheelspeeds rigt/left at an axle for straight ahead detection
vAhaDet_StAnSpeedLimit_XDU16                °/s     0 .. 1200     maximum steering angle speed for straight ahead detection
mAhaDet_TorqueLimit_XDU16                   Nm      0 .. 10       maximum torsionbar torque for straight ahead detection
xAhaDet_MaxRatioGradient_XDU16                      0 .. 16       limit of change in wheelspeed quotient for ahead detection
xAhaDet_FiltFactPT1YR_XDU16                         0 .. 1        filter factor of PT1-filter of yawrate
vAhaDet_MinVehicleSpeed_XDU16               kph     0 .. 255      lower threshold of vehicle speed for ahead detection
=========================================   =====   ===========   ====================================================================================================================


.. include:: AheadDetection_CalMan_VT.irst

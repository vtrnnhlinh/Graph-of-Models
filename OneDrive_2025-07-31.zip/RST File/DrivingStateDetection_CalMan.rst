Driving State Detection
########################


Short Description
=================

Calculates the state of oversteer and understeer. Also detects driving on banked curves.


.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   Input Signals
   -------------

   ================================    =======   ==========================================================================================================
   Signal Name                         Unit      Description
   ================================    =======   ==========================================================================================================
   vApplI_AbsVehicleSpeedFilt_xdu16    km/h      Abs. vehicle speed: processed
   wRWConI_FrontWheelAngle_xds16       °         front wheel angle
   vApplI_YawVelocity_xds16                      Yaw Velocity
   aApplI_LateralAcceleration_xds16    m/s^2     Lateral acceleration
   xApplI_VehDirection_xds8                      vehicle direction
   sApplI_VehicleSpeedState_xdu8                 Validflag for vehicle speed vApplI_AbsVehicleSpeedFilt_xdu16 (1 = valid; 0 = invalid or substitute speed)
   wApplI_RearWheelAngle_xds16         °         Actual RAS-Angle
   ================================    =======   ==========================================================================================================


   Output Signals
   --------------

   =================================   ====   ====================================================================================
   Signal Name                         Unit   Description
   =================================   ====   ====================================================================================
   xApplI_DegreeOfUndersteer_xdu16            Degree of Understeer
   xApplI_DegreeOfOversteer_xdu16             Degree of Oversteer
   fDsdI_BankedCurveDetected_xdb              flag banked curve detection 1=banked curve detected 0=banked curve not detected
   vDsdI_YawVelocity_xdf32                    yaw rate with zero comparison
   aDsdI_LateralAcceleration_xdf32            lateral acceleration [m/s^2]
   =================================   ====   ====================================================================================


   Detailed Description
   --------------------

   To adapt the steering functions in vehicle dynamic situations, the software component driving state detection (Dsd) calculates
   the state of oversteer and understeer. The detection of the driving state is based on the yawrate difference. The software module
   calculates the reference yawrate for over- and understeer. With the current yawrate of the car and the reference yawrate it is
   possible to assess the driving state of the car. The value of driving state equates the straight proportional amplified difference
   between ref.yawrate and the current yawrate.

   - Is the ref. yawrate higher than the current yawrate the module detects oversteer.
   - Is the ref. yawrate less than the current yawrate the module detects understeer.

   If there is oversteer and understeer at the same time, the evaluation of understeer is stopped.

   Following Tools for the identification of single track model and other parameters in the model are necessary.

   - TailorTool (measurment files will be prepared for identification)
   - DSD-Tool (Tool fot the identifcation of the parameters and export kon file for DSD)

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ======================================   =====   =========  ==================================================================================
   Parameter Name                           Unit    Range      Description
   ======================================   =====   =========  ==================================================================================
   vDsd_VelVeh_max_XDF32                            0..70      max. vehicle speed [m/s]
   qDsd_FreqFilt_anvYaw_XDF32                       0..100     absolute term filter [Hz]
   vDsd_Threshold_anvYaw_XAF32                      0..1       parameter threshold calculation for yaw rate
   xDsd_Kd_Yaw_US_XDF32                             0..1000    factor calculation understeer in percent
   vDsd_Th_Yaw_US_XDF32                             0..1       threshold yaw rate understeer  [rad/s]
   xDsd_Kd_Yaw_OS_XDF32                             0..1000    factor calculation oversteer in percent
   vDsd_Th_Yaw_OS_XDF32                             0..1       threshold yaw rate oversteer [rad/s]
   vDsd_Th_YawHyst_XDF32                            0..1       hysteresis of threshold
   vDsd_VelVeh_Init_XDF32                           0..15      min. vehicle speed [m/s]
   vDsd_VelVeh_Backwards_XDF32                      0..15      min. vehicle speed backwards (absolute) [m/s]
   xDsd_Th_GradOS_SK_on_XDF32                       0..100     threshold degree of oversteer for activationg banked curve detection [%]
   xDsd_Th_GradOS_SK_off_XDF32                      0..100     threshold degree of oversteer for deactivationg banked curve detection [%]
   wDsd_Th_RollAngle_SK_on_XDF32                    0..45      min. roll angle for activating banked curve detection [°]
   wDsd_Th_RollAngle_SK_off_XDF32                   0..45      max. roll angle for deactivating banked curve detection [°]
   vDsd_Th_RollAngleSpeed_SK_XDF32                  0..45      min. roll angle speed for activating banked curve detection [°/s]
   vDsd_MaxRollAngleSpeed_SK_XDF32                  0..0.45    max. roll angle speed for activating banked curve detection [°/10ms]
   aDsd_MaxDeltaLatAccSpeed_SK_XDF32                0..0.45    gradient limitation lateral acceleration [m/s^2/10ms]
   aDsd_Th_DeltaLatAcc_SK_XDF32                     0..45      threshold lateral acceleration difference for banked curve detection [m/s^2]
   vDsd_MaxDeltaYawSpeed_SK_XDF32                   0..0.45    gradient limitation  yaw rate [°/s/10ms]
   vDsd_Th_DeltaYaw_SK_XDF32                        0..45      threshold yaw rate difference for banked curve detection [°/s]
   xDsd_RASFactor_XDS8                              -1..1      RAS Angle factor for DSD (1 = normal, 0 = not calculated, -1 = negative)
   ======================================   =====   =========  ==================================================================================



   ======================================   =====   ===========   ======================================================
   Parameter Name                           Unit    Range         Description
   ======================================   =====   ===========   ======================================================
   xDsd_YawRef_a_t_XDF32                            0..1          absolute term functionparameter A
   xDsd_YawRef_a_damp_XDF32                         0..2          damping term functonparameter A
   xDsd_YawRef_b_damp_XDF32                         0..2          damping term functonparameter B
   xDsd_YawRef_a_stat_XDF32                         0..1          factor on vehicle speed
   xDsd_YawRef_b_stat_XDF32                         0..1          factor on linear vehicle speed
   xDsd_YawRef_c_stat_XDF32                         0..1          Y-axis part of kstat function
   xDsd_VelRefSwitch_stat_XDF32                     0..100        Upper limit for new kstat calculation
   qDsd_YawRef_a_freq_XDF32                         0..100        natural frequency functionparameter A
   qDsd_YawRef_b_freq_XDF32                         0..100        natural frequency functionparameter B
   qDsd_YawRef_c_freq_XDF32                         0..100        natural frequency functionparameter C
   qDsd_YawRef_freqFilt_XDF32                       0..100        PT1 filter on psip_ay [Hz]
   tDsd_YawRef_Ts_XDF32                             0.001..0.01   sampling time [s]
   xDsd_YawRef_k_wu_ayshape_XAF32                   0..100        gain wind-up for anvYawAy, vehicle speed dependant
   ======================================   =====   ===========   ======================================================

.. include:: DrivingStateDetection_CalMan_VT.irst

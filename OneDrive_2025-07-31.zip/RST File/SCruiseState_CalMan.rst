Smart Cruise Signal Processor | Statemachine
############################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component SCruiseState implements the state machine managing the activation and deactivation as well as the mode handling of the Smart Cruise Interface (SCI).


   .. only:: confidential

Block Diagram
=============
HandsOn fading factor calculation depending on current mode:

   .. image:: SCruiseState_CalMan_BlockDiagram_Mode.png

Input Signals
-------------

.. only:: confidential

   ===================================   ======   ============================================================================================================================================================================================================================================================================================
   Signal Name                           Unit     Description
   ===================================   ======   ============================================================================================================================================================================================================================================================================================
   SY_SCI_FUNCT_ACTIVATED                         Smart Cruise Interface functionality activated
   sSCruiseFadrI_State_xdu8              Status   FaderState (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=SCI2SFCPND; 6=REPLCMT; 7=ERR)
   sSCruiseI_CnclCdn_xdu16                        Cancel conditions indicating why active control mode of statemachine cannot be reached: Bit0=RedLvlTooLo, Bit1=FctCoOverruled, Bit2=SigInvld, Bit3=CtrlErr, Bit4=LimrErr, Bit5=Reserved, Bit6=FaderEmgcy, Bit7=EcuSt, Bit8=VehSpd, Bit9=BlkdSteer, Bit10=SigPrcrReqOff, Bit11=SteerTrqReqOff
   sSCruiseI_ReqdState_xdu8              Status   Requested State for SCruise from Bus, mapped to internally. 0-Inactive, 1-HandsOn, 2-HandsFree, 3-Parking, 4=HandsOnInc
   ===================================   ======   ============================================================================================================================================================================================================================================================================================

Output Signals
--------------

   ==============================   ======   ============================================================================================================================================================================================================================================================================================
   Signal Name                      Unit     Description
   ==============================   ======   ============================================================================================================================================================================================================================================================================================
   sSCruiseI_Mod_xdu8               Status   SmartCruise operation mode: 0=Inactive, 1=HandsOn, 2=HandsFree, 3=Parking, 4=HandsOnInc
   sSCruiseI_State_xdu8             Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   ==============================   ======   ============================================================================================================================================================================================================================================================================================

.. only:: confidential

   ==============================   ======   ========================================================================================================================================
   Signal Name                      Unit     Description
   ==============================   ======   ========================================================================================================================================
   sSCruiseI_FuCoCnclCdn_xdu8                FunctionCoordinator s Cancel conditions: Bit0=FctCoLockd, Bit1=FctCoOverruled
   sSCruise_FctCoCtrlState_xdu8     Status   Return value of the FunctionCoordinator
   sSCruise_FeatureState_xdu8       Status   Internal feature state for FunctionCoordinator
   xSCruiseI_HandsOnFadrFac_xdu16   --       Fading factor from a HandsOn (1) mode to non-HandsOn modes (0)
   ==============================   ======   ========================================================================================================================================

Detailed Description
--------------------

   The following graph shows the SCruise state machine. A precondition to leave the state Inin is that SCI is activated via the calibration flag fSCruise_Enable_XDU8
   and the customer coding switch SY_SCI_FUNCT_ACTIVATED. Reasons led to the state NotAvl are bit encoded documented in input signal sSCruiseI_CnclCdn_xdu16.
   The cancel conditions set are hold until the state NotAvl is reached and the bus request sSCruiseI_ReqdState_xdu8 turned to inactive.

   .. image:: SCruiseState_CalMan_StatesOverview.drawio.png

   The mode handling is done according to the following state machine. While SCruise is not activated the mode is set to Inactive.
   While SCruise is active the requested mode is taken over directly. During fadeout the last mode is hold and no new mode request is accepted.
   The hands on fading factor xSCruiseI_HandsOnFadrFac_xdu16 is calculated based on the current mode.
   In case the mode is Inactive the fading factor is set to 0. In case any kind of HandsOn mode is requested as initial mode the HandsOn fading factor is directly set to 1.
   In cases of mode changes the HandsOn fading factor is either ramped to 0 in case no HandsOn mode is requested any more or ramped to 1 in case any HandsOn mode is newly requested.

   .. image:: SCruiseState_CalMan_ModesOverview.drawio.png


Calibration/Application Parameters
==================================

   ==============================   ====   =========   ==================================================================================
   Parameter Name                   Unit   Range       Description
   ==============================   ====   =========   ==================================================================================
   fSCruise_Enable_XDU8             --     0..1        Flag to enable the Smart Cruise Interface
   xSCruise_HandsOnRampGrdt_XDU16   1/s    0.5..1000   Gradient of ramping to a HandsOn mode and from a HandsOn mode to non-HandsOn modes
   ==============================   ====   =========   ==================================================================================

.. only:: confidential

.. include:: SCruiseState_CalMan_VT.irst

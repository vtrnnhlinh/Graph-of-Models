﻿RPCSpeedControllerSRA
#########################

Short Description
=================

The component RPCSpeedControllerSRA contains the second controller (the rack speed controller) for RPC.
Based on the deviation of nominal rack speed and the current rack speed this controller calculates a motor torque to reach this nominal rack speed.
* CalcNominalMotorTorque - Contains a PID controller to compute NominalMotorTorque
* LimitNominalMotorTorque - Computed torque is limited to maximum physically possible range during other cases.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RPCSpeedControllerSRA.PNG

   Input Signals
   """""""""""""

   =========================================   ==========   ============   ===============================================================================================================================
   Signal Name                                 Unit         Range          Description
   =========================================   ==========   ============   ===============================================================================================================================
   fRPCI_Activate_xdu8                         n.a          0..1           Flag for the activation of the RPC controller
   vRPCI_NominalRackSpeedLimited_xds16         mm/s         -250..250      Norminal rack speed from RPC Pos controller (with limitation)
   vApplI_RackSpeed_xds16                      mm/s         -250..250      rack speed [mm/s]
   sFltManI_EcuChannelRole_xdu8                n.a          0..1           Ecu role for deciding Ecu master or slave
   mApplI_LimitedMotorTorque_xds16             Nm           -12..12        Limited motor torque
   xApplI_GearSign_xds8                        n.a          -1..1          sign of the steering gear
   =========================================   ==========   ============   ===============================================================================================================================

   Output Signals
   """"""""""""""

   =====================================   ====   =========   =========================================================================
   Signal Name                             Unit   Range       Description
   =====================================   ====   =========   =========================================================================
   mRPCI_NominalMotorTorque_xds16          Nm     -12..12     Nominal motor torque RPC
   =====================================   ====   =========   =========================================================================

   Measurement Signals
   """""""""""""""""""

   =================================================   ==========   =======================   =====================================================================================================
   Signal Name                                         Unit         Range                     Description
   =================================================   ==========   =======================   =====================================================================================================
   mRPC_NominalMotorTorqueUnSat_xds32                  Nm           -24..24                   Unlimited controllertorque (PID-torques)
   mRPC_NominalMotorTorqueP_xds32                      Nm           -10..10                   Measurmentvalue: P-part speed controller (LowRes)
   mRPC_NominalMotorTorqueI_xdf32                      Nm           -10..10                   Measurmentvalue: I-part speed controller (LowRes)
   mRPC_NominalMotorTorqueD_xds32                      Nm           -10..10                   Measurmentvalue: D-part speed controller (LowRes)
   vRPC_RackSpeedDiff_xdf32                            n.a          -250..250                 Difference of nominal and actual rack speed
   mRPC_SaturationCutOffPart_xds32                     Nm           -2147483648..2147483647   Saturation overhang NominalMotorTorqueLimited. Used for antiwindup of I-part of RackSpeed-controller
   mRPC_CutOffFromLimMmot_xds32                        Nm           -2147483648..2147483647   NominalMotorTorque CutOff from Limit MotorTorque
   =================================================   ==========   =======================   =====================================================================================================

   Calibration/Application Parameters
   """"""""""""""""""""""""""""""""""

   ================================================   =========   =========   ====================================================================
   Parameter Name                                     Unit        Range       Description
   ================================================   =========   =========   ====================================================================
   xRPC_RackSpeedCtrlP_XDF32                          s*Nm/mm     0..20       p-part speedcontroller RPC-SRA [s*Nm/mm]
   xRPC_RackSpeedCtrlD_XDF32                          s^2*Nm/mm   0..1        d-part speedcontroller RPC-SRA [s^2*Nm/mm]
   xRPC_RackSpeedCtrlI_XDF32                          Nm/mm       0..1000     i-part speedcontroller RPC-SRA [Nm/mm]
   mRPC_NominalMotorTorqueIMax_XDF32                  n.a         0..8        saturation i-part speedcontroller RPC-SRA
   fRPC_UseLimitedMotorTorque4CutOff_XDU8             n.a         0..1        Flag for using LimitedMotorTorque for CutOff calculation (Anti Wind-up)
   mRPC_MotorTorqueCutOffThreshold_XDU16              n.a         0..12       Threshold for activation of Anti Wind-up
   tRPC_TimeCycle_XDU8                                ms          1..10       RPC time cycle
   qRPC_FrequencyCycle_XDU16                          n.a         100..1000   Frequency cycle of RPC (1000/RPC time cycle)
   ================================================   =========   =========   ====================================================================

.. include:: RPCSpeedControllerSRA_CalMan_VT.irst

Torque Reduction Coordinator
############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The TorqueReductionCoordinator provides linear fade-in and –out for downscaling and rising torque rate limitation. It receives the required target reduction and fading rates from the 
respective reduction functionalities.Customer calibration is only available for channel “Undervoltage”.All other reduction channels protect components of the steering mechanics and
must be calibrated internally by BOSCH Automotive Steering. The following chapters, apart from a general overview, only supply information regarding channel “Undervoltage”.


Block Diagram
=============

.. image:: TorqueReductionCoordinator_CalMan_BlockDiagram.png



Input Signals
-------------

=================================   =====   ===========================================================
Name                                Unit    Description
=================================   =====   ===========================================================
sApplI_VehicleRunning_xdu8                  state vehicle running(0 Vehicle stopp, 1 Vehicle is moving)
=================================   =====   ===========================================================

Output Signals
--------------

==================================  ====  =====================
Signal Name                         Unit  Description
==================================  ====  =====================
xApplI_HLReductionFactor_xdu16            Lowest of all high level reduction factors
xApplI_HLCharCurveBuckleFact_xdu16        Factor for the motor characteristic curve buckling
yApplI_HLMaxTorqueGradient_xdu16          Lowest of all high level torque gradients
==================================  ====  =====================

.. only:: confidential

   ==================================  ====  =====================
   Signal Name                         Unit  Description
   ==================================  ====  =====================
   xtcActualTorqueRedLevel_xau16             active reduction for every channel
   xtcActualGradientRedLevel_xau16           active reduction of the gradient reduction for every channel
   xtcActualMotCharTorqLevel_xau16           active limitation of the motor characteristic for every channel
   ==================================  ====  =====================

Detailed Description
--------------------
This component receives different reduction requests from so called "reduction functions", determines the
lowest reductions request and provides this value to the functionalities who are responsible for performing
the reduction of the motor torque.

.. only:: confidential

   There are three reductions factors: torque reduction, buckling the motor torque characteristic curve and torque gradient limitation.
   Each of these reductions factors takes the lowest value of their associated internal array(xtcActualTorqueRedLevel, xtcActualMotCharTorqLevel or xtcActualGradientRedLevel).
   
   .. image:: TorqueReductionCoordinator_Reduction_Calculation.png

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

====================================   =====   =============    =============================================
Parameter Name                         Unit    Range            Description
====================================   =====   =============    =============================================
mtrcMaxTorGradVehicleMoving_XDU16      Nm/ms   0.001 .. 2.5     max. torque gradient - vehicle is moving or the speed signal is invalid
mtrcMaxTorGradVehicleStanding_XDU16    Nm/ms   0.001 .. 2.5     max. torque gradient - vehicle is staying (no speed)
====================================   =====   =============    =============================================

.. include:: TorqueReductionCoordinator_CalMan_VT.irst

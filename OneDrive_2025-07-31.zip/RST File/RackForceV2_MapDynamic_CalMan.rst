RackForceV2_MapDynamic
######################

Short Description
=================

The rack force module RackForce MapDynamic provides the rack force depends on the validity of rack force from RFMD.
 	
.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!
   

   Block Diagram
   =============

   .. image:: RackForceV2_MapDynamic_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ================================   ======   ==============================
   Signal Name                        Unit     Description
   ================================   ======   ==============================
   kApplI_RackForce_xds16              N       rack force
   ================================   ======   ==============================


   Output Signals
   --------------

   =================================   ====   ===========================================================
   Signal Name                         Unit   Description
   =================================   ====   ===========================================================
   kApplI_RackForceMerge_xds16         N      Merged RackForce
   xRackForceI_RatioD2C_xdu16                 Ratio of the merged force (1=100% Dynamic, 0=100% Comfort)
   =================================   ====   ===========================================================


   Detailed Description
   --------------------
   RackForce from RFMD is checked for validity and then it provides the RackForce and RatioD2C depend on the validity of RackForce.   
   If the RackForce from RFMD is not valid, the Rackforce is set to SNA. Otherwise, the result of RFMD is taken.
   
   Calibration/Application Parameters
   ==================================
 
 
.. include:: RackForceV2_MapDynamic_CalMan_VT.irst
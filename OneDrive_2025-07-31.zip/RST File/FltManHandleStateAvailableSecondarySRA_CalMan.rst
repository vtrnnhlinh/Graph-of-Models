FltManHandleStateAvailableSecondarySRA
######################################

.. only:: confidential



Short Description
=================
    The FltManHandleStateAvailableSecondarySRA calculates the flags DisableLocal and gives Available Mode state machine based on the active error events and current channel role.

Block Diagram
=============

.. image:: FltManHandleStateAvailableSecondarySRA_CalMan_BlockDiagram.png


Input Signals
-------------


==========================================   ====   ===============================================================================================================================
Signal Name                                  Unit   Description
==========================================   ====   ===============================================================================================================================
sFltManI_Events_xau8                                An array of error events. 0-No Error, 1- Error
sFltManI_EcuChannelRole_xdu8                        Indicated whether current channel is Master
==========================================   ====   ===============================================================================================================================


Output Signals
--------------
==========================================   ====   ===============================================================================================================================
Signal Name                                  Unit   Description
==========================================   ====   ===============================================================================================================================
   sFltMan_AvailableMode_xdu8                       State variable of Available Mode state machine                    
==========================================   ====   ===============================================================================================================================

Detailed Description
--------------------
The task of the Available state handler is to manage the functionality of Centralized Fault Management that is specific to the phase of operation when the MCU is actively controlling the output stage.Decision whether to proceed operating in Normal or FailOp mode,
or to completely disable the local actuation channel based on active error events and current Ecu channel role.



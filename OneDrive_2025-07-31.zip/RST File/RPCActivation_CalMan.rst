﻿RPCActivation
#########################

Short Description
=================

The RPCActivation Component activates the RPC Controller in SRA systems.
It checks the conditions required and activates the RPC accordingly.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RPCActivation.PNG

   Input Signals
   """""""""""""

   =========================================   ==========   ============   ===============================================================================================================================
   Signal Name                                 Unit         Range          Description
   =========================================   ==========   ============   ===============================================================================================================================
   sApplI_SteeringAngleState_xdu8              n.a          0..4           Steering angle status
   lApplI_RackPosition_xds16                   mm           -200..200      Current rack position
   vApplI_RackSpeed_xds16                      mm/s         -250..250      Current rack speed
   lTpcI_ReqRackPosition_xds16                 mm           -200..200      Requested rack position
   sFadrI_Mode_xdu8                            n.a          0..2           Current fading state
   sAssCtrlI_AssistMode_xdu8                   n.a          0..4           Current assistance state of the AssistanceController
   =========================================   ==========   ============   ===============================================================================================================================

   Output Signals
   """"""""""""""

   =====================================   ====   =========   =========================================================================
   Signal Name                             Unit   Range       Description
   =====================================   ====   =========   =========================================================================
   fRPCI_Activate_xdu8                     n.a    0..1        flag for the activation of the RPC controller
   =====================================   ====   =========   =========================================================================

   Measurement Signals
   """""""""""""""""""

   =================================================   ==========   =======================   =====================================================================================================
   Signal Name                                         Unit         Range                     Description
   =================================================   ==========   =======================   =====================================================================================================
   sRPC_ActReason_xdu16                                n.a          0..255                    reason for deactivating RPC-mode
   =================================================   ==========   =======================   =====================================================================================================

.. include:: RPCActivation_CalMan_VT.irst

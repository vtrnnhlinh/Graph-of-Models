TestFunctions
##################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

Refer the following for details:
\sgdcc_eps_sdk_dev\EpsDriveSW\DesignSet\Infrastructure\TestFunctions\FaultInjectionSupp\doc\Introduction_to_SCIFI_SW.pptx@@\main\1
\sgdcc_eps_sdk_dev\EpsDriveSW\DesignSet\Infrastructure\TestFunctions\FaultInjectionSupp\doc\SCIFI_UserManual_Template.xlsx@@\main\4



Block Diagram
=============



Input Signals
-------------

==================================  ====   ========================
Signal Name                         Unit   Description
==================================  ====   ========================
mApplI_GradTorsionBarTorque_xds16   Nm     HW LIB: torque gradient
==================================  ====   ========================


Output Signals
--------------

=================================   ====   ==============================================
Signal Name                         Unit   Description
=================================   ====   ==============================================
mPatGenI_Pattern_xds32              Nm     Oscillation pattern for TBT or MMOT injection
mPatGenI_paramEXT_xds16             Nm     Generated excitation signal
sPatGenI_ActiveSection_xdu8                Current active section of Pattern Generator
sPatGenI_Active_xdu8                       PatternGenerator active
=================================   ====   ==============================================


Detailed Description
--------------------
Refer the following for details:
\sgdcc_eps_sdk_dev\EpsDriveSW\DesignSet\Infrastructure\TestFunctions\FaultInjectionSupp\doc\Introduction_to_SCIFI_SW.pptx@@\main\1
\sgdcc_eps_sdk_dev\EpsDriveSW\DesignSet\Infrastructure\TestFunctions\FaultInjectionSupp\doc\SCIFI_UserManual_Template.xlsx@@\main\4



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!
	Tuning switches are not available, only test switches are there.

======================================   =====   =====   =============================================
Parameter Name                           Unit    Range   Description
======================================   =====   =====   =============================================
======================================   =====   =====   =============================================

.. only:: confidential

   Provide a table of internal calibration parameters.

   ========================================   =====   ===============   ========================================================================================================
   Parameter Name                             Unit    Range             Description
   ========================================   =====   ===============   ========================================================================================================
   zPatGen_PRBS_Bits_XDU8                             0..32             Bits of shift register
   yPatGen_PRBS_ShiftRegisterInit_XDU32               0..4294967295     coefficients ParameterID
   yPatGen_PRBS_Coefficients_XDU32                    0..4294967295     coefficients ParameterID
   fPatGen_PRBS_ReinitOfShiftRegister_XDU8            0..1              reinitialize shift register after period
   zPatGen_Wavetype_XDU8                              0..7              Wavetype Selection (0=none, 1=PRBS, 2=Sine, 3=Cosine, 4=SineSweep, 5=CosineSweep, 6=Square, 7=FreeStyle)
   zPatGen_Periods_XDU8                               0..255            Perioden ParameterID
   zPatGen_FirstSection_XDU8                          0..3              Starting Section selector
   zPatGen_LastSection_XDU8                           0..3              Ending Section selector
   fPatGen_EnableNVH_XDU8                             0..1              Enable or disable NVH
   sFaInjI_InjectionActivation_XDU8                   0..2              Activation switch error injection
   mPatGen_PatternOffset_XAS32                Nm      -250..250         motor torque Offset value ParameterID
   mPatGen_PatternAmplitude_XAU32             Nm      0..250            amlitude motor torque ParameterID
   tPatGen_FreeStylePatternTime_XAU16         s       8                 Time between each point of the FreeStyle pattern (WaveType=7)
   yPatGen_FreeStylePatternAmp_XAS16          Nm      -125..125         Amplitude of the FreeStyle pattern (WaveType=7)
   ========================================   =====   ===============   ========================================================================================================

.. include:: PatternGenerator_CalMan_VT.irst

Rack Wheel Converter
####################


Short Description
=================

Conversion of Rackposition to front wheel angle and vice versa.
   
.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RackWheelConverter_CalMan_BlockDiagram.png


   Input Signals
   -------------

   =================================   ====   ===================================================================
   Signal Name                         Unit   Description
   =================================   ====   ===================================================================  
   lApplI_RackPosition_xds16           mm     rack position [mm]
   lRackPoI_LTCorrRackPos_xds16        mm     long term correction angle related to rack position [mm]
   lRackPoI_STCorrRackPos_xds16        mm     short term correction angle related to rack position [mm]
   sApplI_SteeringAngleLinState_xdu8          state of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
   =================================   ====   ===================================================================


   Output Signals
   --------------

   =====================================   =======   ===============================================================================
   Signal Name                             Unit       Description
   =====================================   =======   ===============================================================================   
   wRWConI_AbsFrontWheelAngleCorr_xdu16    degree     absolute front wheel angle with long-time steering angle correction
   wRWConI_AbsFrontWheelAngle_xdu16        degree     absolute front wheel angle
   wRWConI_FrontWheelAngleCorr_xds16       degree     front wheel angle with long-time steering angle correction
   wRWConI_FrontWheelAngleOffset_xds16     degree     front wheel angle offset due to long- and short-time steering angle correction
   wRWConI_FrontWheelAngle_xds16           degree     front wheel angle
   xRWConI_RatioRackPos2WheelAngle_xdu16              ratio between rack position and front wheel angle
   =====================================   =======   ===============================================================================


   Detailed Description
   --------------------

   The Rack Wheel Converter converts the measured rack wheel position into a front wheel angle.
   In addition, a Long term and a Short term rack position correction is used to correct the calculated front wheel angle.
   A rack position offset is calculated which in turn is converted to a corresponding front wheel angle offset. 
   This offset angle for the front wheels is then subtracted from the calculated front wheel angle value.

   The Rack Wheel Converter can also be used to convert the input wheel angle to rackposition.

   Hint: Tuning will be handled with a help of Matlab script.

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   =====================================   =======   ========   =======================================
   Parameter Name                          Unit      Range       Description
   =====================================   =======   ========   =======================================
   wRWCon_MaxWheelAngle_XDU16              degree    0..120     maximum allowed convertable wheel angle
   wRWCon_WheelAngle_XAU16                 degree    0..75      wheel angle array
   lRWCon_RackPosition_XAU16               mm        0..150     rack position array
   xRWCon_RackPos2WheelAngleRatio_XAU16              0..1,95    ratio of rack position to wheel angle
   =====================================   =======   ========   =======================================

.. include:: RackWheelConverter_CalMan_VT.irst

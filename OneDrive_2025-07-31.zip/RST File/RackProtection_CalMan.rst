Rack Protection
###############

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The function "Rack Protection" reduces the characteristic motor curve to a safe value so that it can act against damage.


Block Diagram
=============

.. only:: not confidential

   .. image:: RackProtection_CalMan_Customer_BlockDiagram.png

.. only:: confidential

	.. image:: RackProtection_CalMan_Confidential_BlockDiagram.png


Input Signals
-------------

==================================   ======   =========================================================
Signal Name                          Unit     Description
==================================   ======   =========================================================
mApplI_LimitedMotorTorque_xds16      Nm       limited motor torque
mApplI_TorsionBarTorque_xds16        Nm       HW LIB: torsion bar torque
vVehSpI_AbsMaxSafeVehSpd_xdu16       km/h     Abs. vehicle speed: Secured over hole vehicle speed range
vApplI_SteeringAngleSpeed_xdu16      °/s      speed of the steering angle
xApplI_GearSign_xds8                          sign of the steering gear
==================================   ======   =========================================================



Output Signals
--------------
.. only:: not confidential

   The reduction is performed via a request to the TorqueReductionCoordinator.
   
.. only:: confidential

   The reduction is performed via a request tcSetMotorCharTorqueAxis()  to the TorqueReductionCoordinator.
   This function is called when the ReductionLevel has changend its value.

Detailed Description
--------------------

Individual parts of the mechanical system can be permanently damaged by excess forces or torques. The overall force on the steering rack results from the assistance force of the EPS motor and the torque applied by the driver through the steering wheel.
The there is an unfavorable angular arrangement of the tie rods, the rack of the electric power assisted steering unit is exposed to high bending torques that can subject the rack to plastic deformation under certain circumstances. 
The Rack Protection function reduces the motor characteristic to a safe level, to counteract eventually dangerous forces for steering system.

.. only:: confidential

   The function realizes the reduction of the motor torque for rack protection. If the vehicle stopped (~0km/h), the steering angle speed
   is not too high and the torsion bar torque is too high, the target reduction level of motor characteristic torque is given to torque 
   reduction coordinator.

Calibration/Application Parameters
==================================

==============================================   =====   =======   ====================================================
Parameter Name                                   Unit    Range         Description
==============================================   =====   =======   ====================================================
mRackProt_LimitRedMotorTorque_XDU16              Nm      0..10     limit motortorque for reduction rackprotection
mRackProt_MaxAbsTorsionBarTorqueRampUp_XDU16     Nm      0..10     maximal torsion bar torque for RampUp
mRackProt_MinAbsTorsionBarTorqueRampDown_XDU16   Nm      0..10     minimal torsion bar torque for RampDown
tRackProt_TimeRedRampDown_XDU16                  SEC     0..10     wait time until ramp down
tRackProt_TimeRedRampUp_XDU16                    SEC     0..10     wait time until ramp up
vRackProt_MaxAbsSteeringAngleSpeed_XDU16         °/s     0..1500   maximal steering angle speed for reduction
vRackProt_MaxAbsVehicleSpeed_XDU16               km/h    0..100    maximal vehicle speed for reduction
xRackProt_GradRedRampDown_XDU16                          0..1      reduction gradient for negative gradient [factor/ms]
xRackProt_GradRedRampUp_XDU16                            0..1      reduction gradient for positive gradient [factor/ms]
xRackProt_TargetReductionLevel_XDU16                     0..1      target reduction level
==============================================   =====   =======   ====================================================


.. only:: confidential

	.. Move confidential parameters from the above table down here, if applicable.

	.. include:: RackProtection_CalMan_VT.irst

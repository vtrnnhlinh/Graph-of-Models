﻿TorqueSignalConditioningSupp
############################

NOTE - This is a project specific component and the details shall be updated by respective customer project teams


.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The component TorqueSignalConditioningSupp forwards the calculated torsion bar torque from the component TorqueSignalConditioningMain

.. only:: confidential

   NOTE: This is a project specific component and the details shall be updated by respective customer project teams.

Block Diagram
=============

Input Signals
-------------


   ===========================================   =======   ===========================================================================================
   Signal Name [HwLib]                           Unit      Description
   ===========================================   =======   ===========================================================================================
   mTscI_ExtrapolTBT_xds16                       Nm        extrapolated torsion bar torque
   ===========================================   =======   ===========================================================================================

Output Signals
--------------

   =====================================     =======   ==========================================================================================================
   Signal Name [Internal]                    Unit      Description
   =====================================     =======   ==========================================================================================================
   mTscI_TorsionBarTorque                    Nm        extrapolated Torsion bar torque without limitation
   fTscI_Use_GradXtplTBT_xdb                 -         to use gradient extrapolated TBT
   =====================================     =======   ==========================================================================================================


Calibration/Application Parameters
==================================

.. only:: confidential

   ======================================      =========   =========   ===========================================================================
   Parameter Name                              Unit    	   Range       Description
   ======================================      =========   =========   ===========================================================================
   fTsc_Use_GradXtplTBT_XDU8                   -           0…1         Use the extrapolated averaged TBT from TSC check to calculate the gradient
   ======================================      =========   =========   ===========================================================================




.. include:: TscSupp_CalMan_VT.irst

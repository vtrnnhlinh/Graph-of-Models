Friction Compensation
#####################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

This function calculates the actual friction of the steering gear based upon the hysteresis of the motortorque that is needed to cause a change of the steering direction. 
The calculated friction torque is added to the limited motortorque to compensate the friction effects.

Block Diagram
=============
.. image:: FrictionCompensation_CalMan_BlockDiagram.png

.. only:: confidential

   FrictionTorqueFilter
   ====================
   .. image:: FrictionTorqueFilter_blockDiagram.png
   
   Saturation
   ==========
   .. image:: Saturation_blockDiagram.png

   SteeringangleHysteresisFilter
   =============================
   .. image:: SteeringangleHysteresisFilter_blockDiagram.png

   TorqueHysteresisMeasurement
   ===========================
   .. image:: TorqueHysteresisMeasurement_blockDiagram.png

Input Signals
-------------

=================================   ========   ======================================
Signal Name                         Unit       Description
=================================   ========   ======================================
mApplI_LimitedMotorTorque_xds16     Nm         limited motor torque from HwLib
sApplI_SteeringAngleState_xdu8                 status steering angle from rotor angle not corrected 
wApplI_SteeringAngle_xds16          °          corrected steering angle
vVehSpI_AbsAvgVehSpd_xdu16          km/h       Average vehicle speed. Goal: be as close to the actual speed over ground as possible
nApplI_RotorSpeedFilt_xds16         1/min      filtered rotor speed
xApplI_GearSign_xds8                           steering gear sign
mApplI_TorsionBarTorque_xds16       Nm         HW LIB: torsion bar torque
xRackForceI_RatioD2C_xdu16                     Ratio of the merges force (1=100% Dynamic, 0=100% Comfort)
=================================   ========   ======================================

Output Signals
--------------

=================================   ====   =======================================================================
Signal Name                         Unit   Description
=================================   ====   =======================================================================
mFriCoI_CompensationTorque_xds16    Nm     compensation torque for torque summatione
=================================   ====   =======================================================================


Detailed Description
--------------------

The effiective Friction torque is  the summation of filtered motor torque and converted torsion bar torque to effective torque.
Friction Detection is detecting mechanical friction in the steering gear.Therefore its measuring the Limited friction Torque hysteresis when gear is in a low rack force state.
Then Compensation torque calculated as hysteresis around the effective torque by adding the limited friction torque.


Calibration/Application Parameters
==================================

============================================   =====   ========   =============================================
Parameter Name                                 Unit    Range      Description
============================================   =====   ========   =============================================                                        
mFriCo_FrictionCompFixValue_XDU16              Nm      0..0.49    compensation value in case function is deactivated via customer coding
mFriCo_FrictionCompMin_XDU16                   Nm                 minimum value, which always has to be compensated (in case function is activated via customer coding)
mFriCo_FrictionCompMax_XDU16                   Nm                 maximum value, which is compensated (in case function is activated via customer coding)
xFriCo_CompensationTorqueFilter_XDU16                  0.001..1   filter constant for compensation value filter
mFriCo_FrictionThreshold4Error_XDU16                   0..2       threshold for triggering an high friction error                                                                                                 
============================================   =====   ========   =============================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   
   ===================================================   =====  ===========  =============================================
   Parameter Name                                        Unit   Range        Description
   ===================================================   =====  ===========  =============================================
   mFriCo_MaxTorqueChange4Learn_XDU16                    Nm     0..1         maximum torque change between to cycles for measure hysteresis torque
   nFriCo_MaxRotorSpeed4Learn_XDU16                      1/min  0..3000      maximum rotor speed for measure hysteresis torque
   vFriCo_MinVehicleSpeed4Learn_XDU16                    km/h   0..250       minimum vehicle speed for measure hysteresis torque
   vFriCo_MaxVehicleSpeed4Learn_XDU16                    km/h   10..250      maximum vehicle speed for measure hysteresis torque
   wFriCo_MaxSteeringAngle4Learn_XDU16                          0..100       maximum steering angle for measure hysteresis torque
   zFriCo_UseFastShortTermFilterFactor_XDU8                     0..254       number of times the fast (xFriCo_ShortTermFrictionFilterConstantRampUp_XDU16) short term filter factor is used
   wFriCo_SteeringAngleHysteresis_XDU16                         0..10        width of hysteresis for steering angle hysteresis filter
   xFriCo_FrictionWeightFactor_XDU16                            0..1.5       factor on filtered friction torque
   xFriCo_LongTermFrictionFilterConstant_XDU16                  0.001..1     filter constant for long term filter
   xFriCo_ShortTermFrictionFilterConstant_XDU16                 0.001..1     filter constant for long term filter
   mFriCo_FrictionDeadZone_XDU16                  Nm            0..1         dead zone on filtered friction
   xFriCo_FilterConstantMotorTorqueFilter_XDU16                 0.001..1     filter constant for motor torque filter  
   xFriCo_ShortTermFrictionFilterConstantRampUp_XDU16           0.001 .. 1   filter constant for short term filter during the fisrt cycles (zFriCo_UseFastShortTermFilterFactor_XDU8)
   **System Parameter:** 
   xsyRatioEfficiency_XDU16                                     0 .. 0.2     scaling factor for torsion bar torque to motor torque (system parameter of steering gear)
   ===================================================   =====  ===========  =============================================
                                                    


.. include:: FrictionCompensation_CalMan_VT.irst

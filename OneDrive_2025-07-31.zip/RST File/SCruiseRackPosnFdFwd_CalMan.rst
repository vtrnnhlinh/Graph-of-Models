.. only:: not confidential

   Smart Cruise Signal Processor | Rack Position Feed Forward
   ###########################################################

   In this component the received Rack position from the SCruise Input Limiter component is converted using Transfer function.

.. only:: confidential

   Smart Cruise Signal Processor | Rack Position Feed Forward
   ###########################################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   In this component the received Rack position from the Input Limiter component is converted using Transfer function.
   The order of the transfer function can be varied by adapting the indivdual calibration parameters for the different indices of Numerator and Denominator.
   The TF is implemented in such a way that 2 discrete TFs are cascaded back to back.

   Block Diagram
   =============

   .. image:: SCruiseRackPosnFdFwd_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ================================  ======   =============================================================================
   Signal Name                       Unit     Description
   ================================  ======   =============================================================================
   lSCruiseI_NomRackPosnLimd_xds32   mm       Nominal rack position for Rack Position Feed Forward (after input limitation)
   ================================  ======   =============================================================================

   Output Signals
   --------------

   =============================   ====   ============================================================
   Signal Name                     Unit   Description
   =============================   ====   ============================================================
   lSCruiseI_NomRackPosn_xds32     mm     Nominal Rack Position after Transfer function calculation
   lSCruise_FdFwdTf_xds16          mm     Feed Forward transfer function output
   lSCruise_RefTf_xds16            mm     Reference transfer function output
   =============================   ====   ============================================================


   Detailed Description
   --------------------

   The first transfer function (Feed Forward TF) can be varied from 1st to 5th order
   With the first TF we try to inverse the system. The inverse system reproduces the input of the
   original system. This inversion is similar to a high pass filter.

   The second transfer function (Reference TF) can be varied from 1st to 2nd order.
   The second TF should only transfer those frequency parts which we need.
   Without the second TF we would then amplify the higher frequencies in a signal (e.g. noise).
   This leads to a vibriation in a car. In most cases the second filter would be a low pass filter.

   The component has a calibration parameter fSCruise_EnblTrnsFnc_XDB to disable the use of Transfer function calculation. In this case the input is passed directly as output.
   The component also has a valid check for the input. In case of invalid input signal, output is set to SNA value.
   In case the output of the transfer function is unstable, then we saturate the output to +/-220mm.
   This value is outside the valid range and is detected in SCruiseNomDrvrTrqCacln which leads a comfort fadeout from SCI to SFC

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   =======================================   ============   ===========   =====================================================
   Parameter Name                            Unit           Range         Description
   =======================================   ============   ===========   =====================================================
   fSCruise_EnblTrnsFnc_XDB                  Bitanzeige      0;1          1=TrfFct enabled, 0=TrfFct disabled
   xSCruise_FdFwdTfNumIdx0_XDF32             NA             -1000..1000   Array[0] value
   xSCruise_FdFwdTfNumIdx1_XDF32             NA             -1000..1000   Array[1] value
   xSCruise_FdFwdTfNumIdx2_XDF32             NA             -1000..1000   Array[2] value
   xSCruise_FdFwdTfNumIdx3_XDF32             NA             -1000..1000   Array[3] value
   xSCruise_FdFwdTfNumIdx4_XDF32             NA             -1000..1000   Array[4] value
   xSCruise_FdFwdTfNumIdx5_XDF32             NA             -1000..1000   Array[5] value
   xSCruise_FdFwdTfDenomIdx0_XDF32           NA              0.01..1000   Array[0] value
   xSCruise_FdFwdTfDenomIdx1_XDF32           NA             -1000..1000   Array[1] value
   xSCruise_FdFwdTfDenomIdx2_XDF32           NA             -1000..1000   Array[2] value
   xSCruise_FdFwdTfDenomIdx3_XDF32           NA             -1000..1000   Array[3] value
   xSCruise_FdFwdTfDenomIdx4_XDF32           NA             -1000..1000   Array[4] value
   xSCruise_FdFwdTfDenomIdx5_XDF32           NA             -1000..1000   Array[5] value
   xSCruise_RefTfNumIdx0_XDF32               NA             -1000..1000   Array[0] value
   xSCruise_RefTfNumIdx1_XDF32               NA             -1000..1000   Array[1] value
   xSCruise_RefTfNumIdx2_XDF32               NA             -1000..1000   Array[2] value
   xSCruise_RefTfDenomIdx0_XDF32             NA              0.01..1000   Array[0] value
   xSCruise_RefTfDenomIdx1_XDF32             NA             -1000..1000   Array[1] value
   xSCruise_RefTfDenomIdx2_XDF32             NA             -1000..1000   Array[2] value
   =======================================   ============   ===========   =====================================================


   .. include:: SCruiseRackPosnFdFwd_CalMan_VT.irst

﻿CompensateIncreasedFriction
############################

Short Description
=================

The compensate Increase Friction functionlaity calculates the compensation torque needed to counter the effect of the increased friction which develops in the steering gear due to
several reasons e.g Low temperature. It also calculates the Load factor ratio which will used to compensate the damping effect due to increased frcition.

Block Diagram
=============

Compensation Torque Calculation
---------------------------------------
.. only:: confidential
.. image:: CompensationTorqueCalc_Calman.png

LoadFactor Calculation
---------------------------------------
.. only:: confidential
.. image:: ActiveReturnBoostFactorCalculation_Calman.png


Output Signals
--------------

=======================================   ====   ===============================================================================
Signal Name                               Unit   Description
=======================================   ====   ===============================================================================
mCompIncFricI_CompensationTorque_xds16     Nm     Compensation torque for increased friction
xCompIncFricI_ActiveRetBoost_xdu16                ActiveReturn Boost factor ratio
=======================================   ====   ===============================================================================

Input Signals
-------------

=======================================   ====   ==============================================================================
Signal Name                               Unit   Description
=======================================   ====   ==============================================================================
mApplI_DriverTorque_xds16                  Nm     Driver torque
mDetIncFricI_AdaptedBaseFriction_xdu16     Nm     Adapted Base Friction for RackForce
nApplI_RotorSpeedFilt_xds16                rpm    Filtered Rotor Speed
vVehSpI_AbsAvgVehSpd_xdu16                 Kph    Abs. vehicle speed averaged: processed
xRackForceI_RatioD2C_xdu16                 -      Ratio of the merges force (1=100% Dynamic, 0=100% Comfort)
=======================================   ====   ==============================================================================


Detailed Description
--------------------
In case of increased friction, for example due to low temperature, the steering system behavior, in terms of steering feel is different to normal temperature (higher friction / damping feel). Therefore, several OEMs request a low temperature compensation.
In past with combustion engines the heating up of the steering gear was analog to the heating up of the interior, so the damped steering feel, fits to the behavior of the complete vehicle. In EVs the interior will heat up, but the steering gear will stay at the low temperature or in worst case, the steering system will cool down.

To compensate the low temperature behavior, two parts are needed, a detection of the changed system behavior and a compensation of the friction and damping effect, to have a temperature independent steering feel.
The Functionality calculates the compensation torque to loadfactor ratio to cunter the increased friction behaviour due to Low temeperature.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

========================================================     =====   ========   ===============================================================================================
Parameter Name                                               Unit    Range      Description
========================================================     =====   ========   ===============================================================================================
mCompIncFric_MaxCompensationTorque_XDU16                     Nm      0..2       Max allowed motor torque for compensation
xCompIncFric_BaseFricBasedDampCompFactorRFMC_XAU16                   0..2       DampComp factor dep on BaseFriction difference for RFMC
xCompIncFric_BaseFricBasedDampCompFactorRFMD_XAU16        	         0..2       DampComp factor dep on BaseFriction difference for RFMD
mCompIncFri_CompTorqueBasedOnRotSpdAndVehSpeedRFMC_XAU16     Nm      0..2       RackSpeed and VehicleSpeed dependant damping compensation based on BaseFriction change for RFMC
mCompIncFri_CompTorqueBasedOnRotSpdAndVehSpeedRFMD_XAU16     Nm      0..2       RackSpeed and VehicleSpeed dependant damping compensation based on BaseFriction change for RFMD
xCompIncFric_ActRetFacDepVehSpdAdaptedBaseFricRFMC_XAU16             0..3       Active return factor depends on vehicle speed and adapted base friction for RFMC
xCompIncFric_ActRetFacDepVehSpdAdaptedBaseFricRFMD_XAU16             0..3       Active return factor depends on vehicle speed and adapted base friction for RFMD
xCompIncFric_MaxActiveReturnBoost_XDU16                              0..3       Max Active Return Boost Factor
xCompIncFric_ActRetFacDepDriverTrq_XAU16                             0..3       Factor to change ActiveReturn Factor Ratio dependant on DriverTorque
========================================================     =====   ========   ===============================================================================================


.. include:: CompensateIncreasedFriction_CalMan_VT.irst

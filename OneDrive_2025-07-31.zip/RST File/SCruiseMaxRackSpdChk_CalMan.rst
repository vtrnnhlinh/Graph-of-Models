.. only:: not confidential

   Smart Cruise Limiter | Max Rack Speed Check
   ###########################################

    A monitoring of the maximum rack speed calculated by the Main component SCruise Limiter Max Rack Speed is performed here (Diverse calculation of Limited Rack Speed is performed here).

.. only:: confidential

   Smart Cruise Limiter | Max Rack Speed Check
   ###########################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   A monitoring of the maximum rack speed calculated by the Main component (SCruiseMaxRackSpd) is performed here (Diverse calculation of Limited Rack Speed is performed here).
   If the monitoring detects a failure, the safe RackSpdLim is set in the DisblRackSpd component.

   - There are no additional parameter used in comparison to SCruiseMaxRackSpd.
   - In case of valid monitoring (fSCruiseLimrI_RackSpdMonSafeOk_xdb == 1) the input vSCruiseLimrI_RackSpdLim4Chk_xdu16 will be mapped to the output vSCruiseLimrI_RackSpdLim_xdu16.
   - In case of valid monitoring (fSCruiseLimrI_RackSpdMonSafeOk_xdb == 1) the input vSCruiseLimrI_PosRackSpdLim4Chk_xds16 will be mapped to the output vSCruiseLimrI_PosRackSpdLim_xds16.
   - In case of valid monitoring (fSCruiseLimrI_RackSpdMonSafeOk_xdb == 1) the input vSCruiseLimrI_NegRackSpdLim4Chk_xds16 will be mapped to the output vSCruiseLimrI_NegRackSpdLim_xds16.
   - In case of a monitoring issue (fSCruiseLimrI_RackSpdMonSafeOk_xdb == 0) the value of vSCruiseLimr_MaxRackSpdHandsFree_XAU16 will be mapped to the output vSCruiseLimrI_RackSpdLim_xdu16,
     vSCruiseLimrI_PosRackSpdLim_xds16 and vSCruiseLimrI_NegRackSpdLim_xds16 to avoid an undershoot.
   - Refer to SCruiseMaxRackSpd for application parameter hints.

   Output Signals
   --------------

   =================================   ======   ========================================================================================================
   Signal Name                         Unit     Description
   =================================   ======   ========================================================================================================
   fSCruiseLimr_EssActvChk_xdb                  Indicates whether evasive steering support is requested
   fSCruiseLimr_RackSpdMonSafeOk_xdb            Indicates whether the MaxRackSpd Monitoring reports OK (true) or if they have detected a problem (false)
   sSCruiseLimrI_UsedRackSpdLim_xdu8   Status   Rack Speed Limit used: 0=SFC, 1=HandsOn, 2=Parking, 3=HandsFree, 4=HandsOnInc, 5:ESSactive
   vSCruiseLimrI_RackSpdLim_xdu16      mm/s     max. allowed rack speed checked
   vSCruiseLimrI_PosRackSpdLim_xds16   mm/s     max. allowed positive rack speed with possible limit opening due to driver interaction checked
   vSCruiseLimrI_NegRackSpdLim_xds16   mm/s     max. allowed negative rack speed with possible limit opening due to driver interaction checked
   zSCruiseLimr_JImpChk_xds16          s        inertia impulse counter
   fSCruiseLimrI_RackSpdMonSafeOk               Indicates whether the MaxRackSpd Monitoring reports OK or, detects a problem
   =================================   ======   ========================================================================================================

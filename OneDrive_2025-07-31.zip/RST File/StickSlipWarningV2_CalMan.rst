Stick Slip Warning V2
#########################

.. only:: confidential

   .. warning:: The following Description is for internal use only and is rated as **confidential**!
        
        Parts of this confidential description are in the "official" version as well. Have a look in the NON Confidential Manual for a comparison.
        
Short Description
=================

This function detects freezing water in the steering gear based on combination of various signal pattern and prevents blocking due to frozen water in the steering gear via generated shaking movements.
The corresponding feature also responsible for handling both SFC and RPC related pattern detection through the application of different parameter set.  

Block Diagram
=============
Main Function
-------------
   .. image:: StickSlipWarningV2.png

Detail detection of StickSlip effect
------------------------------------
   .. image:: StickSlipEffect_blockDiagram.png

Detail generation of feedback torque
------------------------------------
   .. image:: GenerationofFeedbackTorque_blockDiagram.png
      :width: 20%

Input Signals
-------------

===================================   =====   =======================================================================================================
Signal Name                           Unit    Description
===================================   =====   =======================================================================================================
nApplI_RotorSpeedFilt_xds16           1/min   Filtered rotor speed
mApplI_TorsionBarTorque_xds16         Nm      HWlib torsion bar torque
mApplI_LimitedMotorTorque_xds16       Nm      Limited motor torque
vVehSpI_AbsMaxSafeVehSpd_xdu16        km/h    Maximum vehicle speed
xApplI_GearSign_xds8                          Sign of steering gear
wApplI_SteeringAngle_xds16            °       Corrected steering angle
sSSWarnSuppI_RpcStatus_xdu8                   Flag for the activation of the RPC controller at RPC-mode: 0 - Inactive, 1 - ModeChange, 2 - Active
xtcActualTorqueRedLevel                       Active reduction for every channel
===================================   =====   =======================================================================================================


Output Signals
--------------

=======================================   =====   ===========================================================================================================================
Signal Name                               Unit    Description
=======================================   =====   ===========================================================================================================================
mApplI_SSWarnTorque_xds16                 Nm      Additional StickSlipWarning torque that will be added at the very end of the limitation chain (unreduced and unlimited).
fSSWarnI_VibrationEnabled_xdu8                    Signal for persistent storage indicating that the  anti freeze action  shall be enabled again in the next key cycle.
zSSWarnI_StickSlipCounter_xdu16                   Number of already detected stick slip effect
=======================================   =====   ===========================================================================================================================


.. only:: confidential
   
   =======================================   =====   ==============================================================
   Signal Name                               Unit    Description
   =======================================   =====   ==============================================================
   sSSWarnI_ErrLvl_xdu8                              Error level of StickSlipWarning
   sSSWarnI_ErrLvl_Red_xdu8                          Error level of StickSlipWarning (Redundant)
   =======================================   =====   ==============================================================
   
   
Detailed Description
====================
Freezing water in the steering gear can possibly block the steering. Freezing water in the steering gear causes stick slip effects which could be recognized through patterns.
These effects are detected in the rotorspeed signal through the detection part of the Stick Slip Warning functionality. If an applicable number of stick slip effects is detected
within a defined period of time, the function generates a feedback torque (shaking movement which contribute to the corresponding ice to be melted) that prevents the steering gear from freezing. 
Once freezing water is detected, the feedback torque ramps in at startup even over the following keycycles until the car is serviced at the garage. 
If the system is prepared to handle RPC mode, the function is capable of freezing water detection in RPC mode by using another coherent parameter set. The corresponding system state can be decided
based on a status input which can be calculated at the supplementary component to keep the generic behvaiour of the base functionality. 

.. only:: confidential

   The signal conditioning subsystem filters and validates the input signals.
   
   Whenever the SSWarnI_Shutdown() server is called,
   the internal signal ShutdownRequest is set to 1.
   
   Server SSWarnI_StickSlipWarningPlausi implements the algorithms  to detect any faults in the StickSlipWarning Torque. The corresponding debounce and integral error buffer can be adjusted via tunable parameters.

Calibration/Application Parameters
==================================
.. image:: StickSlipWarningV2_calib.png  
.. note: the following list of parameters will always be visible in the generated documentation!
  
============================================        =====    ===============   =============================================================================================================
Parameter                                           Unit     Range             Description
============================================        =====    ===============   =============================================================================================================
tSSWarn_VibrationPeriod_XDU8                        s        0.045 .. 0.065    Period of anti-stick-slip-torque
tSSWarn_VibrationRampTime_XDU16                     s        1.8 .. 2.2        Vibration Ramp Time
tSSWarn_VibrationPause_XDU16                        s        0 .. 0.062        Vibration pause
xSSWarn_ReductionGradient_XDU16                              0 .. 1            Reduction Ramp gradient
xSSWarn_ReductionLevel_XDU16                                 0 .. 1            Reduction level 0 - 1 [0 - 100%]
xSSWarn_RotorSpeedFilter_XDU16                               0 .. 1            Constant for rotor speed filter
mSSWarn_MaxTBT4PatternDetectionForRPC_XDU16         Nm       0 .. 25           Torsion bar torque threshold for pattern detection (only in RPC mode)
sSSWarn_SSCounterStorageConfiguration_XDU8                   0 .. 2            Which mode to store classification counter: 0=RPC only, 1=SFC only, 2=both SFC and RPC
fSSWarn_EnableSwitch4RPC_XDU8                                0 .. 1            Switch to enable SSW in RPC mode
tSSWarn_TimeDelayPreventionTorque_XDU16             s        0 .. 60           Delay that is applied between the detection of the freezing and the start of the prevention torque generation
tSSWarn_MaxAllowedReductionTime_XDU16               s        0 .. 10           Maximum allowed reduction time
**SFC related:**
nSSWarn_RotSpeedLow_XDU16                           1/min    0 .. 70           Lower border for rotorspeed
vSSWarn_MinVehicleSpeed_XDU16                       km/h     0 .. 200          Lower limit for vehicle speed
nSSWarn_RotSpeedHigh_XDU16                          1/min    0 .. 1000         Upper border for rotorspeed
tSSWarn_TimeMinNLow_XDU16                           s        0 .. 5            Minimum time for low rotorspeed
tSSWarn_TimeMaxNHigh_XDU16                          s        0 .. 5            Maximum time for high rotorspeed
tSSWarn_TimeMaxNnotZero_XDU16                       s        0 .. 5            Time border for state RotSpeedNotZero
tSSWarn_ResetStickSlipTime_XDU16                    s        55 .. 65          Reset-time for stick-slip-counter
zSSWarn_SSCounterMax_XDU16                                   0 .. 20000        Amount of stick-slip-counts for activation anti-stick-slip-torque
mSSWarn_SSFeedbackTorque_XDU16                      Nm       0 .. 10            Anti-stick-slip torque
mSSWarn_EffTrqLow_XDU16                             Nm       0 .. 6            SSW_M1, lowest effective torque
mSSWarn_EffTrqHigh_XDU16                            Nm       0 .. 6            SSW_M3, highest effective torque
wSSWarn_MaxSteeringAngle_XDU16                      °        0 .. 500          Upper limit for steering angle
mSSWarn_DeltaEffectiveTorque_XDU16                  Nm       0 .. 10           Delta Effective Torque Limit
tSSWarn_MaxDeltaTime_XDU16                          s        0 .. 5            Time till Effective Torque Delta is reached
**RPC related:**
nSSWarn_RotSpeedLowForRPC_XDU16                     1/min    0 .. 70           Lower border for rotorspeed
vSSWarn_MinVehicleSpeedForRPC_XDU16                 km/h     0 .. 200          Lower limit for vehicle speed
nSSWarn_RotSpeedHighForRPC_XDU16                    1/min    0 .. 1000         Upper border for rotorspeed
tSSWarn_TimeMinNLowForRPC_XDU16                     s        0 .. 5            Minimum time for low rotorspeed
tSSWarn_TimeMaxNHighForRPC_XDU16                    s        0 .. 5            Maximum time for high rotorspeed
tSSWarn_ResetStickSlipTimeForRPC_XDU16              s        55 .. 65          Reset-time for stick-slip-counter
zSSWarn_SSCounterMaxForRPC_XDU16                             0 .. 20000        Amount of stick-slip-counts for activation anti-stick-slip-torque
mSSWarn_SSFeedbackTorqueForRPC_XDU16                Nm       0 .. 10            Anti-stick-slip torque
mSSWarn_EffTrqLowForRPC_XDU16                       Nm       0 .. 6            SSW_M1, lowest effective torque in RPC
mSSWarn_EffTrqHighForRPC_XDU16                      Nm       0 .. 6            SSW_M3, highest effective torque in RPC
wSSWarn_MaxSteeringAngleForRPC_XDU16                °        0 .. 500          Upper limit for steering angle
mSSWarn_DeltaEffectiveTorqueForRPC_XDU16            Nm       0 .. 10           Delta Effective Torque Limit for RPC
tSSWarn_MaxDeltaTimeForRPC_XDU16                    s        0 .. 5            Time till Effective Torque Delta is reached in RPC
tSSWarn_TimeMaxNnotZeroForRPC_XDU16                 s        0 .. 5            Time border for state RotSpeedNotZero
**Plausi:**  
mSSWarn_MaxFeedbackTorque_XDF32                     Nm       0 .. 2            Anti-stick-slip torque limit from which on an error-integral will start
mSSWarn_MaxFeedbackTorqueDT_XDF32                            0 .. 124          Limit for anti-stick-slip-torque integral-error
============================================        =====    ===============   =============================================================================================================
  
.. only:: confidential
   
  ======================================   ====   =========   =====================================================
  Parameter                                Unit   Range       Description                                                                           
  ======================================   ====   =========   =====================================================
  xsyRatioEfficiency_XDU16                        0 .. 0.2    Scaling factor for torsion bar torque to motor torque
  ======================================   ====   =========   =====================================================

.. include:: StickSlipWarningV2_CalMan_VT.irst


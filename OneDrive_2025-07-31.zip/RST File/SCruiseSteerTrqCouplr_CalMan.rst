.. only:: not confidential

   Smart Cruise Interface | SCruise Steer Trq Couplr
   #################################################

   The component maps the existing interfaces so that the customer can filter the signals according to their needs.


.. only:: confidential

   Smart Cruise Interface | SCruise Steer Trq Couplr
   #################################################


   Short Description
   =================

   The component SCruiseSteerTrqCouplr mapped the existing interfaces so that the customer can filter the signals according to their needs.


   Block Diagram
   =============

   .. image:: SCruiseSteerTrqCouplr_sm_SCruiseI_SteerTorqueCouplr.png


   Input Signals
   -------------

   =========================   =====   =======================================================
   Signal Name                 Unit    Description
   =========================   =====   =======================================================
   mTrqSumI_MotTrqSum1_xds16   Nm      summation of all input motor torques of main connector
   nSCruiseI_RotSpd_xds16      1/min   SCruise mapped filtered rotor speed, gear sign adjusted
   =========================   =====   =======================================================


   Output Signals
   --------------

   ==============================   =====   ===========================================================================
   Signal Name                      Unit    Description
   ==============================   =====   ===========================================================================
   mSCruiseI_MotTrqSumCoupl_xds16   Nm      Filtered summation of all input motor torques of main connector
   nSCruiseI_RotSpdCoupl_xds16      1/min   SCruise coupled rotor speed including additional filter, gear sign adjusted
   ==============================   =====   ===========================================================================


   Detailed Description
   --------------------

   Provide a detailed description of the functionality depicted in the block diagram.


   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ==============   ====   =====   ===========
   Parameter Name   Unit   Range   Description
   ==============   ====   =====   ===========
   ==============   ====   =====   ===========


.. only:: confidential

      .. Move confidential parameters from the above table down here, if applicable.

   .. include:: SCruiseSteerTrqCouplr_CalMan_VT.irst

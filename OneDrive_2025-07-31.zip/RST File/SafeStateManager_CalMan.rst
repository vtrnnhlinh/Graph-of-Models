SafeStateManager
##################

Short Description
=================

The component SafeStateManager reads all ErrorLevels coming from components located outside of the HwLibrary and maps them to a SafeStateRequest. The SafeStateRequest will be used by the SafeStateManager to determine the EcuSafeState.

.. only:: confidential
   
    .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: SafeStateManager_BlockDiagConfidential.png

   Input Signals
   -------------
   ==================================  =========   =============================================================================================
   Signal Name                         Unit        Description
   ==================================  =========   =============================================================================================
   sHwlI_TorsionBarTorqueState_gde     -           TorsionBarTorque state provided by HWLib 
   sHwlI_RotorPositionState_gde        -           RotorPosition state provided by HWLib
   sHwlI_ActuatorState_gde             -           Actuator State provided by HWLib 
   nApplI_RotorSpeedFilt_xds16         1/min       Filtered Rotor Speed. This interface describes the filtered rotor speed. 
   wApplI_SteeringAngle_xds16          °           Corrected Steering Angle. This is the short-time and long-time corrected steering angle. 
   sApplI_SteeringAngleLinState_xdu8   -           State of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
   sHwlI_SafeState_gde                 -           Safe-State provided by HWLib
   vVehSpI_AbsAvgVehSpd_xdu16          km/h        Average vehicle speed.    
   ==================================  =========   =============================================================================================

   Output Signals
   --------------
   =============================    ====     ===============================================================================================================================================
   Signal Name                      Unit     Description
   =============================    ====     ===============================================================================================================================================
   sSsmI_SafeStateRequest_gde                High Level SafeState-Request. This interface can be used to request a safe state change in the HWLib. 
   xSsmI_FailOpRampLevel_xdu16      %        FailOp-Ramp Target-Level. This interface is used to thell the Assistancecontroller to which level we need to ramp because of an active FailOp. 
   ySsmI_FailOpRedGrad_xdu16        1/ms     FailOp Ramp-Gradient. This interface is used to tell the AssistanceController which gradient shall be used to ramp to the target level. 
   sSsmI_DeactivateAssist_xdu8               Set trigger to Deactivate the Assist based on the error present in errorLvl
   =============================    ====     ===============================================================================================================================================


   Detailed Description
   --------------------

   The component SafeStateManager reads all ErrorLevels coming from components located outside of the HwLibrary and assigns a safe state request, desired reduction level, gradient and fault action time to this specific error event. These values will be used by the SafeStateManager in order to do further processing. 

   Calibration/Application Parameters
   ==================================
 
   Internal Calibaration parameters:
   
   ===========================================   ==========   ========     =====================================================================================================================
   Parameter Name                                Unit         Range        Description
   ===========================================   ==========   ========     =====================================================================================================================
   yHwlWrapI_HwLibSloaRampGradient_XDU16         %/s          1..200       'SLOA Ramp Gradient' limitation parameter provided by HWLib
   yHwlWrapI_HwLibSloaRampLevel_XDU16            %            0..100       'SLOA Level' limitation parameter provided by HWLib
   yHwlWrapI_HwLibSloaRampTime_XDU32             s            0..60        'SLOA Ramp Time' limitation giving time frame until reduction to SLOA level has te be performed
   ySsm_FaultActionGradient_XAU16                Factor/ms    0..x         Gradients to be used for reduction in case of a dedicated fault 
   xSsm_FaultActionRedLevel_XAU16                %            0..100       Reductions level to be used for reduction in case of a dedicated fault 
   tSsm_FaultActionMaxTime_XAU16                 s            0..x         Max. fail operational time before ramp to 0 % is triggered
   nSsm_ShortCircuit_RotorSpeedLimit_XDU16       1/min        500...x      Rotor speed limit for MOSFET SC shutdown strategy. If rotor speed > limit, transition to error is triggered
   vSsm_ShortCircuit_VehSpeedLimit_XDU16         km/h         0...x        Vehicle speed limit for MOSFET SC shutdown strategy. If vehicle speed < limit, transition to error is triggered
   wSsm_ShortCircuit_SteeringAngleLimit_XDU32    °            0...x        Steering angle limit for MOSFET SC shutdown strategy. If steering angle < limit, transition to error is triggered
   ===========================================   ==========   ========     =====================================================================================================================

.. include:: SafeStateManager_CalMan_VT.irst

End Stop
########

.. only:: confidential
   
.. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This function is intended to protect the hardware of the steering system via a counter-torque that is applied before the mechanical end stop is reached.


Block Diagram
=============
.. image:: EndStop_CalMan_BlockDiagram.png
.. image:: EndStopMonitoring_CalMan_BlockDiagram.png

Input Signals
-------------
========================================== ======  ========================================================================
Signal Name                                Unit    Description
========================================== ======  ========================================================================
mApplI_TorsionBarTorque_xds16              Nm      HW LIB: Abs.torsion bar torque
mApplI_LimitedMotorTorque_xds16            Nm      Limited motor torque
xApplI_TotalMotTorLim_xdu16                        total reduction of torque reduction coordinator
mApplI_MaxRequiredMotorTorque_xdu16        Nm      Maximum required motor torque
mSCruiseFadrI_MotTrq_xds16                 Nm      Motor Torque coming from the SCruiseFading functionality
vApplI_AbsVehicleSpeedFilt_xds16           km/h    Abs.vehicle speed:processed   
sApplI_VehicleSpeedState_xdu8                      Validflag for vehicle speed
nApplI_RotorSpeedFilt_xds16                1/min   filtered rotor speed
nApplI_RotorSpeed_xds16                    1/min   Rotor speed
xApplI_GearSign_xds8                               Steering gear sign
lEndStopI_CenterOffset_xds16               mm      Centeroffset[mm] /end stop
lEndStopI_AddSteerRange_xdu16              mm      Additional steering range/ end stop
sEndStopI_LearnStatLeft_xdu8                       Learn state left/endstop                    
sEndStopI_LearnStatRight_xdu8                      Learn state right / endstop

lEndStopI_RackPosition_xds16               mm      Rack position(lEndStopI_DistanceToEndstop_xds16 is calculated from this)
sEndStopI_SALinState_xdu8                  Status  steering angle state (calculated from sApplI_SteeringAngleState_xdu8)
lEndStopI_ReqRackPosMin_xds16                      Desired endstopposition from VSE on right side (neg). If EndStopSupp is not used, this value is only written initial
lEndStopI_ReqRackPosMax_xds16                      Desired endstopposition from VSE on left side (pos). If EndStopSupp is not used, this value is only written initial
sEndStopI_ReqStateEsMin_xdu8                       This state can be used to control the requested endstop handling (right=neg=min): 0-dont use, 1-MAX(learned,ReqES) 2-ReqES has prio
sEndStopI_ReqStateEsMax_xdu8                       This state can be used to control the requested endstop handling (left=pos=max): 0-dont use, 1-MIN(learned,ReqES) 2-ReqES has prio
lEndStopI_AbsPosOffset_xdu16               mm      Additional offset from endstop(VSE).
xEndStopI_OversteerabilityFactor_xdu16             used, this value is only written intial.Caution : Overrules fendstop__limitEnable_XDU8 if Endstop_enableDyn_XDU8!=1
========================================== ======  ========================================================================


Output Signals
--------------

================================== ==== ==========================================================================================
Signal Name                        Unit Description
================================== ==== ==========================================================================================
lEndStopI_DistanceToEndstop_xds16  mm   Distance from end stop in mm
mEndStopI_SpringTorque4Check_xds16 Nm   Endstop spring torque to be checked
mEndStopI_Damping4Check_xds16      Nm   Endstop damping to be checked
fEndStopI_LimitEnable_xdu8              Display flag for switch on endstop torque limitation
fEndStopI_ReduceSpring_xdu8             Flag to reduce spring torque with a non-oversteerable EndStop

mEndStopI_MotorTorque_xds16        Nm   EndStop torque
fEndStopI_EndStopActive_xdu8            Flag for endstop active
fEndStopI_SpringActive_xdu8             Flag for Spring Torque active
lEndStopI_EndstopPosRight_xds16	   mm   current sw-endstop-position right
lEndStopI_EndstopPosLeft_xds16	   mm   current sw-endstop-position left
lEndStopI_RackPosMax_xds16         mm   max rack position
lEndStopI_RackPosMin_xds16         mm   min rack position
================================== ==== ==========================================================================================


Detailed Description
--------------------

EndStop function is implemented in an EPS for functional improvement in terms of noise and haptics and to protect the mechanical components of the steering gears that replicates 
a spring-damper characteristic via software before the mechanical end stops of the steering gears are reached and that counteracts the requested assistance torque. This keeps
the mechanical components from hitting one another when there is a quick steering without braking or with the maximum force. The mechanical end stops of the steering gears are defined 
by the interior joints of the tie rods running up against the steering system housing or the mechanical end stop damper that is additionally installed.The function calculates 
the end stop torque in such a way that it is limited to the maximum possible assistance torque (motor torque with which steering is done in the direction of the mechanical endstop). 
The software end stop can consequently be steered through to the effect that the resulting motor torque is ~ 0 (i.e. behavior as in the case of a shut-down system or deactivated 
servoassistance).

This function is implemented in two parts End stop motor torque calculation and Endstop motor torque limitation& monitoring.

EndStopMotor Torque  Calculation
--------------------------------
CalcAdaptiveData
""""""""""""""""
In the interface function CalcAdaptiveData() the adaptive data, which are required for calculating the racktravel, are detemined. The most important input for this is the current 
rackposition. From this the current distance to the mechanical stop, the learnstate and the positive (left) and negative (right) racktravel is being calculated depending on the geometric
conditions and other calculation conditions.

The function is divided into the following parts:
  * HandleNoLearnFlag:In this part the NoLearnFlag is set and reset (whether identifying new min or max values is allowed or not).
  * CalcMinMaxValues:In this part the flags "new min or max value" of the racktravel and "new minimum or maximum rackposition" are determined.
  * CalcNewLearnStates:In this part the learnstate can be determined.
  * Calc Distance to end stop:In this part the actual distance to the end stop is beeing calculated [mm].
  * NvRamI_WriteBlock:In this part the values for additional steering range and mid-offset are calculated and written to the variables which are stored in the non volatile memory.
  * CheckLearnStates:In this part the learnstates (left, right) are checked for plausibility and , if necessary, the ResetFlag is set.

MotorTorque Calculation
"""""""""""""""""""""""
The output torque of the endstop is set to zero if the rackposition is invalid or if the endstop function isn't activated by coding.The spring torque is set to zero if the endstops are 
not learned yet and it is limited if they are not learned completely. 

The damping torque is limited depending on the steering direction. When steering into the endstop the damping torque is reduced after a calibratable time.This limitation can be 
selected by a switch that it is active either in both directions or only towards the endstop.

The sum of the torques of the endstop is set to zero if the function is deactivated or if the rackposition is invalid. This function ensures on demand, that the sum of the endstop torque
is not greater than the current assistance torque. Thus, the sw-endstop can be overruled manually. The necessary steering torque should correspond to the case, when EPS is switched off.


Endstop MotorTorque Saturation & Monitoring
-------------------------------------------

EndStop Saturation
""""""""""""""""""
The calculated motor torque in the first section shall be limited based on the springfactor and MaxRequiredMotorTorque.And also it calculates the Non oversteerable and Oversteerable 
Endtstop torque.

EndStop Monitoring
"""""""""""""""""""
fEndStop_Disable flag is calculated based on the Rackposition, steering angle and Motor torque. If Endstop active outside allowed rack position range or dynamic Endstop active outside
allowed dynamic rack position range or steering ange invalid or motor torque violates calclated limits or rate down limiter active but not reducing torque  then f_DisableFlag set to 
true otherwise  the flag f_DisableFlag set to false.

EndStop DisableSwitch
"""""""""""""""""""""
Based on the fEndStop_Disable , the Endstop function can be switchedoff.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation


==========================================   =====   ========   =============================================
Parameter Name                               Unit    Range      Description
==========================================   =====   ========   =============================================
vEndStop_uVehSpeedLearnFinished_XDU16        km/h    0 ..20      learn finish condition, lower boarder vehicle speed
nEndStop_oRotSpeedLearn_XDU16                1/min   0..2000    learn condition, upper boarder rotor speed
nEndStop_oRotSpeedLearnFinished_XDU16        1/min   0..2000    learn finished condition, upper boarder rotor speed
mEndStop_uTBTLearn_XDU16                     Nm      0..15      learn condition, lower boarder torsion bar torque 
mEndStop_uMotorTorque_XDU16                  Nm      0..10       learn finish condition, lower boarder motor torque
lEndStop_SteerRange_XDU16                    mm      0..250     Steering range right to left [mm]
lEndStop_uDistanceLearnCondition_XDU16       mm      0..8       distance to endstop, where learn finish conditions being proved from
xEndStop_SpringFactorGrad_XDU16                      0..0.1     gradient factor/ms for reducing spring torque if learn state =1
fEndStop_LimitEnable_XDU8                            0..1       flag for switch on endstop torque limitation
lEndStop_oAbsSteerLearn_XDU16                mm      50..125    Einlernbedingung: max. Lenkhub zum Einlernen bezogen auf Indexmitte bzw. ext. LWS
lEndStop_uAbsSteerLearn_XDU16                mm      50..125    learn condition: lower boarder rack position
lEndStop_OffsetNotExactlyInit_XDU16          mm      0..3       difference in [mm] respected at distance to endstop, if steering angle is not exactly init
==========================================   =====   ========   =============================================

.. only:: confidential

   Internal calibration parameters
   --------------------------------
   
   ============================================     ==============   =========   ======================================================================================================================================================
   Parameter Name                                   Unit             Range       Description
   ============================================     ==============   =========   ======================================================================================================================================================
   mEndStop_SpringTorque_XAS16                      Nm               0..23.999   Characteristic spring curve
   xEndStop_Damping_XAS16                           Nm/(1024/Min)    0..10       Characteristic damping curve
   mEndStop_oMaxDamping_XDU16                       Nm               0..10       Max. damping torque
   fEndStop_ResetLearnedEndstopPosition_XDU8                         0..1        Reset learned EndstopPosition - set back to 0 after reset had been performed
   lEndStop_RelearnOffset_XDU16                     mm               0..10       Additional distance, that the new RackPosMax/Min must be bigger than the old value, to start relearn [mm]
   lEndStop_StatusChangeAllowedOffset_XDU16         mm               0..5        Additional offset to springstartposition (to ensure being outside of the endstoparea) [mm]
   xEndStop_RotSpeedFact_XAU16                                       0..3000     factor for RotSpeed
   xEndStop_RotSpeedFiltFact_XDU16                                   0.01..1     filter factor for rotorspeed; [value = filterfact * task cycle time]
   tEndStop_MaxTimeIncrDamping_XDU8                 s                0..100      max. time for increased damping (non-oversteerable ES); [value = durationtime / task cycle time]
   fEndStop_EnableDyn_XDU8                                           0..1        flag for switch on dynamic endstop. Caution: EndstopSupp-component can overrule fEndStop_LimitEnable!!!
   fEndStop_EnablePos_XDU8                                           0..1        flag for switch on endstop position
   fEndStop_EnableProto_XDU8                                         0..1        flag for enable or dissable the Customer switch
   lEndStop_SteerRangeLimit_XDU16                   mm               50..125     Limitation to minimium steering range related to calibrated SAS [mm]
   xEndStop_FadeRateTorqueLim_XDU16                                  0..1        Fade rate for spring torque from unlimited to limited torque; [value = rate * task cycle time]
   xEndStop_FadeFactorMotTrq_XAU16                                   0..1        fading-faktor motortorque limitLowSpeed
   nEndStop_oRotSpeedRedSpringTorque_XDU16          1/min            0..500      upper limit rotor speed for reduction of spring torque if learn state =2
   mEndStop_LimitDamping_XDU16                      Nm               0..8        max. damping torque at steering away from Endstop
   mEndStop_MaxTorquePointingOutwards_XDU16         Nm               0..2        max. endstop torque pointing towards endstop (allow damping)
   xEndStop_RateLimiterToZeroRate_XDU32                              0..24       gradient Nm/ms for RateToZeroLimiter if ES is oversteered or deactivated; [value = rate * task cycle time]
   fEndStop_DisableReactivation_XDU8                                 0..1        Monitoring: disable reactivation after disappearance of detected error
   xEndStop_ResidualAssistance_XDU16                                 0..1        factor minimum residual assistance for oversteerable Endstop [%/100]
   lEndStop_AllowedPosBorder_XDU16                  mm               0..125      max. absolute rack travel area without Endstop Level2
   xEndStop_FadeFactorLimitation_XAU16                               0..1        Fading factor for oversteerable Endstop (0: Limitation to 100% min(MotTrqSum2, MaxRequiredMotorTorque), 1: Limitiation to 100% MaxRequiredMotorTorque
   lEndStop_AllowedPosBorderHigh_XDU16              mm               35..125     upper limit absolute rack travel without endstop torque --> level2
   lEndStop_MinSteerRangeLearned_XDU16              mm               0..200      minimum steering range when learning is finished
   tEndStop_DebounceTimeLearnFin_XDU8               ms               1..250      debounce time for LearnState = 2 
   mEndStop_uSpringTorque_XDU16                     Nm               0..15       upper limit of spring torque for endstop learning
   lEndStop_EsMechIndentLeft_XDU16                  mm               0..40       distance [mm] to learned endstop position left
   lEndStop_EsMechIndentRight_XDU16                 mm               0..40       distance [mm] to learned endstop position right
   xEndStop_uTotalMotTorLimLearnFinished_XDU16      %                0..100      learn finish condition: lower border LimMotTorFactor
   tEndStop_NVwriteTimer_XDU16                      ms               0..65535    wait time within which Write successful response is expected from NvM
   zEndStop_MaxChancesWriteTrigger_XDU8                              0..10       number of unsuccessful write into DF is exceptable        
   ============================================     ==============   =========   ======================================================================================================================================================
                                                 
   
Teach In
=========
The teach-in status can be separately displayed for both of the end stop sides (left-hand side ->yeeEsLearnStatLeft_xdu8; right-hand side -> yeeEsLearnStatRight_xdu8):
  * Learning Status 0 ->Not taught in (as-delivered condition).

    Only the characteristic damping curve xEndStop_Damping_XAS16 is active. It is proportional to the rotor speed. The characteristic spring curve(mEndStop_SpringTorque_XAS16) 
    is deactivated. The teach-in of the end stops is possible under learning conditions.

  * Learning Status 1->Learned with the vehicle at standstill.

    The characteristic damping and spring curve is active.The characteristic spring curve is reduced to 0% over a time-dependent ramp with a low level of dynamics (e.g. nRot <
    200 r.p.m.) and a rolling vehicle (e.g. vehicle velocity > 5 km/h). The teach-in of the end stops is possible under learning conditions.

  * Learning Status 2->Taught in during slow travel (completed teach in).
  
    The characteristic damping and spring curve is active. No further teach-in of the endstops is possible.

Transition conditions:
----------------------

From Status 0 to Status 1 (from “not learned” to “learned”):
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
  * The steering angle is initialized with precision (sEndStopI_SALinState_xdu8 = 2)
  * Current torsion bar torque < permissible torsion bar torque (currently applied: 15 Nm)
  * Current rotor speed < permissible rotor speed (currently applied: 2000 r.p.m.)
	
Additional conditions for transition into Status 2 (completed learning):
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
  * The current motor torque is > the minimum motor torque (high motor torque ->mechanical end stop reached; currently applied: 4 Nm)	
  * The current rotor speed is < the maximum rotary speed (low rotor speed -> low level of dynamics; currently applied: 200 r.p.m.)
  * The current torsion bar torque is > the minimum torsion bar torque (high torsion bar torque -> mechanical end stop reached; currently applied: 7.5 Nm)
  * The current vehicle speed is > the minimum speed (vehicle is rolling: significantly reduced axle forces, no pressing on the curb; currently applied: 5 km/h)
  * The characteristic spring curve is reduced to 0% over the ramp.
  
The combination of complete learning conditions ensures that the mechanical end stop is actually reached.

Additionl notes:
""""""""""""""""  
The learning conditions are only checked in the end stop area, i.e. the current rack position is > the
steering travel at the band end
If one of the learning conditions is violated, the flag "fEndStop_NoLearnFlag_xdu8" is set; the reset of
same only takes place after the exit from the end stop area.
The status is not changed immediately after all of the conditions have been met, but only when the
end stop area is exited. The background is that the characteristic spring curve is activated when the
status is changed and that has to take place in an area in which it supplies the value 0.

Starting condition for the teach-in process
"""""""""""""""""""""""""""""""""""""""""""
The following conditions have to be created so that the teach-in process can be carried out:
  * The steering system is completely mounted in the vehicle, the plugs have been inserted.
  * The steering movement of the front wheels is not hindered by obstacles.
  * The combustion engine is running.
  * There is no erroneous entry in the EPS control unit; steering assistance exists(SystemState = driveup).
  * The vehicle is at a standstill or is moved at a slow speed (speed range between ~ 5 - 10km/h).
  * No error messages of the external (or internal) steering angle sensor signal.

Teach-in Process
----------------
.. image:: TeachInProcess_blockDiagram.png

The end stop angles are taught-in and permanently stored in the EPS control unit after Step 5.

.. image:: TeachinSWEndStop_blockDiagram.png

.. image:: TeachinSWEndStopSequence_blockDiagram.png

.. include:: EndStop_CalMan_VT.irst

.. only:: not confidential

   Smart Cruise Limiter | Rack Speed Limiter
   #########################################

   This component is responsible for the limitation of the vehicle dynamics.

.. only:: confidential

   Smart Cruise Limiter | Rack Speed Limiter
   #########################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   This component is responsible for the limitation of the vehicle dynamics.
   If the actual rack speed exceeds the positive or negative rack speed limits, a PID controller is activated and generates a counter torque to bring the rack speed again within the limits.


   Block Diagram
   =============

   .. image:: SCruiseRackSpdLimr_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ====================================   ====   =========================================================================================================
   Signal Name                            Unit   Description
   ====================================   ====   =========================================================================================================
   mSCruiseI_MotTrq_xds16                 Nm     MotorTorque requested by the SCruiseController
   vSCruiseLimrI_RackSpdCoupl_xds16       mm/s   PT2 filtered rack speed [mm/s]
   vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16   km/h   Maximum vehicle speed
   vSCruiseLimrI_PosRackSpdLim_xds16      mm/s   max. allowed positive rack speed with possible limit opening due to driver interaction checked
   vSCruiseLimrI_NegRackSpdLim_xds16      mm/s   max. allowed negative rack speed with possible limit opening due to driver interaction checked
   xApplI_GearSign_xds8                          sign of the steering gear
   xSCruiseFadrI_Prgs2SCI_xdu16                  Factor indicates fading progress (0=SFC; 1=SCI)
   fSCruiseI_DeactvRackSpdLimr_xdu8              Deactivate (1) or Activate (0) rack speed limiter in case of steering jerk
   ====================================   ====   =========================================================================================================


   Output Signals
   --------------

   ==================================   ======   ===========================================================================================================================
   Signal Name                          Unit     Description
   ==================================   ======   ===========================================================================================================================
   mSCruiseLimrI_MotTrq4Chk_xds16       Nm       SCruise Limiter Motor Torque
   mSCruiseLimr_DPart_xds8              Nm       DPart of the PID controller
   mSCruiseLimr_IPart_xds8              Nm       IPart of the PID controller
   mSCruiseLimr_PPart_xds8              Nm       PPart of the PID controller
   mSCruiseLimr_RackSpdCtrlrTrq_xds16   Nm       rack speed controller s motor torque
   vSCruiseLimr_RackSpdDe_xds16         mm/s     rack speed deviation
   xSCruiseLimrI_DynResv_xds16                   dynamic reserve until limit has been reached (1:full reserve; 0:no reserve, -1:full overshoot)
   xSCruiseLimr_NrmRackSpdDev_xds16              normalized (== percentage) rack speed deviation
   ==================================   ======   ===========================================================================================================================


   Detailed Description
   --------------------

   Smart Cruise Rack Limiter provides a dynamic limitation on the motor torque based on Rack speed limitation. The component has a PID rack speed controller which controls the Motor torque.
   The vSCruiseLimrI_PosRackSpdLim_xds16 and vSCruiseLimrI_NegRackSpdLim_xds16 are received from the component SCruiseMaxRackSpdChk. This provides the maximum limit for the Rack Speed in positive and negative direction. The rack speed vSCruiseLimrI_RackSpd_xds16 is compared
   with this limit. If exceeded then a normalised deviation is calculated which is used in the PID controller to generate a motor torque mSCruiseLimr_RackSpdCtrlrTrq_xds16.
   This motor torque is limited by the min and max value defined for mSCruiseLimr_RackSpdCtrlrTrq_xds16 i.e. [-24 24] Nm.
   The P, I and D calibration parameters are vehicle speed dependant.
   In addition the P, I and D parts of the controller can be tuned with the calibration parameters dependent on normalized rack speed deviation.
   The P, I and D parts are reset to 0Nm when,

   1) The mSCruiseLimr_RackSpdCtrlrTrq_xds16 ramped down to 0Nm AND Rackspd is within the positive or negative RackSpd limits. (OR)
   2) The controller is turned off in SFC mode.
   3) The steering jerk is enabled i.e. fSCruiseI_DeactvRackSpdLimr_xdu8 = 1

   The output Dynamic reserve xSCruiseLimrI_DynResv_xds16 is an indicator on how the working point of the controller chain is. Its value cannot be greater than 1. There is a saturation = -1 only on the negative values.

   | == 1: 100 % reserve; no dynamic in the system; no movement
   | == 0: dynamic at the limit (RackSpd=RackSpdLim)
   | < 0: RackSpdLim raised; limiter is active

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ==================================   ====   ============   ===================================================
   Parameter Name                       Unit   Range          Description
   ==================================   ====   ============   ===================================================
   xSCruiseLimr_DPartFilFac_XDU8               0.0078125..1   low-pass filter factor for D-part
   xSCruiseLimr_DPartVehSpd_XAU16              0..30          D Part (dependent on vehicle speed)
   xSCruiseLimr_IPartVehSpd_XAU16              0..30          I Part (dependent on vehicle speed)
   xSCruiseLimr_PPartVehSpd_XAU16              0..30          P Part (dependent on vehicle speed)
   xSCruiseLimr_DPartNrmRackSpd_XAU8           0..1           D Part (dependent on norminal rack speed deviation)
   xSCruiseLimr_IPartNrmRackSpd_XAU8           0..1           I Part (dependent on norminal rack speed deviation)
   xSCruiseLimr_PPartNrmRackSpd_XAU8           0..1           P Part (dependent on norminal rack speed deviation)
   ==================================   ====   ============   ===================================================


   .. include:: SCruiseRackSpdLimr_CalMan_VT.irst

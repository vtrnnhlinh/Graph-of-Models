Active Return
#############


Short Description
=================

Active return is a function that controls the return speed of the steering wheel in dependence upon 
the steering angle and vehicle speed. It therefore also concerns itself with a small part 
of steering damping based on the control. The application of this function is responsible for the 
return behavior and the overshoot behavior.


Block Diagram
=============

.. image:: ActiveReturn_CalMan_BlockDiagram.png


Input Signals
-------------

====================================   ======   ====================================================================================================================================================================================================
Signal Name                            Unit     Description
====================================   ======   ====================================================================================================================================================================================================
mApplI_DriverTorque_xds16              Nm       calculated driver torque
sApplI_SteeringAngleState_xdu8         -        steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit)
vApplI_SteeringAngleSpeed_xds16        deg/s    Speed of the steering angle
vVehSpI_AbsAvgVehSpd_xdu16             km/h     Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
wApplI_SteeringAngle_xds16             deg      corrected steering angle
xApplI_GearSign_xds8                   -        sign of the steering gear
xFactMinI_ActiveRetFuncFactor_xdu16    -        Requested active return function factor
xFactMinI_ActiveRetSpeedFactor_xdu16   -        Requested active return speed factor
xCompIncFricI_ActiveRetBoost_xdu16     -        Ratio between learned and init LoadFactor.If a 50% boost is required in the output torque, the value of LoafFacRat shoudl be 0.5.However 200% boost on output torque is possible as per the design
====================================   ======   ====================================================================================================================================================================================================


Output Signals
--------------

==============================   ======   ================================================================
Signal Name                      Unit     Description
==============================   ======   ================================================================
mActRetI_MotTrq4Check_xds16      Nm       motor torque of active return component for check
==============================   ======   ================================================================

.. only:: confidential

==============================   ======   ================================================================
Signal Name                      Unit     Description
==============================   ======   ================================================================
vActRet_ReturnSpeedDiff_xds16    deg/s    difference of steering speed controller
xActRet_SpeedFactorFilt_xds32    -        filtrated active return steering speed factor
xActRet_TorqueFactorFilt_xds32   -        filtrated active return motor torque factor due to driver torque
==============================   ======   ================================================================

Detailed Description
--------------------

ActiveReturn represents a functionality that is to be applied in one or more loops with the assistance calculation due to the additional part in the motor torque.
The characteristic field "nominal steering angle return speed depending on vehicle speed and steering angle" is controlling for the return / damping torque 
as a general principle. The return speed over the steering angle is to be coordinated in such a way that the highest return speed exists with a maximum steering angle and there
is no longer any return speed with straightaway driving. The return speed can also be zero a few degrees outside of the middle of the steering range, depending on the type of 
center alignment that is desired from the return. This coordination will be provided for all vehicle speeds. The level of the target return speed can be changed 
between 0 and 150 % with the aid of a constant factor (xActRet_SteeringSpeedFact_XDU8). Part of the damping is influenced by the control amplification. A factor dependent upon
the vehicle speed (xActRet_MotorTorqueGain_XAU16) is adjusted for this. The factor dependent upon the speed can have any value, even at a standstill.The active return is limited 
over the actuation torque; two dependencies are to be coordinated in the process: A characteristic curve (xActRet_SteerSpeedFactDepOnDriver_XAU16) reduces the target return speed 
in dependence upon the driver torque. This reduction prevents the steering system from trying to move back too strongly against an actuation torque that is being applied (it subjectively
feels like one is pushing against a spring -> "spring effect").The second characteristic curve (xActRet_RetTorqueFactDepOnDriver_XAU16) reduces the control amplification in dependence upon
the driver torque. The spring effect and the damping are influenced by that. Thus, if the target return speed is reduced to zero (or nearly zero) starting with a specific torsion bar torque
and the control amplification is left at a certain minimum value, damping can be achieved with an actuation torque that is being applied (e.g. in the case of cornering) without an interfering
spring effect.

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

========================================   ========   =======   ==================================================================================
Parameter Name                             Unit       Range     Description
========================================   ========   =======   ==================================================================================
vActRet_NominalSteeringSpeed_XAU16         deg/s      0..1500   nominal steering angle return speed depending on vehicle speed and steering angle
mActRet_MaxMotorTorque_XDU8                Nm         0..3      limitation of active return torque
xActRet_FilterFactor_XDU16                 -          0.01..1   filter factor for filtrated nominal steering speed factor and motor torque factor
xActRet_MotorTorqueGain_XAU16              -          0...3     motor torque factor
xActRet_SteeringSpeedAmp_XDU16             Nm s/deg   0..0.02   active return control amplification [Nm * s / deg]
xActRet_SteeringSpeedFact_XDU8             -          0..1.5    factor of nominal steering speed
xActRet_RetTorqueFactDepOnDriver_XAU16     -          0..1      factor of active return motor torque (after limitation) depending on driver torque
xActRet_SteerSpeedFactDepOnDriver_XAU16    -          0..1      factor of nominal steering speed depending on driver torque
========================================   ========   =======   ==================================================================================

.. only:: confidential
   
   ========================================   ========   =======   =================================================================================
   Parameter Name [internal]                  Unit       Range     Description
   ========================================   ========   =======   =================================================================================
   xActRet_SteerSpeedGradAfterInvalid_XDU16   -          0..1      gradient for ramp up after invalid input signals
   ========================================   ========   =======   =================================================================================


.. include:: ActiveReturn_CalMan_VT.irst

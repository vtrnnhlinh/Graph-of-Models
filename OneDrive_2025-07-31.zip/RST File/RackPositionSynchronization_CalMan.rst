﻿Rack Position SynchronizationTPO_SRA
######################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component Rackposition SynchronizationTPO_SRA is part of the Steering Angle Calculation. It handles the synchronization of the internal steering angle calculated based on Accumulated rotor angle(ARA or RPS) to the True Power on steering angle (TAS). 
The calculated offset (difference between ARA and TAS) is provided to the RackPositionMain Component for RackPosition calculation


Output signals of the component are rotor angle offsets and state information to RackPositionMainSRA.  

The tuning of the component can completely be done at the desk, but information is needed from 

* the mechanical system / department

* eventually the vehicle / sensors / column 

* the requirements of the customer / safety. 

To support the tuning there are Excel-sheets available, esp. the MechanicalDataSheet, stored in ..\DesignSet\DataContainer\..  .


Block Diagram
=============

.. only:: confidential

    .. image:: RackPosSync_CalMan_BlockDiagram.PNG

Sketch to give an overview over the state transition. Not all provided signals are visible.
 

Input Signals
-------------

==========================================   ======   ===============================================================================================================================
Signal Name                                  Unit     Description
==========================================   ======   ===============================================================================================================================
wHwlWrapI_PowerOnSteeringAngle_xdf32                  HW LIB: True Power on Staeering Angle
sHwlWrapI_PowerOnSteeringAngleState_xde               HW LIB: True Power on Steering Angle State
nRackPoI_RotorSpeed_xds16                    rpm      Rotor speed with Gear sign compensated
sRackPoI_StateRequest_xdu8                            Requested state of RackPosition qualifier statemachine from Rackposition Main: 0-nop, 1-init, 2-err_rev, 3-err_perm
wRackPoI_AccumRotorAngle_xds32               deg RA   Accumulated RotorAngle, GearSign compensated
sHwlWrapI_AbsRotbasedAngleDetails_xdu32               HW LIB: Absolute Rotbased Angle Details - Qualifier for rotor Position
sApplI_SteeringAngleState_xdu8                        Steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit,4= Fallback)
wApplI_PinionAngle_xds16                     deg SA   Steering angle without lt-/st- correction, calculated in RackPositionMainSRA
sApplI_RackPosQualifier_xdu8                          RotorAngle Offset Qualifier for Rotor angle Ramping
vApplI_AbsRackSpeed_xdu16                    mm/s     GearSign compensated RotorSpeed by mutiplying the RotorSpeed to the Gear conversion
mApplI_LimitedMotorTorque_xds16              Nm       HW LIB: motor torque after limitation in HwLib
wEndStopI_LearnLeftTPOAngle_xdu16                     Left Endstop value in terms of TPO Angle    
wEndStopI_LearnRightTPOAngle_xdu16           deg SA   Right Endstop value in terms of TPO Angle 
==========================================   ======   ===============================================================================================================================


Output Signals
--------------

==========================================   ======   ===============================================================================================================================
Signal Name                                  Unit     Description
==========================================   ======   ===============================================================================================================================
sRpSyncI_RotAngInitState_xdu8                         Synchronization state of internal steering angle
wRpSyncI_AccRotAngOffset_xds32               deg RA   Synchronization offset of internal steering angle
sRpSyncI_InitOffsetControl_xdu8                       Flag to control the synchronization behavior ( 1-with ramping, 0-no ramping)
sRpSyncI_PlausiState_xdu8                             state of synchronization monitoring: 0-Plausi off, 1-active+ok, 2-GoErrRev, 3-GoErrPerm
wRpSyncI_PinionAngleRaw_xds16                deg SA   Compensated pinion angle based on TPO
sRpSyncI_PinionAngleRawState_xdu8                     Qualification state of input signals for synchronization based on TPO
yRpSyncI_DiagData_gds                                 Diagnostic error entry
zRpSyncI_SyncCycleCounter_xdu8                        Counter of synchronization cycles in current ignition cycle
==========================================   ======   ===============================================================================================================================

.. only:: confidential 

   ===================================   =======   ====================================================================
   Signal Name                           Unit      Description
   ===================================   =======   ====================================================================
   sRpSync_ErrorDetected_xdu16                     Plausi error detected value based on error configuration  
   wRpSync_MechanicalCenterRaw_xds16     deg SA    Centered external Raw TAS angle calculated based on Endstop limits
   zRpSync_ErrorCycleCounter_xdu8                  Counter of new sync cycles after error is detected
   wRpSync_SteerAngleDeviation_xds16     deg SA    Deviation of external to internal steering angle
   tRpSync_ErrorFilterTimer_xdu16        ms        Redundant filtertime for RackPosSync plausi errors
   ===================================   =======   ====================================================================

Detailed Description
--------------------

The RackPositionSynchronization is part of the Steering Angle Calculation. It handles the synchronization of the internal steering angle to the true power on angle sensor (TAS). The basic output is an offset to the accumulated rotor angle and the corresponding state information.
Depending on the configuration, a cyclic check and eventual resynchronization can be done.

Calculation of Pinion angle raw
==================================
The TPO angle from HW Lib is converted to degree and depending on the Endstops limits the mechanical centre is calculated.
Pinion angle raw is the difference between Mechanical centre and converted TPO angle.

TPO angle Rollover Calculation:
==================================
The calculation of Pinionangle raw and Mechanical centre is based on rollover compoensation if the left endstops are less tha right endstops.
The rollover compensation is illustrated below

.. image:: Rollover_case1.png
.. image:: Rollover_case2.png


Calculation of Accumulated rotor angle offset
==============================================

.. only:: confidential

    .. image:: RackPosSync_CalMan_OffsetCalculation.PNG

Accumulated rotor angle offset is the differnce between Accumulated rotor angle calulated from RackPositionMain component from RPS and 
pinion angle raw converted interms of rotor angle.


The following are the state machine states of RackPositionSynchronization component

Inital:
=======
During start up the statemachine state will be in Initial state.

The synchronization starts only when
    * Accumulated rotor angle from RackPositionMain is valid 
    * Learnt Endstops values based on TAS angle are valid 
    * True power on steering angle provided by HW LIB is valid
   
Exact:
======
During the Exact state RackPosition is calculated from Accumulated rotor angle corrected with Accumulated rotor angle offset(High Quality conditions)
    
The transition to Exact state happens only when the synchronization conditions mentioned above are fulfilled and 
the calculated raw pinion angle from TPO is of High Quality 
and the state request from RackPosition main compoenent not equal to init, ErrRev, ErrPerm
	
pinion angle raw is said to be of high Quality if it satisfies the below conditions
    * Low Rotor speed 
    * Limited motor torque is valid and Low	  


Raw:
====
During the Raw state RackPosition is calculating from Accumulated rotor angle corrected with Accumulated rotor angle offset.(Low Quality conditions)
    
The transition to Raw state happens only when the synchronization conditions mentioned above are fulfilled and 
the calculated raw pinion angle from TPO is of Low Quality 
and the state request from RackPosition main compoenent not equal to init, ErrRev, ErrPerm
	
pinion angle raw is said to be of Low Quality if it satisfies any of the below conditions
    * High Rotor speed 
    * Limited motor torque is High
	
Error_Reversible:
==================
The transition to Error_Reversible happens if any of the RackPosition synchronization or RackPosition main plausi error is trigerred. 
This state allows resynchronization to Exact or Raw state for certain limit, if the plausi error is configured as reactive error to error reversible(0). 
If the Plausi error is healed during resync then the tranistion would happen to Exact or Raw state depending on the Quality of Signals, if not Error_Permanent would be trigerred

During the error reversible state RackPosition will be calculated from Fallback signal[pinion angle raw]

Note: In case of OS Mon error or MCD red level errors, state machine will be in Error_Reversible state providing no fallback
  
Error_Permanent:
=================
The transition to Error_Permanent happens if it satisfies any of the following conditions
	* If the ECU state is Error and RackPosition will be set to invalid without fallback
	* if any of the RackPosition synchronization plausi or RackPosition main plausi error is trigerred and if the plausi error is configured as error reactive to error permanent(1)
	  and RackPosition will be calculated based on Fallback signal
	
Note: If plausi errors are healed in Error_Permanent state still rackposition would be calculated based on Fallback, only in the next ignition cycle recovery
from Error_Permanent happens

Resynchronization in Exact state
==================================
If the conditions are ok for an exact synchronization, and the already synchronized internal steering angle deviates from the calculated Pinion angle raw by more than a certain threshold, 
a resynchronization can be done (if activated in the ConfigFlags). 
		
Note: The Resynchronization is allowed for a certain threshold and if the threshold exceeds it would be captured by plausi and the state transition to Error_Reverisble or Error_Permanent 
happens depends on the configuration and Fallback signal would be used to calculate the RackPosition. 
		

Configuration
===============

To adapt the synchronization behavior of the steering angle to the requirements in the project there are configuration flags: 

sRpSync_ConfigFlagsSyncTPO_XDU16 (bitwise):

* 2 - Not used currently

* 8 - Not used currently

* 16 - Not used currently

* 32 - Not used currently

* 64 - Not used currently

* 256 - enable resynchronization of intSA to pinion angle raw on deviations at center

* 512 - Not used currently

* 1024 - Not used currently


Safety mechanism and Configuration
====================================

There is a separate monitoring for the RackPosition Main and the Synchronization. It can be configured for each of them, which parts of the monitoring shall be used and what 
should be the reaction to a detected error. The details about sRackPo_ConfigFlagsMainPlausiActivErr_XDU16 can be found in the RackpositionMain docu, the mapping of 
sRpSync_ConfigFlagsSyncPlausiActivErr_XDU16 is as following:  (bitwise; configure, which parts of monitoring are used (bit=1) or not (bit=0))

* 1 - check if deviation from pinion angle raw to internal angle exceeds limit based on wRackPo_MaxAbsDiffSteerAngle_XAU16

* 2 - Not used currently

* 4 - Not used currently

* 8 - Not used currently

* 16 - Not used currently

* 32 - Not used currently


sRpSync_ConfigFlagsSyncPlausiReactErr_XDU16 (bitwise): configure the reaction to the different checks; go to permanent error (bit=1) or reversible error (bit=0)

* The Bitmask is the same as given above.
 
In case an error is detected and entered to the error memory / event manager, the corresponding errorcode / monitoring ID is: MONID_RACKPOS_SYNC

Some of the outputs of this component are stored redundantly for safety reasons.


Calibration/Application Parameters
==================================

============================================   =======   ===========   ====================================================================================================================
Parameters in calculation                      Unit      Range         Description
============================================   =======   ===========   ====================================================================================================================
wRpSync_MaxDMWSAngle_XDU16                     deg SA    0 .. 2016     permitted steering angle range for TAS
vRpSync_RotSpdLowTh_XDU16                      1/min     0 .. 13000    Range qualifier (low range limit) of rotor speed - Determines the quality of TAS signal
mRpSync_MaxMMotLowDyn_XDU16                    Nm        0 .. 12       Assume low steering dynamics below this maximum motor torque
sRpSync_ConfigFlagsSyncTPO_XDU16                         0 .. 65535    Configuration if component behaviour; details in unit design
wRpSync_MinSyncDiff_XDU16                      deg RA    0 .. 20000    Required divergence of reference position and rotor angle zero-point for resynchronization
============================================   =======   ===========   ====================================================================================================================

============================================   =======   ===========   ====================================================================================================================
Parameters in monitoring                       Unit      Range         Description
============================================   =======   ===========   ====================================================================================================================
sRpSync_ConfigFlagsSyncPlausiActivErr_XDU16              0 .. 65535    Configuration of monitoring behavior; error enabled, if corresponding bit is set; otherwise error is disabled
sRpSync_ConfigFlagsSyncPlausiReactErr_XDU16              0 .. 65535    Configuration error leads to permanent error, if corresponding bit is set; otherwise error results in reversible error
tRpSync_ErrorFilterTimeout_XDU16               ms        0 .. 65000    Maximum filtertime for redundant filtering of general RackPos synchronization errors
wRackPo_MaxAbsDiffSteerAngle_XAU16             deg SA    0 .. 250      Threshold for comparison of internal steering angle and TAS angle
zRpSync_ErrorCounterLimit_XDU8                           0 .. 250      Threshold for Resync-Cycles after detected errors to switch to permanent error  
============================================   =======   ===========   ====================================================================================================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------

   ================================= =====   ==================  ========================
   System Parameter Name             Unit    Range               Description
   ================================= =====   ==================  ========================
   jsyInvSteeringRatio_XDU16                 900 .. 3000         1/steeringratio * 2^15
   ================================= =====   ==================  ========================


.. include:: RackPositionSynchronization_CalMan_VT.irst

.. only:: not confidential

   Smart Cruise Signal Processor | Input Interpolation
   ###################################################

   This component interpolates the Rack Position and provides it to the SCruise Input Limiter component.

.. only:: confidential

   Smart Cruise Signal Processor | Input Interpolation
   ###################################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================
   This component belongs to the functionality SCruise Signal Processor. .
   This component interpolates the Nominal Rack Position and provides it to the SCruiseInpLimr component.
   In case of invalid Requested Rack Position or Rack Position, the Interpolated Rack Position value is calculated as SNA.


   Block Diagram
   =============

   .. image:: SCruiseInpIntrpn_CalMan_BlockDiagram.png


   Input Signals
   -------------

   =====================================   ======   ===================================================================================================
   Signal Name                             Unit     Description
   =====================================   ======   ===================================================================================================
   lSCruiseI_RackPosn_xds16                mm       SCruise filtered current Rackposition
   lSCruiseI_ReqdRackPosn_xds32            mm       Requested Rackposition for SCruise from Bus, mapped to internally
   sSCruiseI_State_xdu8                    Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   zEpsInI_SCruiseElmIntrpnStepSize_xdu8            SCruise s requested number of elements used for input interpolation step size
   =====================================   ======   ===================================================================================================


   Output Signals
   --------------

   =================================   ====   ==========================================================================
   Signal Name                         Unit   Description
   =================================   ====   ==========================================================================
   lSCruiseI_NomRackPosnIntrpn_xds32   mm     Requested Rack Position Interpolated
   =================================   ====   ==========================================================================


   Detailed Description
   --------------------

   Within this component the requested rack position signal received from BUS will be interpolated in order to smoothen the steps before it is passed to the input limiter.
   Therefore the requested rack position received with a low cycle time is converted to smaller steps with a higher cycle time.
   A moving average is calculated for the requested rack position as long as interpolation and SCruise State are enabled.
   Else, the validity checked requested rack position is passed through and the actual rack position is used for moving average calculation.
   The moving average is calculated by adding the values of Rack Position/Requested Rack Position in buffer for number of instances and then dividing it by number of instances as defined by calibration.
   The number of steps for calculation of the moving average is used from the bus. In case the bus value becomes invalid or is not used from the costumer, the corresponding application parameter will be set. 

   Calibration/Application Parameters
   ==================================

   ======================================   ====   =====   ================================================================================================
   Parameter Name                           Unit   Range   Description
   ======================================   ====   =====   ================================================================================================
   fSCruise_EnableInpIntrpn_XDU8                   0..1    activate interpolation of input signal nominal rack position
   zSCruise_NumElementsMovingAverage_XDU8          2..20   Number of elements for moving average calculation (typically EPSInput_MessageCycletime/TaskTime)
   ======================================   ====   =====   ================================================================================================


   .. include:: SCruiseInpIntrpn_CalMan_VT.irst

Motor Torque Limiter
####################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The MotorTorqueLimiter is responsible for the limitation of the nominal motor torque of the steering controller (RG3) to a motor torque that can be handled by the driver.

System Overview
---------------
Component BoostcurveInterpolation is responsible for calculating the current assitance torque curve and the basic steer torque curve out of the calibrated dataset, 
with respect to the vehicle speed. Both curves are inputs to the steering controller (RG3) and therefore responsible for steering assistance and the steering feeling. 
The steering controller calculates the nominal motor torque.

The assistance torque curve is also an input to the MotorTorqueLimiter used as the basis for the current limitation curve.
The MotorTorqueLimiter limits the nominal motor torque to values defined by the limitation curve, considering the driving situation (e.g. current steering torque, vehicle speed). 
The limited motor torque is passed to the motor control (FOC).

AddOn-functions may additionally request a steering torque offset and/or an motor torque offset. An steering torque offset can be considered within MTL (by shifting the limiter curve x-axis),
but motor torque offsets has to be secured separately (ASIL D), if they are bypassing the MotorTorqueLimiter.

Block Diagram
=============

.. image:: MotorTorqueLimiter_CalMan_BlockDiagram.png


Input Signals
-------------

=====================================  =====   ======================
Signal Name                            Unit    Description
=====================================  =====   ======================
mApplI_TorsionBarTorque_xds16          Nm      HW LIB: torsion bar torque
nApplI_RotorSpeedFilt_xds16            1/min   filtered rotor speed
vApplI_AbsSafeVehicleSpeed_xdu16       km/h    abs. vehicle speed: Secured over vehicle speed range 
xApplI_GearSign_xds8                           sign of the steering gear  
mApplI_NominalMotorTorque_xds16        Nm      limited motor torque
mTrqSumI_SteerTrqSum_xds16             Nm      summation of all input steering torques of additional function
mApplI_AbsTorsionBarTorque_xdu16       Nm      HW LIB: abs torsion bar torque
mBciI_AssistCurveTBTXAxis_xau16        Nm      x-axis of interpolated assistance characteristic (torsion bar torque)
mBciI_AssistCurveMMotYAxis_xau16       Nm      y-axis of interpolated assistance characteristic (nominal assistance torque)
=====================================  =====   ======================


Output Signals
--------------

=============================================   ====   =====================
Signal Name                                     Unit   Description
=============================================   ====   =====================
mMotTorLimI_ValidatedMotorTorque_xds16          Nm     Limited motor torque                               
=============================================   ====   =====================

.. only:: confidential

   =============================================   ====   =====================
   Signal Name                                     Unit   Description
   =============================================   ====   =====================
   xMotTorLimI_WeightedIntegratedDeviation_xdu16          weighted integrated deviation of the motor torque
   sMotTorLimI_ErrLvl_xdu8                                error level MotorTorqueLimiter
   =============================================   ====   =====================

Detailed Description
--------------------

The function is responsible for the calculation of the basic limitation curve out of the assistance torque curve provided by component BoostCurveInterpolation. 
The component MotorTorqueLimiter consists of several parts:

1.Calculation of the Basic limitation curve

The basic limitation curve is based on the actual assistance torque curve, allocated with an vehicle speed dependent and torsionbar torque dependent offset. 
This offset has to cover the other parts of the requested motor torque (e.g. active return torque, inertia torque, RG3-part). The offset is extended in negative TBT-direction for an applicable range.
The limitation curve is mirrored on the y-axis to cover also negative steering direction.       

.. image:: limitationCurve_blockDiagram.png


2.Expanding the Basic limitation curve in generatoric mode

The function is responsible for the expandation of the basic limitation curve in case that the motor becomes generatoric.
 .. image:: limitationCurvegeneratoricMode_blockDiagram.png
 
3.Additional filtering of the limitation curve

In general, the requested assistance torque is gradient limited by RG3’s DAC (DynamicAssistControl) component that shall ensure controller stability. 
This may result in violations of the limitation curve (see picture below) in cases that the torsionbartorque decreases very fast while the assistance torque decreases much more slowly due to mentioned DAC gradient limitation. The result is a limitation of the motor torque.

 .. image:: LimitationCurveFiltering_blockDiagram.png

 To avoid this limiter violations and following an unwanted motor torque limitation, a PT1-filter can be applied on the limitation curve. If the upper limitation curve is decreasing (or if the lower limitation curve is increasing) the limitation curve is filtered as shown in the follwing picture:

 .. image:: LimitationCurveFiltering1_blockDiagram.png 

 Note: The filter of the limitation curve shall be equal or slower than the filter applied on the DAC component.
 
4.Limitation and Reduction of the resulting motor torque

If the nominal motor torque exceeds the limitation curve, the weighted integrated deviation (normalized value of the integrated deviation, range from 0 .. 1) will be calculated. 
Depending on this weighted integrated deviation, the resulting motor torque will be limited to the limitation curve (after a short ‘fading’ phase, if applied).

If the weighted integrated deviation reaches its limit, the following reduction is possible
  * reduction to a defined percentage value (in picture: 0%) of upper limit
    (application parameters xMotTorLim_LowestReductionLevel_XDU16 == target percentage value, with gradient xMotTorLim_Grad4RedRampDown_XAU16 for ramp down and xMotTorLim_Grad4RedRampUp_XAU16 for ramp up) 
	
 .. image:: Limitation_Reduction_Motortorque_blockDiagram.png
 
If the requested motor torque fall below the limitation curve again, the reduction is cancelled and the reduced motor torque ramps up to the nominal motor torque again.


5. Tuning recommondation

Due to resolution of mMotTorLim_MaxIntegralInv_XDU16, the weighted integral deviation will not reach to 1.
Based on the tuning of the curve xMotTorLim_FadeDepOnIntegrator_XAU16, its possible that its interpolated value will never reach the value of 1, so 
fading will not happen completly and the limitation of the nominal torque will be bit higher than the max limit even the integral has reached its maximum value.
So, while tuning mMotTorLim_MaxIntegralInv_XDU16, one should take care of below points

1. mMotTorLim_MaxIntegralInv_XDU16 should be inverse of mMotTorLim_MaxIntegral_XDU16 or vice versa
2. in terms of resolution, mMotTorLim_MaxIntegralInv_XDU16 should be tuned always greater by 1 digit. refer example below.

example:
Let mMotTorLim_MaxIntegral_XDU16 is 30. So, mMotTorLim_MaxIntegralInv_XDU16 should be 1/30 i.e. 0.033333 (with scaling used for mMotTorLim_MaxIntegralInv_XDU16, in SW it will set as 0.033325 which is not exact inverse of mMotTorLim_MaxIntegral_XDU16)
But keeping the resolution of mMotTorLim_MaxIntegralInv_XDU16 in mind, we should tune it to 0.033333 + 1/(scaling of mMotTorLim_MaxIntegralInv_XDU16) 


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

Basic limitation curve parameters
---------------------------------
=============================================   =====   ==================   =============================================
Parameter Name                                  Unit    Range                Description
=============================================   =====   ==================   =============================================
mMotTorLim_MmotShiftForCalculatedLimits_XAU16   Nm      0..4                 Motor torque offset to calculate the limitation curve out of the assistance torque curve
xMotTorLim_FactExpandLimitsDepOnTbt_XAS16       %       0.1 .. 2             Torsion bar torque dependent factor
mMotTorLim_TbtShiftForZeroMmotTh_XDS16          Nm      0.0009765625 .. 6    Torsion bar torque (in neg. direction) where limitation curve starts ramping to zero
sMotTorLim_UseSteeringTorqueOffset_XDU8                 0 .. 1               Switch, to add the steering torque offset to the torsion bar torque. (1 -> Add offset to TBT, 0 -> only TBT is used
=============================================   =====   ==================   =============================================

Expand in generatoric mode parameters
-------------------------------------
=========================================   =====   ==============   =============================================
Parameter Name                              Unit    Range            Description
=========================================   =====   ==============   =============================================
mMotTorLim_GeneratoricModeLimit_XAS16       Nm      0..12            characteristic limit curve of the generatoric operation
xMotTorLim_Integ2StopGenRotSpeedExp_XDU16   %       0 .. 0.99        minimum weighted integrated deviation to stop the expansion of motor torque limits over generatoric rotor speed
tMotTorLim_Time2StopGenRotSpeedExp_XDU8     s       0 .. 0.02        minimum time to stop the expansion of motor torque limits over generatoric rotor speed
mMotTorLim_Tbt2StopGenRotSpeedExp_XDU16     Nm      0 .. 15          Torsion bar torque threshold to stop generatoric rotor speed expansion
=========================================   =====   ==============   =============================================


Additional filtering of the limiation curve
-------------------------------------------

=============================================    =====   ==============   =============================================
Parameter Name                                   Unit    Range            Description
=============================================    =====   ==============   =============================================
sMotTorLim_UseFilterOnDecrLimits_XDU8            Nm      0..1             1=Filter on decreasing upper and lower limits active, 0=filter inactive
xMotTorLim_Integ2StopFilterOnDecrLimits_XDU16            0 .. 0.99        minimum weighted integrated deviation to stop filtering the decrementing upper and lower limits
xMotTorLim_FilterFactorOnDecrLimits_XDU16                0.01 .. 0.1      filter factor of PT1-filter for decrementing upper and lower limits
=============================================    =====   ==============   =============================================

Limitation and reduction
------------------------

=============================================    =====   ==============   =============================================
Parameter Name                                   Unit    Range            Description
=============================================    =====   ==============   =============================================
mMotTorLim_MaxIntegral_XDU16                     Nm/ms   1 .. 50          maximum allowed integral [Nm/s]
mMotTorLim_MaxIntegralInv_XDU16                          0.015 .. 1       inverse maximum allowed integral [s/Nm]
xMotTorLim_FadeDepOnIntegrator_XAU16             %       0 .. 1           slope of fading factor (do not change 1st point to avoid level-2-shutdown)
tMotTorLim_DelayToStartReduction_XDU16           s       0 .. 10          time to start reducing
xMotTorLim_LowestReductionLevel_XDU16            %       0                lowest allowed reduction level
xMotTorLim_Grad4RedRampDown_XAU16                %/ms    0 .. 1           reduction gradient ramp down [factor/ms]
xMotTorLim_Grad4RedRampUp_XAU16                  %/ms    0.000183 .. 1    reduction gradient ramp up [factor/ms]   
=============================================    =====   ==============   =============================================


Signalling MTL Limitation
--------------------------
====================================  =====  ==============   =============================================
Parameter Name                        Unit   Range            Description
====================================  =====  ==============   =============================================
mMotTorLim_MaxAllowedNomMot_XDU16     Nm     0 .. 8           max allowed NominalMotTorq for WarnLampCheck
mMotTorLim_MaxAllowedTBT_XDU16        Nm     0 .. 25          max allowed TBT for WarnLampCheck
tMotTorLim_DiagTime_XDU16             ms     0 .. 200         max Time in the state Prefailed or Prepassed
xMotTorLim_PreFailedRedLvl_XDU16             0 .. 1           reduction level between mApplI_NominalMotorTorque and mMotTorLimI_ValidatedMotorTorque to go to Prefailed
xMotTorLim_PrePassedRedLvl_XDU16             0 .. 1           reduction level between mApplI_NominalMotorTorque and mMotTorLimI_ValidatedMotorTorque to go to Prepassed
====================================  =====  ==============   =============================================


Level2 monitoring prarmeters
-----------------------------

===============================================    =====   ==============   =============================================
Parameter Name                                     Unit    Range            Description
===============================================    =====   ==============   =============================================
mMotTorLim_L2MmotShiftForCalculatedLimits_XAF32    Nm      0 .. 4           L2 motor torque offset to calculate the limitation characteristic out of the assist characteristic (shall be identical to the values of mMotTorLim_MmotShiftForCalculatedLimits_XAU16)
xMotTorLim_L2FactExpandLimitsDepOnTbt_XAF32        %       0.1 .. 2         L2 torsion bar torque dependent factor (shall be identical to the values of xMotTorLim_FactExpandLimitsDepOnTbt_XAS16)
mMotTorLim_GeneratoricModeLimit_XAF32              Nm      0 .. 12           characteristic limit curve of the generatoric operation (shall be identical to the values of mMotTorLim_GeneratoricModeLimit_XAS16)
===============================================    =====   ==============   =============================================


.. only:: confidential



   Failure Injection
   -----------------

   =============================================    =====   ==========   =============================================
   Parameter Name                                   Unit    Range            Description
   =============================================    =====   ==========   =============================================
   sMotTorLim_EnableErrorInjection_XDU8                     0 .. 2       Switch to enable error injection (test value)0=error injection off,1=set substitute value for input signal motor torque,2=add offset value to input signal motor torque
   mMotTorLim_ErrorInjectionMotorTorque_XDS16       Nm      -12 .. 12    Motor torque substitute value of offset for error injection tests (test value), depending on sMotTorLim_EnableErrorInjection_XDU8
   mMotTorLim_L2SwitchOffTestMotorTorque_XDS16      Nm      -5 .. 5      Motor torque for L2 switch off check test (test value),add an offset torque to the level2 functionality.
   =============================================    =====   ==========   =============================================

   Others
   ------
   =============================================    =====   =======   =============================================
   Parameter Name                                   Unit    Range     Description
   =============================================    =====   =======   =============================================
   sMotTorLim_LimiterSwitch_XDU8                            0 .. 1    Switch to deactivate limiter (Note: limiter shall always be active)0=limiter active [default],1=limiter inactive
   fMotTorLim_DeactivateLevel2Error_XDU8                    0 .. 1    Switch to deactivate level2 monitoring (Note: level2 monitoring shall always be active)0= limiter level2 plausi active [default],1= limiter level2 plausi inactive
   =============================================    =====   =======   =============================================


.. include:: MotorTorqueLimiter_CalMan_VT.irst

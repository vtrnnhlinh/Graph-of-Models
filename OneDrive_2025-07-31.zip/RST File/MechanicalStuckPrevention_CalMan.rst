Mechanical Stuck Prevention
###########################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
The function is used to calculate the Motortorque to avoid Mechanical Stuck Prevention.

.. only:: confidential

   Block Diagram
   =============

   .. image:: MechanicalStuckPrevention_CalMan_BlockDiagram.png



Input Signals
-------------

==================================  =====   ==========================================================================================
Signal Name                         Unit    Description
==================================  =====   ==========================================================================================
nApplI_RotorSpeedFilt_xds16         1/min   Filtered Rotor Speed.This interface describes the filtered rotor speed.
mApplI_TorsionBarTorque_xds16       Nm      HW LIB:torsion bar torque
mApplI_GradTorsionBarTorque_xds16   Nm/ms   HW LIB:torque gradient
wApplI_SteeringAngle_xds16          °       Corrected Steering Angle.This is the short-time and long-time corrected steering angle.
vApplI_AbsVehicleSpeedFilt_xdu16    km/h    Abs.vehicle speed:processed
sApplI_SteeringAngleState_xdu8      -       status steering angle from rotor angle not corrected
sApplI_VehicleSpeedState_xdu8       -       Validflag for vehilce speed
xApplI_GearSign_xds8                -       Sign of the steering gear
mApplI_LimitedMotorTorque_xds16     Nm      limited motor torque
fEndStopI_EndStopActive_xdu8        -       flag for EndStop active
==================================  =====   ==========================================================================================

.. only:: confidential

   ===================================  =====   ==========================================================================================
   Signal Name                          Unit    Description
   ===================================  =====   ==========================================================================================
   fMchStPrvI_MonSafeOk_xdb             -       Indicates whether MonitorSafe checks report OK (1) or if they have detected a problem (0)
   sHwlWrapI_TorsionBarTorqueState_xde  -       Torsion Bar Torque State
   ===================================  =====   ==========================================================================================


Output Signals
--------------

==================================   ====   ============================================================================
Signal Name                          Unit   Description
==================================   ====   ============================================================================
mMchStPrvI_MotorTorque4Check_xds16   Nm     Motortorque Mechanical Stuck Prevention for check
==================================   ====   ============================================================================


Detailed Description
--------------------
The component MechanicalStuckPrevention eleminates discontinuous movement due to friction (e.g. stuck gears in the steering gear Dp/Epsc systems).

The input-signals are checked for validity. If the inputs are not Vaild, the torque is set to zero to avoid Mechanical stuck.

The component implements a period square signal for the motortorque to prevent mechanical stuck. This torque consists of two parts. 
A background vibration (permananet square signal with low amplitude) in order to overcome the basic friction in addtion to a  
vibration, which is activated in case of stuck moments.  The vibration is activated if the actual rotor speed is less than the reference rotor speed.

The calculation of motortorque based on the below formula::

   Mechanical Stuck Prevention Motor Torque = Activation level Mechanical Stuck Prevention * Square Signal with Period

Parameters xMchStPrv_GroundLevelHakelVFZFactor_XAU16,xMchStPrv_GroundLevelHakelAngle_XAU16,xMchStPrv_GroundLevelFactHakel_XDU16 shall be tuned to avoid background mechanical notchiness.


Calibration/Application Parameters
==================================

=========================================   =====   ==========   ===================================================================================
Parameter Name                              Unit    Range        Description
=========================================   =====   ==========   ===================================================================================
xMchStPrv_GradTBTFilterFact_XDU16            -      0.001 .. 1   filter factor on gradient TBT
xMchStPrv_HakelGrad_XDU16                    -      0 .. 1       Gradient for ramp in MchStPrv moment
xMchStPrv_GroundLevelHakelVFZFactor_XAU16    -      0 .. 1       Factor on ground level of MchStPrv amplitude depending on vehicle velocity
xMchStPrv_GroundLevelHakelAngle_XAU16        -      0 .. 1       factor for background vibration depending on steering angle
xMchStPrv_GroundLevelFactHakel_XDU16         -      0 .. 1       factor for MchStPrv amplitude for background vibration
nMchStPrv_BoundRotSpeedGRADTBT_XAU16        1/min   0 .. 150     reference rotor speed depending on gradient TBT
nMchStPrv_BoundRotSpeedSWA_XAU16            1/min   0 .. 150     reference rotor speed depending on steering wheel angle";
xMchStPrv_RotSpeedRefVFZFactor_XAU16         -      0 .. 1       factor on reference rotor speed depending on vehicle velocity
xMchStPrv_MaxActDepVFZ_XAU16                 -      0 .. 1       Maximal activation depending on vehicle velocity 
nMchStPrv_BoundRotSpeedMeff_XAU16           1/min   0 .. 150     reference rotor speed depending effective torque      
nMchStPrv_BoundRotSpeedMeffVO_XAU16         1/min   0 .. 150     reference rotor speed depending on effective torque for low vehicle speed velocity
vMchStPrv_MeffV0bound_XDU16                 km/h    0 .. 230     Switch for BoundRotSpeedTBTV0 to BoundRotSpeedTBT
tMchStPrv_HakelPeriodHalf_XDU16              -      0 .. 50      time in ms for half period of MchStPrv square moment
xMchStPrv_MaxActDepSteeringAngle_XAU16       -      0 .. 1       Maximal activation depending on steering angle   
=========================================   =====   ==========   ===================================================================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------

   =========================   =====   ==========   ===================================================================================
   Parameter Name              Unit    Range        Description
   =========================   =====   ==========   ===================================================================================
   xsyRatioEfficiency_XDU16      -     0 .. 0.2     scaling factor for torsion bar torque to motor torque (system parameter of steering gear)
   =========================   =====   ==========   ===================================================================================





.. include:: MechanicalStuckPrevention_CalMan_VT.irst

WormWheelProtection
###################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

WormWheelProtection is one component of the functionality OverloadProtection.

Overload Protection provides the possiblity to check threshold values
of the various tracked system loads / damage and stimulate a corresponding
system reaction when these values have surpassed their thresholds.

Even if the DataFlash is damaged (eg. CRC-Error) the Overload Protection set an ErrorLevel.

This component "WormWheelProtection" serves to protect the system against excessive
damage to the worm wheel (a mechanical part of the dual-pinion steering system).

The receivers (yLdTrkI_WormWheelRotDamage_xdu32,yLdTrkI_WormWheelRotDamageH_xdu32, yLdTrkI_WormWheelImpDamage_xdu32, yLdTrkI_WormWheelImpDamageH_xdu32)
are the low and high parts of a 64 bit variable, therefore the H_xdu32 represents the high 32 bit.

Block Diagram
=============

StartUp
=============
.. image:: WormWheelProtection_CalManStartUp.png

Cyclic
=============
.. image:: WormWheelProtection_CalManCyclic.png

JobStatus
=============
.. image:: WormWheelProtection_CalManJobStatus.png

Input Signals
-------------

==========================================           ====   ======================
Signal Name                                          Unit   Description
==========================================           ====   ======================
yLdTrkI_WormWheelRotDamage_xdu32                            WormWheel Rotational Damage (low bytes)

yLdTrkI_WormWheelRotDamageH_xdu32                           WormWheel Rotational Damage (high bytes)

yLdTrkI_WormWheelImpDamage_xdu32                            WormWheel Impact Damage (low bytes)

yLdTrkI_WormWheelImpDamageH_xdu32                           WormWheel Impact Damage (high bytes)

mLdTrkI_MaxWormWheelTorque_xdu16                     Nm     This shows the highest worm wheel torque which occured during this ignition cycle.

mApplI_LimitedMotorTorque_xds16                      Nm     Limited motor torque

sLdTrkI_ReadJobResultOK_xdu8								         Job Result of reading NvM data: 0-noResult, 1-DataOk 2-DataCorrupted

sLdTrkI_WriteJobResultOK_xdu8								         Write Job Result of writing NvM data: 0-noResult, 1-DataOk 2-DataCorrupted
==========================================           ====   ======================


Output Signals
--------------

==========================================           ====   ======================
Signal Name                                          Unit   Description
==========================================           ====   ======================
sOvrLdProtI_ErrLvl_xdu8                                      ErrorLevel of Worm Wheel

sOvrLdProtI_ErrLvl_Red_xdu8                                  ErrorLevel of Worm Wheel (explicit redundant)

sOvrLdProtI_WormWheelDamageState_xdu8						 State of Worm Wheel  Damage - 0 No Damage, 1 low Damage, 2 high Damage, 3 DF-Error, 4 Heavy Impact

fOvrLdProtI_HeavyImpactOccurred_xdb                          Flag: The WormWheelTorque is over the max value

yOvrLdProtI_WormWheelDamageSum_xdu32						 Total value of the worm gear alteration (low bytes)

yOvrLdProtI_WormWheelDamageSumH_xdu32						 Total value of the worm gear alteration (high bytes)
==========================================           ====   ======================


Detailed Description
--------------------
The received damages are
compared with the High/Low Limit to detect if the WormWheelDamage is higher than the max. limit.
If this max limit is exceeded by the Worm Wheel Damage the ErrorLevel ("sOvrLdProtI_ErrLvl" and "sOvrLdProtI_ErrLvl_Red")is set
to "ERRLVL_HW_ERROR" in the next ignition cycle during start up.

The component includes three servers:

OvrLdProtI_WormWheelStartupCheck

	This server is called while starting up the ECU and checks if the WormWheelDamage is above an Limit, the DataFlash is corrupted or there was an heavy impact during last cycle.
	If one of these events happened, the ErrorLevel is set and the system switch to state Error.

   - If the WormWheelDamage is above the High Limit-->s_WormWheelDamageState is set to STATE_HIGH_DAMAGE-->The Event History ID  is MONID_WORMWHEELPROTECTION_HIGH

   - If fOvrLdProtI_HeavyImpactOccurred_xdb is set-->s_WormWheelDamageState is set to STATE_HEAVY_IMPACT-->The Event History ID  is MONID_WORMWHEELPROTECTION_HEAVYIMPACT

   - If the DF is corrupted-->s_WormWheelDamageState is set to STATE_DATA_ERROR-->The Event History ID  is MONID_DF_WORMWHEELPROTECTION

OvrLdProtI_WormWheelCyclicCheck

	This server is called cyclic and react of one of the following things:

   - If the WormWheelDamage is above the Low Limit-->s_WormWheelDamageState is set to STATE_LOW_DAMAGE-->The Event History ID  is MONID_WORMWHEELPROTECTION_LOW

   - If the WormWheelDamage is above the High Limit-->s_WormWheelDamageState is set to STATE_HIGH_DAMAGE-->The Event History ID  is MONID_WORMWHEELPROTECTION_HIGH

   - If mLdTrkI_MaxWormWheelTorque is above the Limit-->The flag HeavyImpact is set-->s_WormWheelDamageState is set to STATE_HEAVY_IMPACT-->The Event History ID  is MONID_WORMWHEELPROTECTION_HEAVYIMPACT

   - Additionally if the damage is not written to the Data Flash properly during ApplicationInit (StartUp), an error level is set and MONID_WORMWHEELDAMAGETRACKER_PREASSISTMONITORING will be triggered.
     This is to indicate that AssistanceController will not have a transition from NoAssist to Assist, even though the Assistance torque is greater than zero.

OvrLdProtI_NvMJobStatusCallback

 	The server checks if the NvM Read all was successful and the information from DF is copied to RTE.

   - If NvM read is not successful-->ErrorLevel is set: sOvrLdProtI_ErrLvl_xdu8 = ERRLVL_SW_ERROR-->The Event History ID  is MONID_DF_WORMWHEELPROTECTION



Error reaction
==================================
Error reaction is separated into reaction at start up (StartUpCheck) and during the ignition cycle (CyclicCheck).

.. image:: WWP_CalMan.png


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

.. Move confidential parameters from the above table down here, if applicable.

.. only:: confidential

   ===========================================    =====   ===============   =======================================================
   Parameter Name                                 Unit    Range             Description
   ===========================================    =====   ===============   =======================================================
   zOvrLdProt_SwitchOffCounterHigh32_XDU32                0..4294967295     Threshold for steering assistance off - high 32 bit

   zOvrLdProt_SwitchOffCounterLow32_XDU32                 0..4294967295     Threshold for steering assistance off - lower 32 bit

   mOvrLdProt_HeavyImpactLimit_XDU16               Nm     0..400            Max allowed value of ImpactTorque

   zOvrLdProt_WarningCounterHigh32_XDU32                  0..4294967295     Threshold for warning (yellowlight) - higher 32 bit

   zOvrLdProt_WarningCounterLow32_XDU32                   0..4294967295     Threshold for warning (yellowlight) - lower 32 bit
   ===========================================    =====   ===============   =======================================================

Deactivation of WormWheelProtection
======================================

(Only for EPSapa-Projects with unified Software "Einheitssoftware")
If the value of SY_WORMWHEEL_ERRORREACN_ACTIVATED is 0, the Output Signals ("sOvrLdProtI_ErrLvl_xdu8" and "sOvrLdProtI_ErrLvl_Red_xdu8")are set to {NO_ERROR}.
It is also important that no event entry or warning light is set.
So the WormWheelProtection is deactivated!


.. include:: WormWheelProtection_CalMan_VT.irst

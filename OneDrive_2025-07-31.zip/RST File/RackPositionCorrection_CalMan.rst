Rackposition Correction 
#######################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component Rackposition Correction provides a correction value to the steering angle in order to calculate a steering angle with better alignment to the straight ahead position of the vehicle.
Therefore the uncorrected steering angle is slowly filtered (PT1) as long as the straight ahead conditions (from yawrate and additional) are fulfilled.
It is assumed that the average steering angle should be zero when driving straight ahead.

The algorithm is devided into a faster learning part (shortterm correction) and a slower learning part (longterm correction).
The longterm correction value is stored in the NVRam to preserve it for later key cycles.

The learning values can separately be reset and also the learning can individually be enabled/disabled for LT and ST. 


Block Diagram
=============

.. image:: RpCorrection.png


Input Signals
-------------

=====================================   =====   =============================================================================
Signal Name                             Unit    Description
=====================================   =====   =============================================================================
mApplI_TorsionBarTorque_xds16            Nm     Torsion bar torque
sHwlWrapI_TorsionBarTorqueState_xde             HW LIB: state / validity of torsion bar torque
xApplI_TorsionBarStiffness_xdu16         Nm/°   stiffness of torsionbar
vApplI_AbsVehicleSpeedFilt_xdu16        kph     vehicle speed, filtered
sApplI_VehicleSpeedState_xdu8                   state / validity of vehicle speed
sApplI_RackPosQualifier_xdu8                    state of rackposition / steering angle
sRpCorrI_EnableCorrectionSupp_xdu8              control signal to enable correction algorithm LT and ST
mApplI_LimitedMotorTorque_xds16         Nm      limited motor torque
nRackPoI_RotorSpeed_xds16               rpm     rotor speed, GearSign compensated (counterclockwise positive)
wRackPoI_RotorAngleRamped               °       accumulated rotor angle, 0° at calibrated position
zRpSyncI_CalibCycleCounterClbNVR                counter of calibration cycle, to be compared with zRpCorrI_CalibCycleCounterLTNVR
sAhaDetI_AheadFromYaw_xdu8                      result of ahead detection from yawrate, torsionbar torque and vehicle speed
=====================================   =====   =============================================================================


Output Signals
--------------

==========================================   ====   ===================================================================================================================
Signal Name                                  Unit   Description
==========================================   ====   ===================================================================================================================
wRpCorrI_RotAngLTCorrNVR                     °      longterm correction value, in terms of rotor angle; stored in NVRam
wRpCorrI_RotAngSTCorr                        °      shortterm correction value, in terms of rotor angle
zRpCorrI_CalibCycleCounterLTNVR                     counter of calibration cycle, to reset correction values in case of new calibration (only if enabled by cfg)
==========================================   ====   ===================================================================================================================


Detailed Description
--------------------

The RackPositionCorrection function calulates a long- and a shortterm correction value for the steering angle, based on the rotor angle.
Therefore certain conditions have to be fulfilled to assume the vehicle is driving straight ahead on an average. Then the deviation of the 
calibrated rotor angle from zero is learned via a slow filter.

.. image:: RpCorr_LT_learn.png

The longterm correction value is stored in the data flash. Its learning speed depends proportionally on the vehicle speed, up to a threshold. Above this threshold the speed dependent factor equals one.
The shortterm correction is basically the same as the longterm correction, but learning faster and not depending on the vehicle speed.

.. image:: RpCorr_SpeedDependency.png

Safety mechanism
""""""""""""""""

There is no special safety mechanism for the RackPosition Correction implemented, only the outputs are limited to thresholds and monitored. The longterm correction value is stored redundantly.
The correctness of the learned values cannot be guaranteed (only within thresholds).



Calibration/Application Parameters
==================================

=========================================   =====   ===========   ====================================================================================================================
Parameter Name                              Unit    Range         Description
=========================================   =====   ===========   ====================================================================================================================
sRpCorr_ConfigFlagsCorr_XDU8                        0 .. 15       configuration: 1-enable LT, 2-enable ST, 4-torsion in DynSteerAngle, 8-check calib counters 
wRackPoI_MaxTorsionBarTorsion_XDU16         °       0 .. 10       maximum possible torsion of torsionbar (mechanical clutch; steering angle) 
wRpCorr_Resolution_XDU16                    °       0 .. 255      resolution adjustments for slow learning or learning only significant changes
mRpCorr_LTATBT_XDU16                        Nm      0 .. 8        upper torsionbar torque threshold for longterm correction
mRpCorr_LTMaxMotTorq_XDU16                  Nm      0 .. 8        upper motor torque threshold for longterm correction
tRpCorr_LTimeIntegTime_XDU8                 s       0 .. 20       delay of stopping longterm correction when leaving allowed range
xRpCorr_LTACompIntegFactor_XDU16                    0 .. 0.0625   integration factor of longterm correction --> learning speed
vRpCorr_VehicleSpeedWeight_XDU16            kph     0 .. 255      upper threshold of vehicle speed; above the learning factor is constantly 1
tRpCorr_DetectionTimerLT_XDU8               s       0 .. 20       detection time for straight ahead in longterm correction / debouncing
wRpCorr_LTACompIntegRange_XDU16             °       0 .. 600      working range of longterm correction, in terms of rotor angle
wRpCorr_LTACompMaxAngle_XDU16               °       0 .. 600      limitation of longterm correction, in terms of rotor angle
mRpCorr_STMaxMotTorq_XDU16                  Nm      0 .. 8        upper motor torque threshold for shortterm correction
mRpCorr_STMaxTBT_XDU16                      Nm      0 .. 8        upper torsionbar torque threshold for longterm correction
vRpCorr_STMinVehicleSpeed_XDU16             kph     0 .. 255      lower threshold of vehicle speed for shortterm correction
xRpCorr_STIntegrationFactor_XDU16                   0 .. 0.9      integration factor of shortterm correction --> learning speed
tRpCorr_DetectionTimerST_XDU8               s       0 .. 20       detection time for straight ahead in shortterm correction / debouncing
wRpCorr_STACompIntegRange_XDU16             °       0 .. 600      working range of shortterm correction, in terms of rotor angle
wRpCorr_STACompMaxAngle_XDU16               °       0 .. 600      limitation of shortterm correction, in terms of rotor angle
tRpCorr_CycleTimeRpCorr_XDU8                ms      0 .. 1        cycle time of steering angle correction
=========================================   =====   ===========   ====================================================================================================================


.. only:: confidential

   Internal calibration parameters
   -------------------------------

   ========================== =====   ============  ========================
   Parameter Name             Unit    Range         Description
   ========================== =====   ============  ========================
   jsyInvSteeringRatio_XDU16          900 .. 3000   1/steeringratio * 2^15
   ========================== =====   ============  ========================

.. include:: RackPositionCorrection_CalMan_VT.irst

Low Voltage Assist Reduction
#############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The function reduces the EPS power consumption to avoid a crash of the on-board power supply in case of under voltage.


Block Diagram
=============

.. only:: confidential

   .. image:: LowVoltageAssistReduction_CalMan_BlockDiagram.png
  
.. only:: not confidential

   .. image:: LowVoltageAssistReduction_CalMan_Customer_BlockDiagram.png

Input Signals
-------------
===============================   =====   ======================
Signal Name                       Unit    Description
===============================   =====   ======================
sApplI_EngineRunning_xdu8                 State of combustion engine (0 == EngineNotRunning, 1 == EngineRunning, 2 == EngineRunningStable)
uApplI_SupplyVoltage_xdu16         V      SupplyVoltage
vVehSpI_AbsMaxSafeVehSpd_xdu16    km/h    Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
===============================   =====   ======================

.. only:: confidential


   =================================   ====   =====================
   Signal Name [Internal]              Unit   Description
   =================================   ====   =====================
   xtcActualTorqueRedLevel_xau16              active reduction for every channel
   =================================   ====   =====================


Output Signals
--------------

.. only:: confidential

   ===================================   ====   =====================
   Signal Name [Internal]                Unit   Description
   ===================================   ====   =====================
   uLowVoltAssRed_SupplyVoltage_xdu16     V     mapped SupplyVoltage signal to characteristic curve or substitute value
   ===================================   ====   =====================


Detailed Description
--------------------

Supply voltage reduction shall only be allowed if 
the enging is running stable (stable on-board power supply shall be given) or Vehicle speed is more than 10 km/h.
The DesiredRedLevel will be set to 100 %,if the reduction is not allowed.
The TorqueReductionLevel will be reduced to a Desired Reduction Level, which is "100 %" if Engine is not running stable.
TorqueGradientLimit and MotorCharTorqueAxis will be reduced preventively because there is no significant loss of assistance in that cases.

.. only:: confidential

   During the holding time the positive gradients are set to 0 %/ms to avoid a bounce of the assistance.

Calibration/Application Parameters
==================================

==========================================================   ======   ===========   =============================================
Parameter Name                                               Unit     Range         Description
==========================================================   ======   ===========   =============================================
xLowVoltAssRed_UnderVoltageReductionLevel_XAU16                       0 .. 1        reduction motor torque due to under voltage 
xLowVoltAssRed_UnderVoltageTorqueReductionGradient_XAU16              0 .. 1        reduction motor torque gradient due to under voltage
xLowVoltAssRed_UnderVoltageMotorCharTorqueAxis_XAU16                  0 .. 1        compression motor characteristic curve  
xLowVoltAssRed_NegativeMotorTorqueGradient_XDU16             1/1ms    0 .. 1        negative motor torque reduction level
xLowVoltAssRed_NegRedGradMotorTorqueGrad_XDU16               1/1ms    0 .. 1        negative motor torque gradient limit
xLowVoltAssRed_NegGradCompressMotorChar_XDU16                1/1ms    0 .. 1        negative gradient of compressing motor characterisic curve 
xLowVoltAssRed_PositiveMotorTorqueGradient_XDU16             1/1ms    0 .. 0.001    positive  motor torque reduction level
xLowVoltAssRed_PosRedGradMotorTorqueGrad_XDU16               1/1ms    0 .. 0.001    positive motor torque gradient limit
xLowVoltAssRed_PosGradCompressMotorChar_XDU16                1/1ms    0 .. 0.001    positive gradient of compressing motor characterisic curve
==========================================================   ======   ===========   =============================================

.. only:: confidential

   =====================================================      =====   ===========   =============================================
   Parameter Name                                             Unit    Range         Description
   =====================================================      =====   ===========   =============================================
   uLowVoltAssRed_SubstSupplyVoltage_XDU16                      V     0 .. 33       substitute value in case of invalid SupplyVoltage
   tLowVoltAssRed_UnderVoltageHoldTime_XDU16                    s     0 .. 65       holding time for rejecting an instant rising of assistance 
   vLowVoltAssRed_ValidMinSpeed_XDU16                         km/h    0 .. 500      Min Vehicle Speed for Low Volt Assist Reduction Activation to protect against SLoA
   =====================================================      =====   ===========   =============================================

.. include:: LowVoltageAssistReduction_CalMan_VT.irst

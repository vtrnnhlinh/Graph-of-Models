Pull Drift Compensation
########################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

PDC (PullDriftCompensation) provides compensation for the right-hand or left-hand pull on a straight road that is tilted towards the right or towards the left. 
The function prevents a situation in which the driver has to continually apply a torque despite a straight road to keep the vehicle in the lane.
PDC learns and applies a rack force offset to minimize the torque that the driver has to apply. 



Block Diagram
=============
.. only:: confidential

   .. image:: PullDriftCompensation_CalMan_BlockDiagram.png
   

Input Signals
-------------

=================================   ====   ======================================================================
Signal Name                         Unit   Description
=================================   ====   ======================================================================
sApplI_SteeringAngleState_xdu8             status steering angle from rotor angle not corrected 
sApplI_VehicleSpeedState_xdu8              Validflag for vehicle speed
vApplI_YawVelocity_xds16                   Yawrate
mApplI_TorsionBarTorque_xds16       Nm     HW LIB: torsion bar torque
xApplI_GearSign_xds8                       steering gear sign
vApplI_AbsVehicleSpeedFilt_xds16    km/h   abs.vehicle speed:processed
wApplI_SteeringAngle_xdu16          °      abs.corrected steering angle
=================================   ====   ======================================================================

.. only:: confidential
   
   =================================   ====   ======================================================================
   Signal Name                         Unit   Description
   =================================   ====   ======================================================================
   sFctCoI_ArbitrationResult_xau8             arbitration result for this FctCo channel
   sPDC_ActivationRequest_xdu8                flag for PDC activation request of the FunctionCoordinator
   sPDC_EstActivationRequest_xdu8             flag for estimator activation request of the FunctionCoordinator
   sPDC_State_xdu8                            state PullDriftCompensation (0 = Passive, 1 = Active, 2 = Hold, 3 = RampOut, 4 = RequestForActivation, 5 = HoldLongTerm)
   sPDC_RampedOut_xdu8                        flag for RampedOut of the FunctionCoordinator
   sPDC_RampedIn_xdu8                         flag for RampedIn of the FunctionCoordinator
   sPDC_PdcFeatureState_xdu8                  PullDriftCompensation interner FunctionCoordinator Status
   sPDC_EstFeatureState_xdu8                  PullDriftCompensation Estimator interner FunctionCoordinator Status
   =================================   ====   ======================================================================


Output Signals
--------------

=================================   ====   ==========================================
Signal Name                         Unit   Description
=================================   ====   ==========================================
mPDCI_MotorTorqueOffset_xds16       Nm     motortorque offset pulldriftcompensation
=================================   ====   ==========================================

.. only:: confidential
   
   ============================================   =====   ========================================================================================
   Signal Name                                    Unit    Description
   ============================================   =====   ========================================================================================
   sPDC_State_xdu8                                        state of PullDriftCompensation
   vPDC_YawVelocityFilt_xds16                     °/s     filtered yaw rate  
   mPDC_TorsionBarTorqueFilt_xds16                Nm      filtered torsion bar torque
   aPDC_VehicleAccelerationFilt_xds16             m/s^2   filtered vehicle acceleration
   tPDC_Timer4BigCrowningChangeDetection_xdu8     ms      timer for the detection of a big crowning change for changing the integration factor
   kPDC_SatRackForce_xds16                        N       requested PDC rack force offset
   fPDC_FunctionEnabled_xdb                               PDC is enabled (by coding/application)
   fPDC_StateIsActive_xdb                                 indicates whether PDC shall actively calculate and request a torque
   ============================================   =====   ========================================================================================

Detailed Description
--------------------
The component PullDriftCompensation compensates the pull drift on a straight road that is crowned. 
The PullDriftCompensation reduces the torque that the driver has to apply to keep the vehicle on a straight line on such roads.

The component PullDriftCompensation calculates a compensation rack force, which will be converted into a motortorque offset.
It detects that the vehicle drives straight ahead and that the vehicle is in the correct vehicle speed range by monitoring 
the signals YawVelocity, VehicleAcceleration, TorsionBarTorque, SteeringAngle and VehicleSpeed. 
If this is the case the compensation rack force is calculated out of the torsion bar torque with two integrators for short and long term.
The rackforce offset is converted into a motortorque offset.

.. only:: confidential

   State Transistions
   """"""""""""""""""
   PDC goes to state Active if the Functioncoordinator allows PDC to compensate and learn AND the following conditions are fulfilled for more than tPDC_MinTime4Active_XDU8:

     * All input signals valid
     * fPDC_FctSwitch_XDB == 1 XOR SY_PDC_FUNCT_ACTIVATED (coding switch)
     * Abs(vPDC_YawVelocityFilt_xds16) <= vPDC_MaxYawVelocity4Learn_XDU16
     * Abs(mPDC_TorsionBarTorqueFilt_xds16) <= mPDC_MaxTorsionBarTorque4Learn_XDU16
     * vApplI_AbsVehicleSpeedFilt_xdu16 >= vPDC_MinVehicleSpeed4Learn_XDU16
     * vApplI_AbsVehicleSpeedFilt_xdu16 <= vPDC_MaxVehicleSpeed4Learn_XDU16
     * wApplI_SteeringAngle_xdu16 <= wPDC_MaxSteeringAngle4Learn_XDU16
     * aPDC_VehicleAccelerationFilt_xdu16 <= aPDC_MaxVehicleAcceleration4Learn_XDU16

   PDC goes from state Active to state Hold if the FunctionCoordinator allows PDC to compensate but does not allow PDC to learn OR one of the following conditions is fulfilled 
   for more than tPDC_MinTime4Hold_XDU8:

      * Abs(vPDC_YawVelocityFilt_xds16) > vPDC_MaxYawVelocity4Learn_XDU16
      * Abs(mPDC_TorsionBarTorqueFilt_xds16) > mPDC_MaxTorsionBarTorque4Learn_XDU16
      * vApplI_AbsVehicleSpeedFilt_xdu16 > vPDC_MinVehicleSpeed4Learn_XDU16
      * vApplI_AbsVehicleSpeedFilt_xdu16 < vPDC_MaxVehicleSpeed4Learn_XDU16
      * wApplI_SteeringAngle_xdu16 < wPDC_MaxSteeringAngle4Learn_XDU16
      * aPDC_VehicleAccelerationFilt_xdu16 < aPDC_MaxVehicleAcceleration4Learn_XDU16
  
   PDC goes from state Active or Hold to state RampOut if the FunctionCoordinator does not allow to compensate OR one of the input signals is invalid.

   State machine
   """""""""""""

   .. image:: PullDriftCompensationstateMachine_blockDiagram.png

   .. image:: PullDriftCompensationstateMachine01_blockDiagram.png

   BigCrowning ChangeDetection
   """"""""""""""""""""""""""""

   .. image:: PullDriftCompensationBigCrowningDetect_blockDiagram.png


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=========================================================        ======   ====================   ===============================================================================================================================
Parameter Name                                                   Unit     Range                  Description
=========================================================        ======   ====================   ===============================================================================================================================
fPDC_FctSwitch_XDB                                                        0 .. 1                  enable PullDriftCompensation Fct. (XOR-logic with coding switch)
aPDC_MaxVehicleAcceleration4Learn_XDU16                          m/s^2    0 .. 30                 max long acceleration for calculating the compensation rack force
mPDC_DeadBandTorsionBarTorque_XDU16                              Nm       0 .. 1                  dead band for torsion bar torque
kPDC_MaxCompFrackLongTerm_XDU16                                  N        0 .. 700                max allowed long term compensation rack force
kPDC_MaxCompFrackShortTerm_XAU16                                 N        0 .. 700                max allowed short-term-compensation rack force while learning (input value: vehicle speed)
kPDC_MaxRateCompFrack_XDU16                                      N        1 .. 2800               max allowed rate for the compensation rack force
mPDC_MaxTorsionBarTorque4Learn_XDU16                             Nm       0 .. 25                 max torsion bar torque for calculating the compensation rack force
kPDC_MinCompFrack4BigCrowningChangeDetection_XDU16               N        0 .. 1400               min compensation rack force for the detection of a big crowning change for changing the integration factor
kPDC_MinCompFrack4CompFrackWrongDetection_XDU16                  N        0 .. 1400               min rack force for detecting a wrong compensation rack force
mPDC_MinTorsionBarTorque4BigCrowningChangeDetection_XDU16        Nm       0 .. 25                 min torsion bar torque for the detection of a big crowning change for changing the integration factor
mPDC_MinTorsionBarTorque4CompFrackWrongDetection_XDU16           Nm       0 .. 25                 min torsion bar torque for the detection of a wrong compensation rack force for ramping out of state Hold
mPDC_MinTorsionBarTorque4TurnDetection_XDU16                     Nm       0 .. 25                 min torsion bar torque for the detection of a turn for ramping out of state Hold
kPDC_RateCompFrackErrorRampOut_XDU16                             N/10ms   1 .. 1400               rate with which the compensation rack force is ramped down in case of error situation
kPDC_RateCompFrackNormalRampOut_XDU16                            N/10ms   1 .. 1400               rate with which the compensation rack force is ramped down in normal situation
tPDC_MinTime4Active_XDU8                                         ms       0 .. 2500               time for transition to state Active
tPDC_MinTime4BigCrowningChangeDetection_XDU8                     ms       0 .. 2500               time for the detection of a big crowning change for changing the integration factor
tPDC_MinTime4CompFrackWrongDetection_XDU16                       ms       0 .. 600000             time for the detection of a wrong compensation rack force for ramping out of state Hold 
tPDC_MinTime4Hold_XDU8                                           ms       0 .. 2500               time for transition to state hold
tPDC_MinTime4TurnDetection_XDU8                                  ms       0 .. 2500               time for the detection of a turn for ramping out of state Hold
vPDC_MaxVehicleSpeed4Learn_XDU16                                 km/h     0 .. 500                max vehicle speed for calculating the compensation torque
vPDC_MaxYawVelocity4Learn_XDU16                                  °/s      0 .. 150                yaw velocity for calculating the compensation torque
vPDC_MinVehicleSpeed4CompFrackWrongDetection_XDU16               km/h     0 .. 500                min vehicle speed for the detection of a wrong compensation rack force for ramping out of state Hold
vPDC_MinVehicleSpeed4Learn_XDU16                                 km/h     0 .. 500                min vehicle speed for calculating the compensation rack force
vPDC_MinVehicleSpeed4TurnDetection_XDU16                         km/h     0 .. 500                min vehicle speed for the detection of a turn for ramping out of state Hold
vPDC_MinYawVelocity4TurnDetection_XDU16                          °/s      0 .. 150                min yaw velocity for the detection of a turn for ramping out of state Hold
wPDC_MaxSteeringAngle4Learn_XDU16                                °        0 .. 100                max steering angle for calculating the compensation rack force
wPDC_MinSteeringAngle4TurnDetection_XDU16                        °        0 .. 100                min steering angle for the detection of a turn for ramping out of state Hold
vPDC_MaxYawVelocity4Learn_XAU16                                  °/s      0 .. 150                max allowed yaw velocity while learning (input value: vehicle speed)
xPDC_CompFrackFactor_XAU16                                                0 .. 1                  factor for the calculated compensation rack force (input value: vehicle speed)
xPDC_FastIntegrationFactorShortTerm_XDU16                                 0 .. 0.062499           fast filter factor of short-term-integrator (filter factor = sample rate / time constant);scaling changed:2^-22-->2^-20
xPDC_NormalIntegrationFactorShortTerm_XDU16                               0 .. 0.062499           normal filter factor of short-term-integrator (filter factor = sample rate / time constant);scaling changed:2^-22-->2^-20
xPDC_IntegrationFactorLongTerm_XDU16                                      0 .. 0.062499           filter factor of long-term-integrator (filter factor = sample rate / time constant);scaling changed:2^-22-->2^-20
xPDC_PT1FilterFactorTorsionBarTorque_XDU16                                0.0001 .. 1             filter factor of PT1-filter for torsion bar torque (filter factor = 2 * pi * cut-off frequency * sample rate)
xPDC_PT1FilterFactorVehicleAcceleration_XDU16                             0.0001 .. 1             filter factor of PT1-filter for vehicle acceleration (filter factor = 2 * pi * cut-off frequency * sample rate)                   
xPDC_PT1FilterFactorYawVelocity_XDU16                                     0.0001 .. 1             filter factor of PT1-filter for yaw velocity (filter factor = 2 * pi * cut-off frequency * sample rate)                  
kPDC_LimitCompRackForce_XDU16                                    N        0 .. 1400               max. allowed compensation rackforce
=========================================================        ======   ====================   ===============================================================================================================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   ======================================   =====   ==========   ==========================================================================================
   Parameter Name                           Unit    Range        Description
   ======================================   =====   ==========   ==========================================================================================
   xsyEngTorqueToRackForce_XDU16            N/Nm    1 .. 5000    factor from engine torque to rackforce (system parameter of steering gear)
   xsyRackForceToEngTorque_XDU16            Nm/N    0 .. 0.003   factor from rackforce to engine torque (system parameter of steering gear)
   xsyRatioEfficiency_XDU16                         0 .. 0.2     scaling factor for torsion bar torque to motor torque (system parameter of steering gear)
   ======================================   =====   ==========   ==========================================================================================



.. include:: PullDriftCompensation_CalMan_VT.irst

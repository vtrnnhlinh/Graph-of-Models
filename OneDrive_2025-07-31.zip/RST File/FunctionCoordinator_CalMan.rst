Function Coordinator
####################

Short Description
=================

The component FunctionCoordinator (FctCo) is a generic interface component for co-ordinating the customer specific functions/Addon functions (e.g. Automatic Parking Control).

Due to the high configurability, the component is split in two parts:
	#. Generic component (delivered by the product line), which is called "FunctionCoordinator"
	#. Configuration component (located in the customer project), which is called "FunctionCoordinatorConf"

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: FunctionCoordinator_blockDiagram.png


   Input Signals
   -------------

   ================================   ====   =========================================================
   Signal Name                        Unit   Description
   ================================   ====   =========================================================
   xApplI_TotalMotTorLim_xdu16               total reduction of torque reduction coordinator
   ================================   ====   =========================================================


   Output Signals
   --------------

   ==========================================   ======   ========================================================================================
   Signal Name                                  Unit     Description
   ==========================================   ======   ========================================================================================
   sFctCoI_ChannelStateArray_xau8               Status   Array of the actual channel states
   ==========================================   ======   ========================================================================================
   
   .. only:: confidential

   ==========================================   ====   ================================================================
   Signal Name [Measurement Signals]            Unit   Description
   ==========================================   ====   ================================================================
   fFctCo_MaxActCat1ChannelsAchieved_xdb		       Maximum number of active channel category 1 channels achieved
   sFctCo_DeratingStateArray_xau8			           Array of the actual derating channel states 0-> Off, 1-> ON
   ==========================================   ====   ================================================================


   Detailed Description
   --------------------

   Each feature (AddOn-component; e.g. AutomaticParkingControl, LaneKeeping, ...) shall implement one of the following patterns for the hand shake with the FunctionCoordinator.

   Simple Handshake:
   
   .. image:: FunctionCoordinator_HandShakePattern.png

   Complex Handshake:
   
   .. image:: FunctionCoordinator_FeatureStatemaschine.png
   

   Have a look to the unit documentation for the behaviour of the FunctionCoordinator.
   
   The Function coordinator handles only the activation requests from Addon/customer components. 
   Torque output from the Addon/Customer components shall be connected to respective summation points.
   
   The calibration parameters are not tunable via A2L. Only the values in the KGT file shall be configured. Have a look to your FunctionCoordinatorConf component
   in your CPR VOB.


   Calibration/Application Parameters
   ==================================

   ==========================================   =====   ========   ==================================================================================================================================================================
   Name                                         Unit    Range      Description
   ==========================================   =====   ========   ==================================================================================================================================================================
   zFctCo_MaxNumOfCat1Channel_XDU8                      0..3       Maximum number of active channels at channel category 1
   sFctCo_ChannelCategory_XAU8                          0..1       Channel category to limit the active channels. 0->internal channel, 1->external channel
   xFctCo_LockAtDeratingLimit_XAU16                     0..1       Array to lock individual channels if the EPS is derating
   sFctCo_AllowedToActivate_XAU8                        0..1       Matrix to configure which channels are allowed to activate dependent on the actual state of the other channels. row -> calling channel, column -> runnning channel
   sFctCo_ContinueIfActive_XAU8                         0..1       Matrix to configure which channels are allowed to continue dependent on the actual state of the other channels. row -> calling channel, column -> runnning channel
   sFctCo_ParallelRampingAllowed_XAU8                   0..1       Matrix to configure which channels are allowed to ramp parallel. row -> calling channel, column -> runnning channel
   ==========================================   =====   ========   ==================================================================================================================================================================


.. include:: FunctionCoordinator_CalMan_VT.irst

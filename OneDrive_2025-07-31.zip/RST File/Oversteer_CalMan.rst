Oversteer
##########

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================
The module Oversteer should optimise the steering feeling in the process of excess steering . The function is divided into three steps which can be used 
individually or in combination.

.. only:: confidential

   Block Diagram Overview   ======================
 
   .. image:: OverSteer_CalMan_BlockDiagram.png

   Block Diagram ReturnTorqueCalculation
   =====================================
  
   .. image:: Oversteer_blockDiagramMMOT.png


Input Signals
-------------

======================================     ======   =====================================================
Signal Name                                Unit     Description
======================================     ======   =====================================================
sApplI_SteeringAngleLinState_xdu8                   status steering angle from rotor angle not corrected
xApplI_DegreeOfOversteer_xdu16                      Degree of oversteer 
vApplI_SteeringAngleSpeed_xds16            °/s      speed of the steering angle
xApplI_GearSign_xds8                                steering gear sign
vVehSpI_AbsAvgVehSpd_xdu16                 km/h     abs.vehicle speed filtered
mApplI_AbsDriverTorque_xdu16               Nm       abs.calculated driver torque
aDsdI_LateralAcceleration_xdf32            m/s^2    lateral accelaration
vDsdI_YawVelocity_xdf32                    rad/s    yaw rate with  zero point adjustment
wApplI_PinionAngle_xds16                    °       pinion angle
xRWConI_RatioRackPos2WheelAngle_xdu16               ratio between rack postion and front wheel angle
fDsdI_BankedCurveDetected_xdb                       banked curve detection flag
======================================     ======   =====================================================

.. only:: confidential

   ======================================     ======   =====================================================
   Signal Name                                Unit     Description
   ======================================     ======   =====================================================
   sFctCoI_ArbitrationResult_xau8                      state of arbitration for this channel:0=Arbitration Not OK;1=Arbitration OK, channel active;2=Arbitration OK, channel passive
   ======================================     ======   =====================================================
   
Output Signals
--------------

======================================   ====   ==============================================
Signal Name                              Unit   Description
======================================   ====   ==============================================
mOvStI_MotorTorque_xds16                 Nm     motortorque of oversteer-function
xOvStI_ActiveReturnFuncFactor_xdu16             active return FuncFactor fading in oversteer
xOvStI_ActiveDampingFactor_xdu16                active damping factor during oversteer
======================================   ====   ==============================================


.. only:: confidential

   ======================================   ====   =============================================================
   Signal Name [Internal Use]                             Unit   Description
   ======================================   ====   =============================================================
   xOvSt_DegreeOfOversteerFilt_xdu16               filtered degree of oversteer [%/100]
   mOvSt_OscRetTorque_xds32                 Nm     return motortorque oversteer(part of sideSlipAngle velocity)
   mOvSt_LiftingForceComp_xds16             Nm     lifting force compensation motortorque
   vOvSt_SideSlipVelocityFilt_xds32         °/s    filtered side slip velocity
   xOvSt_RatioWheelAngle2SteerAngle_xdf32          ratio between front wheel angle and steering angle
   vOvSt_ReturnSpeed_xds16                  °/s    nominal return speed
   vOvSt_SpeedDiff_xds32                    °/s    difference desired/current steering angle speed
   fOvSt_Activate_xdb                              indicates whether Oversteer is allowed to apply torque
   ======================================   ====   =============================================================


Detailed Description
--------------------

To avoid early interventions of the oversteer function the degree of oversteer is first passed through a DeadZone.If a banked curve is detected the DeadZone is increased with an offset.
The degreeofoversteer is then filtered and passed through a rate down limiter to avoid a premature drop of the Oversteer function.

The nominal return speed has been calculated with a concept depending on the side slip velocity.

The next part calculates the requested motor torque.The requested motor torque consists of two elements, the return torque based on the return speed difference and lifting force compensation. 
They could be switched of separately for tuning purposes.

Return Torque calculation
"""""""""""""""""""""""""
The difference between nominal and current steering angle speed is multiplied with 0.001 to shift the vehicle speed dependent control amplification factor to a more convenient tuning 
range. Second an amplification factor is multiplied that depends on the current driver torque. So the return torque is blended out with an increasing driver torque.

LiftingForceCompensation Torque calculation
"""""""""""""""""""""""""""""""""""""""""""
In accompany with an increasing steering angle the lifting force acting on the front axle increases. Depending on the specific vehicle the usual motor torque may not sufficient to adjust
the required wheel angle. Therefore a motor torque offset is calculated to compensate the occuring lifting force. The motor torque offset is tuned via a characteristic curve (vehicle measurement)
and blended in dependency of the current yaw rate and pinion angle. The compensation is only activated if the sign of pinion angle and yaw velocity are different.The impact of the
lifting force can additionally be scaled in dependency of the vehicle speed.


Calibration/Application Parameters
==================================

=============================================    =====  ===============      =============================================================================================================
Parameter Name                                   Unit   Range                Description
=============================================    =====  ===============      =============================================================================================================
xOvSt_FilterFactOversteer_XDU16                         0.0009765 .. 1       filter factor  oversteer
xOvSt_RetSpeedOnSideSlipVelocityFact_XAU16              0 .. 2               factor steering speed depending on side slip velocity (->factor*steering_ratio)
xOvSt_BlendLiftingForceFact_XAU16                       0 .. 1               blend lifting force depending on yaw rate [°/s] when steering to end stop [%/100]
mOvSt_LiftingTorqueOnPinionAngle_XAU16                  0 .. 1               torque to compensate lifting force depending on pinion angle [Nm]
xOvSt_LiftingForceOnVelocityFact_XAU16                  0 .. 1               scale factor lifting force depending on vehicle speed [%/100]
xOvSt_VelDepCtrlAmpFact_XAF32                           0 .. 5               factor control amplification dependent on vehicle speed [x1000]
xOvSt_TbtDepCtrlAmpFact_XAU16                           0 .. 2               factor control amplification dependent on compensated torsionbar torque
xOvSt_FilterFactTBT_XDU16                               0.0009765 .. 1       filter factor torsion bar torque
xOvSt_FilterFactSAS_XDU16                               0.0009765 .. 1       filter factor steering angle speed
xOvSt_FilterFactSideSlipVel_XDU16                       0.0009765 .. 1       filter factor side slip velocity
fOvSt_UseOscRetTorque_XDB                               0 .. 1               activate return torque path (level 3)
fOvSt_UseLiftForceComp_XDB                              0 .. 1               enable lifting force compensation (level 2)
xOvSt_RampDownGradDepOnSideSlipVel_XAU16                0 .. 1               max neg gradient oversteer
xOvSt_ActRetFuncFactorDepOnDegOversteer_XAU16           0 .. 1               factor on Active Return depending on oversteer signal. Used for blending to Oversteer Active Return (1-x)
xOvSt_ActDampingFactorDepOnDegOversteer_XAU16           0 .. 1               factor on Active Damping depending on oversteer signal
=============================================    =====  ===============      =============================================================================================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   ======================================   =====   =======   ===================================================================
   Parameter Name                           Unit    Range     Description
   ======================================   =====   =======   ===================================================================
   xOvSt_ActivateOversteer_XDU8                     0 .. 1     activate oversteer
   mOvSt_LimitRetTorque_XDU16                       0 .. 1    limitation of return torque of oversteer
   xOvSt_BankedCurveDZOffset_XDU16                  0 .. 1    offset on deadzone degree of oversteer during banked curves [%/100]
   ======================================   =====   =======   ===================================================================

.. include:: Oversteer_CalMan_VT.irst

Automatic Parking Control Supp
##############################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component Automatic Parking Control Supp implements the 
managment of activation and deactivation the APC controller.


Block Diagram
=============

.. image:: AutomaticParkingControlSupp_CalMan_BlockDiagram.png


Input Signals
-------------

======================================   ======   =====================================================================================================================================================================================
Signal Name                              Unit     Description
======================================   ======   =====================================================================================================================================================================================
SY_APC_FUNCT_ACTIVATED                            AutomaticParkingControl functionality activated
lApplI_RackPosition_xds16                mm       rack position [mm]
mApplI_MaxRequiredMotorTorque_xdu16      Nm       max required motor torque
mApplI_TorsionBarTorque_xds16            Nm       HW LIB: torsion bar torque
sApplI_ApcState_xdu8                              APC: state from external ECU: 0=inactive, 1=request rack position control
sApplI_EcuState_xdu8                     Status    Ecu safe state 
sApplI_SteeringAngleLinState_xdu8                 state of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
sAutParkCtrlI_MakeSafeAndMonState_xdu8            Indicates whether the MakeSafe and MonitorSafe checks report OK (0) or if they have detected a problem (1) or if HandsOn was detected (2) of if invalid arbitration was detected (3).
vApplI_RackSpeed_xds16                   mm/s     rack speed [mm/s]
vVehSpI_AbsMaxSafeVehSpd_xdu16           km/h     Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
wApplI_ApcDesiredAngle_xds16             °        APC: desired steering angle
xApplI_GearSign_xds8                              sign of the steering gear
======================================   ======   =====================================================================================================================================================================================


Output Signals
--------------

=======================================   ====   =============================================================================================================================================================================================================================================================
Signal Name                               Unit   Description
=======================================   ====   =============================================================================================================================================================================================================================================================
lAutParkCtrlI_DesiredRackPosition_xds16   mm     desired rack position
sApplI_EpsApcState_xdu8                          APC: internal state for external ECU: 0=inactive, 1=EPS error, 2=available, 3=temporary error, 4=request rejected, 5=active rack position control, 6=ramp out
sAutParkCtrlI_Activate_xdu8                      Indicates whether APC shall actively calculate and request a torque (1 means active).
sAutParkCtrl_CancelState_xdu16                   flags on change EpsApcState to REQUEST_REJECTED: Bit0=EPS-Error, Bit1=SignalsInvalid, Bit2=ApcSignalsInvalid, Bit3=VehSpeedRangeInvalid, Bit4=RackPosRequestInvalid, Bit5=MakeSafeAndMonNotOk, Bit6=ArbitrationFailed, Bit7=HandsOn, Bit8=FctCoReturnedLocked
sAutParkCtrl_FctCoCtrlState_xdu8                 return value of the FunctionCoordinator
sAutParkCtrl_FeatureState_xdu8                   internal feature state for FunctionCoordinator
=======================================   ====   =============================================================================================================================================================================================================================================================


Detailed Description
--------------------

The component Automatic Parking Control Supp implements the 
managment of activation and deactivation the APC controller. 

It is responsible for the signal processing and conditioning of the external receivers, including the BUS signals
The APC state machine determines the EpsApcState for the external ECU and the ControlCommand for the check and main component.

Substitution of bus received APC state (sApplI_ApcState_xdu8) and APC desired angle(wApplI_ApcDesiredAngle_xds16) is available 
by setting the parameters sAutParkCtrl_SubState_XDU8 and wAutParkCtrl_DesiredAngle_XDS16 within the valid range. 


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

==================================   ====   ===========   =================================================================================
Parameter Name                       Unit   Range         Description
==================================   ====   ===========   =================================================================================
jsyInvSteeringRatio_XDU16                   900..3000     1/steeringratio * 2^15
lAutParkCtrl_MaxRackPosDiff_XDU16    mm     0..400        maximum allowed rack position difference of desired to real value
lAutParkCtrl_MaxRackPosGrad_XDU16    mm     0..400        maximum allowed gradient of desired rack position
sAutParkCtrl_SubState_XDU8                  0..255        Substitution of bus received APC state if value is within the valid range
vAutParkCtrl_MaxVehicleSpeed_XDU16   km/h   0..10         maximum allowed vehicle speed for enable rack position controller
wAutParkCtrl_DesiredAngle_XDS16      °      -1000..3276   Substitution of bus received APC desired angle if value is within the valid range
xsyGearRatioMot2Rack_XDU16           mm     1.9..5        scaling factor for servomotorrev to racktravel [mm]
==================================   ====   ===========   =================================================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: AutomaticParkingControlSupp_CalMan_VT.irst

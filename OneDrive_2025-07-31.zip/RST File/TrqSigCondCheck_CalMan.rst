﻿TorqueSignalConditioningCheck
#############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

 This function processes the extrapolated torque signal from TSC main and secure it to the safe limit.



Block Diagram
=============

.. only:: confidential

   .. image:: TrqSigCondCheck_Limitation.PNG
  
Input Signals
-------------
    ================================   =======   =========================================================================================================
    Signal Name                        Unit      Description
    ================================   =======   =========================================================================================================
    mTscI_ExtrapolTBT_xds16            Nm        extrapolated torsion bar torque
    ================================   =======   =========================================================================================================

.. only:: confidential

    ===========================================   =======   ===========================================================================================
    Signal Name [Internal]                        Unit      Description
    ===========================================   =======   ===========================================================================================
    sHwlWrapI_TorsionBarTorqueState_xde           -         Validity state of the torsion bar torque
    yHwlWrapI_TorsionBarStiffness_xdu16           NM / °    Torsion bar stiffness
    mHwlWrapI_TorsionBarTorque_xds16              Nm        Torsion bar torque
    vVehSpI_AbsMaxSafeVehSpd_xdu16                km/h      Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
    ===========================================   =======   ===========================================================================================

Output Signals
---------------

=================================   =====   =======================================
Signal Name                         Unit    Description
=================================   =====   =======================================
mApplI_TorsionBarTorque_xds16       Nm      Torsion bar torque
mApplI_AbsTorsionBarTorque_xdu16    Nm      absolute torsion bar torque
xApplI_TorsionBarStiffness_xdu16    NM/°    Torsion bar stiffness
=================================   =====   =======================================

.. only:: confidential


   Detailed Description
   --------------------

    The component TorqueSignalConditioningCheck implements the Limitation and Monitoring logic.
    Limitation will limit the extrapolated tbt coming from TSC main to the primary channel TBT with additional tolarence which depends on the MaxSafeVehicle Speed.
    Monitoring will be keep a check if the Limitation is not violating the limit. Once the Limit is exceeded for a timelimit only primary will be considered as final steer torque.

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

.. only:: confidential

    ========================================   =======   ==========   ==============================================================================================================================
    Parameter Name                             Unit      Range        Description
    ========================================   =======   ==========   ==============================================================================================================================
    mTsc_LimitationThreshold_XAU16             Nm        0..1         Maximum deviation allowed of the limited extrapolated average TBT signal from the trusted signal(refer diag 1.3)
    fTsc_DisableTscLimitation_XDU8             -         0..1         0-Limitation is enabled,1-Limitation is disabled.In S/w by default it should not be tuned to 1
    mTsc_IntegralDeviationThreshold_XDU16      Nm        0..60        set inline to the UAF time and Integral threshold of UAF(refer diag 1.1,1.2)
    tTsc_ErrorFilterTimeout_XDU16              ms        1..2500      backward and forward filtering time threshold to disabling the extrapolated torque limitation(refer diag 1.3)
    tTsc_ResetIntDevTime_XDU16                 ms        1..2500      thresold time limit to reset the integral deviation(refer diag 1.1,1.2)
    vTsc_SubstituteSpeed_XDU16                 km/h      0..500       If the vehicle speed is invalid, substitute speed is considered for TSC
    ========================================   =======   ==========   ==============================================================================================================================
   
TSC Safety Tuning
=================

LEAKY BUCKET INTEGRAL
=====================

When extrapolated averaged TBT crosses the Upper or Lower Limit, the deviation gets integrated and when it reaches the defined limit monitoring fails 

Diag 1.1
========

.. only:: confidential

  .. image:: IntegralDeviation.PNG

Diag 1.2
========

.. only:: confidential

  .. image:: LeakyBucketIntegral.PNG

Limit Deviation
===============

Diag 1.3
========

.. only:: confidential

  .. image:: LimitDeviationFFT.PNG
  

.. include:: TrqSigCondCheck_Main_CalMan_VT.irst
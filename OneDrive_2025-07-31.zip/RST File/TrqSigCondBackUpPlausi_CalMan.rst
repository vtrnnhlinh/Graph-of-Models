﻿TorqueSignalConditioningPlausi
##############################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component TorqueSignalConditioningPlausi disable the averaging in case of UV situation detected and primary alone is passed.
Once the UV situation recovered, the backup need to be monitored against the primary before enabling the averaging.  

Block Diagram
=============

.. only:: confidential

   .. image:: TrqSigCondPlausi_CalMan_BlockDiagram.png
  
Input Signals
-------------

.. only:: confidential

    ===========================================   =======   ===========================================================================================
    Signal Name [HwLib]                           Unit      Description
    ===========================================   =======   ===========================================================================================
    sHwlWrapI_TorsionBarTorqueState               -         state of the Torsion bar torque
    ===========================================   =======   ===========================================================================================


Output Signals
---------------

=================================   ====   =======================================
Signal Name                         Unit   Description
=================================   ====   =======================================
fTscI_DisAvgBackUpMonFail_xdb       -      Avg disabled due to Back check fail
=================================   ====   =======================================



   Detailed Description
   --------------------
   
   Check the Voltage is undervoltage or Undervoltage 
   Check the Primary and Backup Channel Torque are valid and without Error   
   Monitors the TBT value of exactly 0.0Nm for two consecutive cycles shall be interpreted as TBT undervoltage 
   In case of a zeroed TBT signal due to undervoltage, the TBT correlation check shall be disabled.   
   Calculate deviation between TBT level differs between Main and Backup ECU
   It will disable the averaging when undervoltage and Integral deviation greater than Maximum value   
   

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

.. only:: confidential

   ========================================   =======   ==========   =========================================================================================================================
   Parameter Name                             Unit      Range        Description
   ========================================   =======   ==========   =========================================================================================================================
   tTsc_UVRecoverWaitTimer_XDU8           	  ms        1..200       Wait time when avergaing should be enabled after recovering from UV. To make sure there is no fluctuation at the border
   ========================================   =======   ==========   =========================================================================================================================

.. include:: TrqSigCondBackUpPlausi_CalMan_VT.irst
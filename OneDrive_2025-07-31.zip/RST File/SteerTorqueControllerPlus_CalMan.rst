Steer Torque Controller Plus
############################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The steer torque controller plus ("RG3") calculates out of the nominal steering torque and the measured torsion bar torque a motor torque for the motor controller.
The component implements an easy understandable PID controller as a driver torque controller.


Block Diagram
=============

.. only:: confidential

   .. image:: SteerTorqueControllerPlus_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SteerTorqueControllerPlus_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

=================================   =====   ====================================================================================
Signal Name                         Unit    Description
=================================   =====   ====================================================================================
mApplI_TorsionBarTorque_xds16       Nm      HW LIB: torsion bar torque
mStFCI_NominalSteerTorque_xds16     Nm      Nominal Steer Torque for Controller
nApplI_RotorSpeed_xds16             1/min   unfiltered rotor speed
sApplI_SteeringAngleState_xdu8              state of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
vVehSpI_AbsAvgVehSpd_xdu16          km/h    Average vehicle speed. Goal: be as close to the actual speed over ground as possible
=================================   =====   ====================================================================================

.. only:: confidential

   =============================================   =====   =================================================
   Signal Name [for internal usage only]           Unit    Description
   =============================================   =====   =================================================
   lEndStopI_DistanceToEndstop_xds16               mm      distance from end stop in mm
   sFctCoI_ArbitrationResult_xau8                          state of arbitration for this channel:0=Arbitration Not OK;1=Arbitration OK, channel active;2=Arbitration OK, channel passive
   xApplI_GearSign_xds8                                    sign of the steering gear
   xMotTorLimI_WeightedIntegratedDeviation_xdu16           weighted integrated deviation of the motor torque
   zcrChatterPeriodsCount_xdu8                             counter of the chatter oscillations
   =============================================   =====   =================================================

Output Signals
--------------

===============================   ====   =================================================================
Signal Name                       Unit   Description
===============================   ====   =================================================================
mStTorCtrlPI_MotorTorque_xds16    Nm     Desired motor torque offset of Steer Torque Controller Plus (RG3)
===============================   ====   =================================================================

.. only:: confidential

   =============================================   =====   ===============================================
   Signal Name [for internal usage only]           Unit    Description
   =============================================   =====   ===============================================
   sStTorCtrlP_FctCoCtrlState_xdu8                         Return value of the FunctionCoordinator.
   sStTorCtrlP_FeatureState_xdu8                           Internal feature state for FunctionCoordinator.
   xStTorCtrlP_RampInOut_xdu16                             factor to ramp in and ramp out the motor torque
   =============================================   =====   ===============================================


Detailed Description
--------------------

On basis of the nominal steering torque and the measured torsion bar torque the steer torque controller plus calculates a motor torque. This motor torque is PID controlled and saturated to a minimum motor torque.Based on the valid inputs chatter periods, vehicle speed and
distance to EndStop the function calculates for each a motor torque. The minimum of these three motor torques is used to saturate the motor torque from the PID controller.
It is possible to deactivate the steer torque controller plus via the characteristic curve mStTorCtrlP_MMotMax_XAU16.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

============================================   ==========   ========   ========================================================
Parameter Name                                 Unit         Range      Description
============================================   ==========   ========   ========================================================
xStTorCtrlP_RampInGrad_XDU16                   1/10ms       0.001..1   gradient to ramp in the motor torque [factor / 10 ms]
xStTorCtrlP_RampOutGrad_XDU16                  1/10ms       0.001..1   gradient to ramp out the motor torque [factor / 10 ms]
xStTorCtrlP_PFactorTBTControl_XAU16                         0..1       P-part factor depending on absolute filtered rotor speed
xStTorCtrlP_IFactorTBTControl_XAU16                         0..1       I-part factor depending on absolute filtered rotor speed
xStTorCtrlP_DFactorTBTControl_XAU16                         0..10      D-part factor depending on absolute filtered rotor speed
mStTorCtrlP_MMotMax_XAU16                      Nm           0..10      maximum motor torque dependent on vehicle speed
============================================   ==========   ========   ========================================================

.. only:: confidential

   ============================================   ==========   ========   ==================================================================================
   Parameter Name [for internal usage only]       Unit         Range      Description
   ============================================   ==========   ========   ==================================================================================
   fStTorCtrlP_EnableIfEndstopIsInvalid_XDB       Bitanzeige   0..1       Enable controller in case of DistanceToEndstop is not available
   mStTorCtrlP_AlternativeMMotMaxDepOnVFZ_XDU16   Nm           0..10      substitute value of mStTorCtrlP_MMotMax_XAU16 in case of invalid vehicle speed
   mStTorCtrlP_ChatterMMotMax_XAU16               Nm           0..10      maximum motor torque dependent on chatter period counts
   mStTorCtrlP_DistanceToEndstopMMotMax_XAS16     Nm           0..10      maximum motor torque dependent on distance to EndStop
   msyAbsTorsionBarTorque_XDU16                   Nm           3..10      Absolute steering torque limit
   xStTorCtrlP_DPt1FactorTBTControl_XDU16                      0..1       D-part PT1 filter factor
   xStTorCtrlP_FactChatterMMotMax_XAU16                        0..1       factor maximum motor torque dependent on chatter period counts
   xStTorCtrlP_FactorDepOnWeightedInt_XAU16                    0..1       maximum allowed motor torque factor depending on WeightedIntegratedDeviation (MTL)
   xStTorCtrlP_PPt1FactorTBTControl_XDU16                      0..1       P-part PT1 filter factor
   ============================================   ==========   ========   ==================================================================================

.. include:: SteerTorqueControllerPlus_CalMan_VT.irst

Automatic Parking Control
#########################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component AutomaticParkingControl is used to control a desired rack position
for an automatic parking assistance module. Its output is a motor torque and
depending on application parameter a torsion bar torque and an active return factor.

The rack position controller is implemented as a cascaded PID control. The outer loop controller is the rack position controller
and the inner loop controller is the rack speed controller, which outputs is the motor torque offset.

.. only:: confidential

   Block Diagram
   =============

   .. image:: AutomaticParkingControl_CalMan_BlockDiagram.png


Input Signals
-------------

=======================================   ====   =====================================================================================
Signal Name                               Unit   Description
=======================================   ====   =====================================================================================
lApplI_RackPosition_xds16                 mm     rack position [mm]
lAutParkCtrlI_DesiredRackPosition_xds16   mm     desired rack position
mApplI_MaxRequiredMotorTorque_xdu16       Nm     max required motor torque
mApplI_TorsionBarTorque_xds16             Nm     HW LIB: torsion bar torque
sApplI_SteeringAngleLinState_xdu8                state of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
sAutParkCtrlI_Activate_xdu8                      Indicates whether APC shall actively calculate and request a torque (1 means active).
vVehSpI_AbsMaxSafeVehSpd_xdu16            km/h   Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd
vApplI_RackSpeed_xds16                    mm/s   rack speed [mm/s]
xApplI_GearSign_xds8                             sign of the steering gear
=======================================   ====   =====================================================================================


Output Signals
--------------

===========================================   ====   ==================================================================================================
Signal Name                                   Unit   Description
===========================================   ====   ==================================================================================================
lAutParkCtrl_DesiredRackPosFilt_xds16         mm     filtrated desired rack position
mAutParkCtrlI_DesMotTrqOffset4Check_xds16     Nm     Desired motor torque offset of Automatic Parking Control to be read by Check component only
mAutParkCtrlI_DesSteerTrqOffset4Check_xds16   Nm     Desired steering torque offset of Automatic Parking Control to be read by Check component only
vAutParkCtrl_DesiredRackSpeed_xds16           mm/s   desired rack speed incl. feed-forward controlled part
vAutParkCtrl_LimitedDesiredRackSpeed_xds16    mm/s   gradient limited desired rack speed
xAutParkCtrlI_DesActRetFuncFact4Check_xdu16          Desired ActiveReturn function factor of AutomaticParkingControl to be read by Check component only
===========================================   ====   ==================================================================================================


Detailed Description
--------------------

The input quantities for the controller are the desired rack position (lAutParkCtrlI_DesiredRackPosition_xds16), the rack position (lApplI_RackPosition_xds16),
the rack speed (vApplI_RackSpeed_xds16), the maximal allowed motor moment (mApplI_MaxRequiredMotorTorque_xdu16), the gear prefix for the left-right-steer (xApplI_GearSign_xds8),
the torsion bar torque (mApplI_TorsionBarTorque_xds16) and the steering angle state for the validity for the rack position (sApplI_SteeringAngleLinState_xdu8).

The controller will be enabled if all input signals are valid (including sApplI_SteeringAngleLinState_xdu8 which can be RawInit or ExactlyInit) and the state machine
sends a GO! via the interface sAutParkCtrlI_Activate_xdu8 (value 1).


Filtering of desired rack position (control variable)
"""""""""""""""""""""""""""""""""""""""""""""""""""""

The module is typically called cyclical in the 10 ms task. In case of performance issues (acoustic, quality of control, ...) you can move the controller
to a faster task (at compilation). Be aware that you have to adapt the calibration parameter tAutParkCtrl_CycleTimeController_XDU8.

Usually the performance problems come from a slower cycle of the control variable. You can increase the performance by enabling the filtering of the
control variable (fAutParkCtrl_EnableDesRackPosFilt_XDU8). In each case you have to check the correctness of the calibration parameter tAutParkCtrl_CycleTimeControlVariable_XDU8.

The filtration is implemented as an interpolation over the steps of the controller until a new value of the control variable will be received.

Example: The controller will be called each 10 ms and the control variable will be updated each 40 ms. In each cycle a quarter of the difference will be added to the DesiredRackPosition.

=====   ========================   ============================   ========================
Time    last DesiredRackPosition   received DesiredRackPosition   used DesiredRackPosition
=====   ========================   ============================   ========================
0 ms    100 mm                     200 mm                         125 mm
10 ms   125 mm                     200 mm                         150 mm
20 ms   150 mm                     200 mm                         175 mm
30 ms   175 mm                     200 mm                         200 mm
40 ms   200 mm                     400 mm                         250 mm
=====   ========================   ============================   ========================

The filtering is secured against a jitter of the received control variable. In case of a delayed value she last value will be hold. In case of a premature control variable
the new one will be interpolated.


Rack position controller (PID)
""""""""""""""""""""""""""""""

The rack position controller implements the outer loop of the cascaded PID controller. The deviation of control is: lAutParkCtrl_DesiredRackPosFilt - lApplI_RackPosition
The controller uses the self-explanatory calibration dates xAutParkCtrl_PositionPPart, xAutParkCtrl_PositionIPart, xAutParkCtrl_PositionDPart). The I-part is limited to
xAutParkCtrl_PositionIMax and will be reset in case of the controller is disabled.


Feed forward control
""""""""""""""""""""

As an additional servo control to the P-part in the position controller another servo control can be activated.

The feed forward control can be used to improve the quality of control.


Limitation of desired rack speed
""""""""""""""""""""""""""""""""

To improve the stability of the system the rack speed shall be limited in the maximum value and the gradient via the self-explanatory calibration data
vAutParkCtrl_MaxRackSpeed (result: vAutParkCtrl_DesiredRackSpeed) and vAutParkCtrl_MaxGradRackSpeed (result: vAutParkCtrl_LimitedDesiredRackSpeed).


Rack speed controller (PID)
"""""""""""""""""""""""""""

The rack speed controller implements the inner loop of the cascaded PID controller. The deviation of control is: vAutParkCtrl_LimitedDesiredRackSpeed - DeadZone(vApplI_RackSpeed)
The controller uses the self-explanatory calibration dates xAutParkCtrl_RackSpeedPPart, xAutParkCtrl_RackSpeedIPart, xAutParkCtrl_RackSpeedDPart). The I-part is limited to
xAutParkCtrl_RackSpeedIMax and will be reset in case of the controller is disabled.


Limitation
""""""""""

The output of the rack speed controller will be limited to the value of mApplI_MaxRequiredMotorTorque. This ensures that the driver can neutralize the APC's torque be steering
against the controller in case of a none-working Hands On Detection. The result is the variable mAutParkCtrlI_DesMotTrqOffset4Check_xds16.


Hands On Detection
""""""""""""""""""

To protect the driver's hands and especially the thumbs a Hands On Detection is implemented. If the absolut torsion bar torque (mApplI_AbsTorsionBarTorque)
is more than mAutParkCtrl_CheckHandsOnTorqLim for more than tAutParkCtrl_CheckHandsOnSwOffTime milliseconds, the request will be rejected.
The counter value is stored in zAutParkCtrl_HandsOnCounter.


Function coordination
"""""""""""""""""""""

If all conditions are given the request can be set to the FunctionCoordinator.
The feature internal state is given in sAutParkCtrl_FeatureState, the return value of the FunctionCoordinator in sAutParkCtrl_FctCoCtrlState.


Safety mechanism
""""""""""""""""

The safety mechanism depends only on the vehicle speed. The check component will set the torque to 0Nm
if vVehSpI_AbsMaxSafeVehSpd_xdu16 is more than preset vehicle speed limit.

Calibration/Application Parameters
==================================

==========================================  ====  =======   ====================================================================================================================
Parameter Name                              Unit  Range     Description
==========================================  ====  =======   ====================================================================================================================
fAutParkCtrl_EnableDesRackPosFilt_XDU8            0..1      enable filtering of the desired rack position due to an interpolation between the steps (macros shall be configured)
fAutParkCtrl_EnableFeedForward_XDU8               0..1      enable feed-forward controlled nominal rack position (formerly known as bypass)
mAutParkCtrl_DeadBandTBT_XDU16              Nm    0..6.5    maximum allowed steering torque offset (formerly known as dead band)
vAutParkCtrl_DeadBandRackSpeed_XDU16        mm/s  0..100    dead band threshold of nominal rack speed
vAutParkCtrl_MaxGradRackSpeed_XDU16         mm/s  0..10     maximum allowed desired rack speed gradient
vAutParkCtrl_MaxRackSpeed_XDU16             mm/s  0..200    maximum allowed desired rack speed
xAutParkCtrl_FeedForwardFiltFact_XDU16            0..1      filter factor feed-forward controlled nominal rack position
xAutParkCtrl_PositionDPart_XDF32                  0..100    D-part position controller
xAutParkCtrl_PositionIMax_XDF32                   0..2000   maximum allowed I-part position controller
xAutParkCtrl_PositionIPart_XDF32                  0..100    I-part position controller
xAutParkCtrl_PositionPPart_XDF32                  0..2000   P-part position controller
xAutParkCtrl_RackSpeedDPart_XDF32                 0..2      D-part speed controller
xAutParkCtrl_RackSpeedIMax_XDF32                  0..8      maximum allowed I-part speed controller
xAutParkCtrl_RackSpeedIPart_XDF32                 0..1      I-part speed controller
xAutParkCtrl_RackSpeedPPart_XDF32                 0..2      P-part speed controller
tAutParkCtrl_CycleTimeController_XDU8       ms    1..10     Cycle time of controller function call
tAutParkCtrl_CycleTimeControlVariable_XDU8  ms    10..250   Cycle time of updating control variable
==========================================  ====  =======   ====================================================================================================================


.. include:: AutomaticParkingControl_CalMan_VT.irst

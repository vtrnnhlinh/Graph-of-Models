PAMotTrqSum
###########

Short Description
=================
Infrastructure component to sum motor torques..

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: PAMotTrqSum_CalMan_BlockDiagram.png

   Input Signals
   -------------

   =================================   ======   ==================================================================================
   Signal Name                          Unit     Description
   =================================   ======   ==================================================================================
    matAssistantTorque_xds16            Nm       Assistance torque
    mSteerCtrlI_MotorTorque_xds16       Nm       totalized motor torque (D-part and D-offset)
    mInCoI_InertiaComp_xds16            Nm       motor torque offset from inertia compensation
    mStTorCtrlPI_MotorTorque_xds16      Nm       Desired motor torque offset of Steer Torque Controller Plus (RG3)
    mOCCI_MotorTorque_xds16             Nm       motor torque of OnCenterConnection
    mTrqSumI_TrqSumBeforeMTL_xds16      Nm       summation of all input motor torques of sub connector before MotorTorqueLimiter
    mApplI_HWLMaxUsableTorque_xdf32     Nm       MaxUsableTorque
   =================================   ======   ==================================================================================

   Output Signals
   --------------

   =================================   =========   =====================================================================
   Signal Name                         Unit        Description
   =================================   =========   =====================================================================
   mApplI_NominalMotorTorque_xds16      Nm         summation of all power assist motor torques including AddOnFunctions
   =================================   =========   =====================================================================


   Detailed Description
   --------------------

   The PAMotTrqSum component adds all the all power assist torque including AddOnFunctions.
   It limits the final summed torque to MaxUsableTorque i.e motor torque which can be provided by the system. Including the max. Boost Torque.
   This limitaion can be enabled or disbaled with the help of tuning switch.

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ==========================================   =====   ===========   ==================================================================
   Parameter Name                               Unit    Range         Description
   ==========================================   =====   ===========   ==================================================================
   fPAMotSum_EnableLimitation_XDU8                       0..1          Enabling Limitation with respect to UsableMotorTorque from HWlib
   matIMaxUsableOffset_XDU16                     Nm      0..2          MaxUsableMotorTorqueOffset from AssistanceV3
   ==========================================   =====   ===========   ==================================================================

.. include:: PAMotTrqSum_CalMan_VT.irst

Basic Steer Torque V2
#####################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The basic steer torque function determines the handwheel torque dependent on the rack force level. This function is responsible for a major part of the steering feeling.
The handwheel torque is generated in dependency upon the input quantities of rack force and vehicle speed. The vehicle speed is used to represent the servotronic 
effect that is well known from hydraulic systems. This means that the basic steering torque is increased for the same rack force when the vehicle speed increases.

Note that the vehicle speed part of calculation is done by BoostCurveInterpolation which is an input to BasicSteerTorque.


Block Diagram
=============

.. only:: confidential

   .. image:: BasicSteerTorqueV2_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: BasicSteerTorqueV2_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

====================================   ====   ===================================================================================================
Signal Name                            Unit   Description
====================================   ====   ===================================================================================================
kApplI_RackForceMerge_xds16            N      Merged rack force
kBciI_BSTCurveRackForceXAxis_xau16     N      x-node of interpolated and scaled basic steer torque characteristic curve (rack force)
mBciI_BSTCurveSteerTorqueYAxis_xau16   Nm     y-node of interpolated and scaled basic steer torque characteristic curve (nominal steering torque)
====================================   ====   ===================================================================================================

.. only:: confidential

   =====================================   ====   ===================================================================================================
   Signal Name [for internal usage only]   Unit   Description
   =====================================   ====   ===================================================================================================
   mTrqSumI_DisturbanceComp_xds16          Nm     totalized motor torque of disturbance compensation for RG3
   xApplI_GearSign_xds8                           sign of the steering gear
   =====================================   ====   ===================================================================================================

Output Signals
--------------

==============================   ====   =====================
Signal Name                      Unit   Description
==============================   ====   =====================
mBSTI_NominalSteerTorque_xds16   Nm     Basic Steering Torque
==============================   ====   =====================


Detailed Description
--------------------

The basic steering torque is applied in dependency upon the vehicle speed and the rack force. 
In general, the characteristic curves over the rack force should be applied with a monotone increase to realize the implicit 
return signal of crosswise acceleration, unevenness, the coefficient of friction and understeering. The greater the increase in 
the characteristic curve, the more distinct the implicit return signal. The application of the characteristic curves for the basic steering torque 
for small rack forces is to be approached in a sensitive way, because the torque increase from the center and the center feel could be very heavily influenced in this range.
The characteristic curves for the basic steering torque should be increased for increased vehicle speeds to imitate the well-known servotronic functionality.
It has been shown that a steeper increase in the characteristic curves for the basic steering torque is especially required for good steering and center feel 
when initiating a steering maneuver, and this for small rack forces. An application that is too steep can lead to controller instabilities when there are high rack force gradients.

Consider: The max. allowed gradient has to be less than::

   M = F * i
      M = max. mBST for the first node in Nm
      F = first node in x-direction in N
      i = pinion ration / (2000 * pi)

.. only:: confidential

   The SteerTorqueControllerPlus ("RG3") does need to know the influence of the RG1 motor torques. This is done by the DisturbanceCompensation.
   Otherwise the RG1 torque would interact as a disturbance.
   The RG1 motor torque sum will be converted into a rack force, PT1 filtered 

Calibration/Application Parameters
==================================

=====================================   ====   =======   ==========================================================
Parameter Name                          Unit   Range     Description
=====================================   ====   =======   ==========================================================
msyAbsTorsionBarTorque_XDU16            Nm     3..10     Absolute steering torque limit
xBST_RackForceScaleFact_XDU16                  0.2..2    rack force scaling factor
=====================================   ====   =======   ==========================================================

.. only:: confidential

   ========================================   ====   =======   ==========================================================
   Parameter Name [for internal usage only]   Unit   Range     Description
   ========================================   ====   =======   ==========================================================
   xBST_PT1FilterFactor_XDU16                        0..1      Filter factor PT1 for RG1-motor torques
   xsyNoEffDepEngTorqueToRackForce_XDU16      N/Nm   1..5000   Factor from Engine Torque to Rack Force without efficiency
   ========================================   ====   =======   ==========================================================


.. include:: BasicSteerTorqueV2_CalMan_VT.irst

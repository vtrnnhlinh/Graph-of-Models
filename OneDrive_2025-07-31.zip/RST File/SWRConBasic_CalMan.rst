﻿SWRConBasic
###################

Short Description
=================

The Component SWRConBaisc calculates the desired rack position based on steering wheel angle request from SWA and steering ratio.
If steering wheel angle request from SWA becomes invalid external steering angle is used for calculation.
The steering ratio is constant and does not depends on steering wheel angle, vechicle speed and charisma mode.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: SWRConBasic.PNG

   Input Signals
   -------------

   ======================================    ==========    ===========    =============================================================================================================
   Signal Name                               Unit          Range          Description
   ======================================    ==========    ===========    =============================================================================================================
   wEpsInI_ReqSteeringAngle_xds32            °             -1000..1000    Steering Wheel Angle Request
   wEpsInI_SteeringAngleExtern_xds16         °             -2048..2048    Extern Steering Wheel Angle
   sEpsInI_SteeringAngleExternState_xdu8     n.a           0..3           State of SteeringAngleExt; 0=OK; 1=INI; 2=ERR; 3=ERR_INI
   ======================================    ==========    ===========    =============================================================================================================

   Output Signals
   --------------

   =========================================================   =========   ==========   ===============================================================================================
   Signal Name                                                 Unit        Range        Description
   =========================================================   =========   ==========   ===============================================================================================
   lSWRConI_ReqRackPos_xds16                                   mm          -200..200    Rack Position calculated from Steering Wheel Angle Request
   sSWRConI_State_xdu8                                         n.a         0..3         Steering Wheel Rack Converter State bit 0 = eSAS ok, bit 1 = SA_SWA ok
   jSWRConI_RatioRackPos2StAng_xdu16                           (mm/rev)    40..230      Rack to Steering Wheel Angle Ratio (mm/rev)
   =========================================================   =========   ==========   ===============================================================================================

   Internal Signals
   ----------------

   =========================================================   ====   ==========   ===============================================================================================
   Signal Name                                                 Unit   Range        Description
   =========================================================   ====   ==========   ===============================================================================================
   lSWRCon_RequestedRackPosFilt_Buffer_xas16                   mm     -200..200    ring buffer for filtering the requested steering angle
   zSWRCon_ReqRackPosLastElement_xdu8                          n.a    0..20        last updated ring buffer element - requested steering angle
   =========================================================   ====   ==========   ===============================================================================================

   Calibration/Application Parameters
   ----------------------------------
   Internal calibration parameters.

   =================================================          ==========   =========     ======================================================================================
   Parameter Name                                             unit         Range         Description
   =================================================          ==========   =========     ======================================================================================
   jSWRCon_Rack2SteeringAngleRatio_XDU16                      (mm/rev)     40..230       Rack to Steering Wheel Angle Ratio
   zSWRCon_ReqRackPosNumElementsMovingAverage_XDU8            n.a          2..20         Number of elements for requested steering angle moving average calculation
                                                                                         (typically EPSInput_MessageCycletime/TaskTime)
   =================================================          ==========   =========     ======================================================================================

.. include:: SWRConBasic_CalMan_VT.irst

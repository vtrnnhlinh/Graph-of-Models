Active Inertia NST
##################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The Active Inertia Nst has to modify the Inertia of the steering system.
Depending on the torsion bar torque, the RotorAcceleration and the vehicle speed the current inertia torque is calculated.


Block Diagram
=============

.. only:: confidential

   .. image:: ActiveInertia_Nst_CalMan_BlockDiagram.png


Input Signals
-------------

==================================   =========        ===================================
Signal Name                          Unit             Description
==================================   =========        ===================================
mApplI_TorsionBarTorque_xdu16        Nm               HW LIB:Absolute torision bar torque
aApplI_RotAccelerationFilt_xds16     1/min/ms         filtered rotor acceleration
xApplI_GearSign_xds8                                  Steering angle gear sign
vApplI_AbsVehicleSpeedFilt_xdu16     km/h             Absolute vehcile speed :processed
==================================   =========        ===================================


Output Signals
--------------

=================================   ====   =======================================
Signal Name                         Unit   Description
=================================   ====   =======================================
mActInI_NominalSteerTorque_xds16    Nm     Nominal steer torque of active inertia
=================================   ====   =======================================


Detailed Description
--------------------
There are 3 possibilities to tune the function ActiveInertia_Nst:

  * Tuning of the vehicle speed dependent factor
  * Tuning of the torsion bar torque dependent factor
  * Tuning of the max inertia torque dependent on the vehicle speed


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=========================   =======   ==========    =====================================
Parameter Name              Unit      Range         Description
=========================   =======   ==========    =====================================
xActIn_InertiaTBT_XAU16                 0 .. 1      TorsionBarTorque dependent inertia
xActIn_InertiaFact_XAS16              -10 .. 10     VehcileSpeed dependent factor inertia
=========================   =======   ==========    =====================================

.. only:: confidential

   Internal calibration parameters.
   --------------------------------
   
   ========================  =====   =====   ======================
   Parameter Name            Unit    Range   Description
   ========================  =====   =====   ======================
   mActIn_InertiaMax_XAU16   Nm      0..10   maximum inertia torque
   ========================  =====   =====   ======================

.. include:: ActiveInertia_Nst_CalMan_VT.irst

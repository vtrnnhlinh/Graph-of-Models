Rack Position Synchronization TPO
#########################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component Rackposition Synchronization is part of the Steering Angle Calculation. It handles the synchronization of the internal steering angle to the external steering 
angle sensor (TPO). Therefore the validity of the external SAS is beeing checked amongst other conditions.
Depending on the configuration, a cyclic check and eventual resynchronization can be done or the external SAS can be ignored after a successful synchronization.

Output signals of the component are rotor angle offsets and state information to RackPositionMain.  

The tuning of the component can completely be done at the desk, but information is needed from 

* the mechanical system / department

* eventually the vehicle / sensors / column 

* the requirements of the customer / safety. 

To support the tuning there are Excel-sheets available, esp. the MechanicalDataSheet, stored in sharepoint.  .


Block Diagram
=============

.. image:: RpSync_docu.png

Sketch to give an overview over the calculation. Not all provided signals are visible.
 

Input Signals
-------------

==========================================   ======   ===============================================================================================================================
Signal Name                                  Unit     Description
==========================================   ======   ===============================================================================================================================
wHwlWrapI_PowerOnSteeringAngle_xdf32         rad SA   angle measured by the TPO sensor
sHwlWrapI_PowerOnSteeringAngleState_xde               state of TPO sensor
sRackPoI_StateRequest_xdu8                            requested state of statemachine: 0-nop, 1-init, 2-err_rev, 3-err_perm
sHwlWrapI_TorsionBarTorqueState_xde                   HW LIB: torsion bar torque state
mApplI_TorsionBarTorque_xds16                 Nm      extrapolated and averaged handwheel torque
sAhaDetI_AheadFromWheels_xdu8                         ahead detection from wheelspeeds
sAhaDetI_AheadFromYaw_xdu8                            ahead detection from vehicle speed, torsionbar torque and yawrate
nRackPoI_RotorSpeed_xds16                    rpm      rotor speed with GearSign included (--> related to column)
wRackPoI_RotorAngleRev_xdu16                 deg RA   singleturn RotorAngle, GearSign and belt tension compensated
wRackPoI_AccumRotorAngle_xds32               deg RA   accumulated RotorAngle, GearSign and belt tension compensated
sApplI_SteeringAngleState_xdu8                        state of steering angle and rackposition signals: 0-invalid, 1-raw init, 2-exactly init, 3-No-init
wApplI_PinionAngle_xds16                     deg SA   steering angle without lt-/st- correction, related to driver pinion
vApplI_AbsSteeringAngleSpeed_xdu16           deg /s   absolute value of steeringspeed
mApplI_LimitedMotorTorque_xds16              Nm       HW LIB: motor torque after limitation in HwLib 
zSSDetI_DetectionCounter_xdu16               
wEndStopI_LearnRightTPOAngle_xdu16           deg      TPO angle at the Right end of the rack
wEndStopI_LearnLeftTPOAngle_xdu16            deg      TPO angle at the Left end of the rack
uApplI_SupplyVoltage_xdu16                   Volt     Supply voltage level
vVehSpI_AbsMaxSafeVehSpd_xdu16               kmph     Safe vechicle speed
SY_PRODUCTION                                         Tells if system in PRODUCTION mode or not
==========================================   ======   ===============================================================================================================================


Output Signals
--------------

==========================================   ======   ===============================================================================================================================
Signal Name                                  Unit     Description
==========================================   ======   ===============================================================================================================================
sRpSyncI_RotAngInitState_xdu8                         synchronization state of internal steering angle
wRpSyncI_AccRotAngOffset_xds32               deg RA   synchronization offset of internal steering angle
sRpSyncI_Statemachine_xdu8                            state of synchronization statemachine
sRpSyncI_InitOffsetControl_xdu8                       flag to control the synchronization behavior ( 1-with ramping, 0-no ramping)
wRpSyncI_RotAngOffsetCalibNVR_xds16          deg RA   singleturn synchronization offset of internal steering angle; stored in NV-Ram
sRpSyncI_PlausiState_xdu8                             state of synchronization monitoring
sRpSyncI_SyncQualifier_xdu8                           qualifier for synchronization integrity: 0 - QM, 1 - ASIL-D
sRpSyncI_RefPosState_xdu8                             synchronization state for reference position (e.g. index), used in sw-endstop
wRpSyncI_RefPosOffset_xds16                  deg RA   Offset to calculate reference position (e.g. index), used in sw-endstop
==========================================   ======   ===============================================================================================================================


Detailed Description
--------------------

The RackPositionSynchronization is part of the Steering Angle Calculation. It handles the synchronization of the internal steering angle to the external steering 
angle sensor (TPO). The basic output is an offset to the accumulated rotor angle and the corresponding state information.
Depending on the configuration, a cyclic check and eventual resynchronization can be done or the external SAS (TPO) can be ignored after a successful synchronization.

The RackPositionSynchronization has its own monitoring function which handles the checks with relation to the external steering angle sensor.

* validity and range of TPO
* comparison intSA-TPO


The synchronization can occur in several steps with increasing accuracy:
  
* raw synchronization

  The internal steering angle can be only raw synchronized, if the environmental conditions do not allow an accurate measuring of the external steering angle or an 
  accurate alignment to the corresponding rotor angle. This can be caused by
  
  * high torsionbar torque or high motor torque --> torsion of the steering system
  * high steering speed --> old/delayed data from TPO cause a deviation to the current angle
  * wrong position of steering column, where the error can be high (in case of i-Var)
  
* exact synchronization

  If the environmental conditions are ok, the internal steering angle can be synchronized exactly. These conditions are:
  
  * low torsionbar torque or low motor torque --> low/no torsion of the steering system
  * low steering speed --> exact values from TPO
  * suitable position of steering column (in case of i-var near to center)
  
  When doing the exact synchronization the first time, the corresponding rotor position within 0�..360� is beeing stored in the NV-Ram.
  In subsequent ignition cycles this value can be used to align the newly calculated center position to this previously stored position. In doing so,
  we get a more reproducable steering angle and a better learning for long- and shortterm correction.
  
* resynchronization

  If the conditions are ok for an exact synchronization, and the already synchronized internal steering angle deviates from the TPO by more than a certain threshold, 
  a resynchronization the the TPO can be done (if activated in the ConfigFlags).  
  
After a reversible error was detected, a new synchronization can be done again. The number of synchronizations after errors within one ignition cycle can be limited,
to avoid a continuously toggling validity of the steering angle.
  


Configuration
"""""""""""""

To adapt the synchronization behavior of the steering angle to the requirements in the project there are configuration flags: 

sRpSync_ConfigFlagsSync_XDU16 (bitwise):

* 2 - enable usage of RPS Calib offset; so the 0� position is kept at the same rotor angle during subsequent ignition cycles

* 8 - if activated, the sync-check is passed only if at least one of the activated methods was successfull (compare towards straight, check steering range)

* 16 - sync-check method 1: verification of TPO alignment (sync-check, no 360� offset), done by wheelspeeds

* 32 - sync-check method 2: verification of TPO alignment (sync-check, no 360� offset), done by vehiclespeed, torsionbar torque and yawrate

* 64 - sync-check method 3: verification of TPO alignment (sync-check, no 360� offset), done by range check

* 256 - enable resynchronization of intSA to TPO on higher deviations at center


Safety mechanism and Configuration
""""""""""""""""""""""""""""""""""

There is a separate monitoring for the RackPosition Main and the Synchronization. It can be configured for each of them, which parts of the monitoring shall be used and what 
should be the reaction to a detected error. The details about sRackPo_ConfigFlagsMainPlausiActivErr_XDU16 can be found in the RackpositionMain docu, the mapping of 
sRpSync_ConfigFlagsSyncPlausiActivErr_XDU16 is as following:  (bitwise; configure, which parts of monitoring are used (bit=1) or not (bit=0))

* 1 - check if deviation from TPO to internal angle exceeds limit (~50�..90�)

* 2 - check if state of TPO is invalid (=1 or not =0)

* 4 - check if range of external reference signal (TPO) is exceeded

* 8 - check if Prim and Sec bit set along with valid bit for TPO


sRpSync_ConfigFlagsSyncPlausiReactErr_XDU16 (bitwise): configure the reaction to the different checks; go to permanent error (bit=1) or reversible error (bit=0)

* The Bitmask is the same as given above.
 
In case an error is detected and entered to the error memory / event manager, the corresponding errorcode / monitoring ID is: MONID_RACKPOS_TAS,MONID_RACKPOS_TPOCALIB and MONID_RACKPOS_RANGE

Some of the outputs of this component are stored redundantly for safety reasons.


Calibration/Application Parameters
==================================

============================================   =======   ===========   ====================================================================================================================
Parameters in calculation                      Unit      Range         Description
============================================   =======   ===========   ====================================================================================================================
please refere to the Mechanical data sheet
============================================   =======   ===========   ====================================================================================================================

============================================   =======   ===========   ====================================================================================================================
Parameters in monitoring                       Unit      Range         Description
============================================   =======   ===========   ====================================================================================================================
please refere to the Mechanical data sheet
============================================   =======   ===========   ====================================================================================================================


.. include:: RackPositionSynchronization_CalMan_VT.irst

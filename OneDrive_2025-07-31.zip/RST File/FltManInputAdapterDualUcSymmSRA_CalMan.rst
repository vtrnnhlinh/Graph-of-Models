FltManInputAdapterDualUcSymmSRA
###############################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The component evaluates the required input signals and maps the result to the output signal sFltManI_Events_xau8 which is further
evaluated by the fault management state handler functions.

.. only:: confidential

   Block Diagram
   =============

   .. image:: FltManInputAdapterDualUcSymmSRA_CalMan_BlockDiagram.png

Input Signals
-------------

=======================================   ====   ============================================================================================
Signal Name                               Unit   Description
=======================================   ====   ============================================================================================
sHwlWrapI_ActuatorState_xde                      HwLib Actuator State
sHwlWrapI_ChipsetSafetyFault_xde                 HwLib Chipset SafetyFault State
sHwlWrapI_RotorPositionState_xde                 HwLib Rotor Position State
sHwlWrapI_SystemVoltageState_xde                 HwLib System Voltage State
sHwlWrapI_PhaseCurrentState_xde                  HwLib Status of the phase current measurement
sHwlWrapI_PowerOnSteeringAngleState_xde          Status of the PowerOnSteeringAngleState
sSWRConI_State_xdu8                              Steering Wheel Rack Converter State
sApplI_SteeringAngleState_xdu8                   Steering Angle State
sOsMonI_ErrLvl_xdu8                              Error Level OsMon
sSwInCompI_ErrLvl_xdu8                           Error Level SwInComp
sAsmI_ErrLvl_xdu8                                Error Level ApplicationstateMachine
scpI_SwFault_ErrLvl_xdu8                         Error Level Compare
sMcdI_ErrLvl_xdu8                                Error Level Mcd
sTaskCtlSuppI_ErrLvl_xdu8                        Error Level TaskCtrlSupp
sOsMonI_ErrLvl_Red_xdu8                          Redundant signal for Error Level OsMon
sSwInCompI_ErrLvl_Red_xdu8                       Redundant signal for Error Level SwInComp
sAsmI_ErrLvl_Red_xdu8                            Redundant signal for Error Level ApplicationstateMachine
scpI_SwFault_ErrLvl_Red_xdu8                     Redundant signal for Error Level Compare
sMcdI_ErrLvl_Red_xdu8                            Redundant signal for Error Level Mcd
sTaskCtlSuppI_ErrLvl_Red_xdu8                    Redundant signal for Error Level TaskCtrlSupp
yIpcInI_IntConnAvailState_xdu8                   IPC PWMsync channel state
yIpcInI_IntConnCommState_xdu8                    IPC UART ,channel state
yIpcInI_RemoteFaultMode_xdu8                     CFM State of the remote channel
fIpcInI_RemoteStartUpConditions_xdu8             Startup conditions of the remote channel
sIpcI_RemoteDSMIntegrity_xdu8                    DSM integrity of the remote channel
fIpcI_RemoteIpcErrorConfirmed_xdu8               IPC error state of the remote channel
=======================================   ====   ============================================================================================

Output Signals
--------------

===================================   ====   ================================================================================================
Signal Name                           Unit   Description
===================================   ====   ================================================================================================
sFltManI_Events_xau8                         An array of error events
sFltManI_DSMIntegrity_xdu8                   Local DSM integrity transmitted to the remote channel
fFltManI_IpcErrorConfirmed_ldB               Local IPC error state transmitted to the remote channel
fFltManI_StartUpConditions_ldU8              Local Startup conditions transmitted to the remote channel
===================================   ====   ================================================================================================

Detailed Description
--------------------
The FltManInputAdapterDualUcSymmSRA component maps HardwareLib signals such as ActuatorState, ChipsetSafetyFault, RotorPositionState, BoardTempState, TorsionBarTorqueState,
SystemVoltageState and Sw Error Levels into an event list based on the actual status of the signals.


.. include:: FltManInputAdapterDualUcSymmSRA_CalMan_VT.irst

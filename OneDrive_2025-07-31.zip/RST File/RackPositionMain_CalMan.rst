Rackposition Main SRA
#########################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component Rackposition Main provides the pinion angle and rackposition values needed for other functionalities. The cyclic calculation of the relative changes
is based on the accumulated rotor angle comming from the HwLib. The absolute value at startup is taken from an reference signal, such as an external steering angle sensor,
an index sensor or an torque-angle-sensor (TAS). The synchronization to this reference is handled in the component RackPositionSynchronization.

Output signals of the component are pinion angle and rackpositions and also the corresponding  rackspeed. There are additional
state signals which need to be evaluated to get the validity and integrity of the outputs.

The tuning of the component can completely be done at the desk, but information is needed from

* the mechanical system / department

* eventually the vehicle / sensors / column

* the requirements of the customer / safety.

To support the tuning there are Excel-sheets available.


Block Diagram
=============

.. only:: confidential

	.. image:: RackPosMain_CalMan_BlockDiagram.png

Sketch to give an overview over the calculation. Not all provided signals are visible.


Input Signals
-------------

==========================================   ====   ===============================================================================================================================
Signal Name                                  Unit   Description
==========================================   ====   ===============================================================================================================================
sHwlWrapI_AbsRotbasedAngleDetails_xdu32             HW LIB: detailed state of accumulated rotor angle
sHwlWrapI_AbsRotbasedAngleState_xde                 HW LIB: state of accumulated rotor angle
wApplI_RotorPosition_xds32                   °RA    HW LIB: integrated, compensated rotorposition
xApplI_GearSign_xds8                                HW LIB: Sign between steering column and motor shaft
nrsI_IntRotorSpeed_xds16                     rpm    Hw lib rotor speed converted from Rad/sec => 1/min 
sApplI_EcuState_xdu8                                ECU state
sRpSyncI_PinionAngleRawState_xdu8                   Qualification state of input signals for synchronization based on TPO
sRpSyncI_InitOffsetControl_xdu8                     Flag to control the synchronization behavior ( 1-with ramping, 0-no ramping)
wRpSyncI_AccRotAngOffset_xds32               °RA    Complete offset to accumulated rotor angle from hw-lib(deviation between ARA and TAS angle)
sRpSyncI_RotAngInitState_xdu8                       Synchronization state of internal steering angle
sRpSyncI_PlausiState_xdu8                           state of synchronization monitoring: 0-Plausi off, 1-active+ok, 2-GoErrRev, 3-GoErrPerm
wRpSyncI_PinionAngleRaw_xds16                °SA    Compensated pinion angle based on TPO
==========================================   ====   ===============================================================================================================================

.. only:: confidential

   =======================   ====   =============================================
   Signal Name               Unit   Description
   =======================   ====   =============================================
   sOsMonI_ErrLvl_xdu8              Error Level OsMon
   sOsMonI_ErrLvl_Red_xdu8          Error Level redundant OsMon
   sMcdI_ErrLvl_xdu8                Error level MCDataIntegrity
   sMcdI_ErrLvl_Red_xdu8            Error level redundant MCDataIntegrity
   =======================   ====   =============================================


Output Signals
--------------

==========================================   ====   ===============================================================================================================================
Signal Name                                  Unit   Description
==========================================   ====   ===============================================================================================================================
sRackPoI_PlausiState_xdu8                           output of main monitoring: 0-Plausi off, 1-active+ok, 2-GoErrRev, 3-GoErrPerm
sRackPoI_StateRequest_xdu8                          requested state of statemachine: 0-nop, 1-init, 2-err_rev, 3-err_perm
sRackPoI_RotAngQualifier_xdu8                       qualifier of accum. rotor angle: 0-noinit, 1-err_perm, 2-err_rev, 3-rel, 4-estim, 8-raw_noChk, 9-raw, 10-exact_noChk, 11-exact
nRackPoI_RotorSpeed_xds16                    rpm    rotor speed with GearSign included (--> related to column)
wRackPoI_AccumRotorAngle_xds32               °RA    accumulated RotorAngle, GearSign and belt tension compensated
wRackPoI_RotorAngleRamped_xds32              °RA    RotorAngle ramped with the fine offset (ARA is compensated with TAS deviation)
yRackPoI_DiagData                                   Diagnostic error entry

**PinionAngle Interfaces:**
wApplI_PinionAngle_xds16                     °SA    steering angle without lt-/st- correction, related to driver pinion
wApplI_AbsPinionAngle_xdu16                  °SA    absolute value of PinionAngle
sApplI_SteeringAngleLinState_xdu8                   state of steering angle and rackposition signals: 0-invalid, 1-raw init, 2-exactly init
sApplI_SteeringAngleState_xdu8                      state of steering angle and rackposition signals: 0-error, 1-raw init, 2-exactly init, 3-not init, 4-Fallback

**RackPosition Interfaces:**
lApplI_RackPosition_xds16                    mm     rackposition without lt-/st- correction
lApplI_AbsRackPosition_xdu16                 mm     absolute value of RackPosition
sApplI_RackPosQualifier_xdu8                        RotorAngle Offset Qualifier for Rotor angle Ramping

**RackSpeed Interfaces:**
vApplI_RackSpeed_xds16                       mm/s   gradient of rackposition
vApplI_AbsRackSpeed_xdu16                    mm/s   absolute value of rackspeed
==========================================   ====   ===============================================================================================================================

Measurement Signals
=======================

   ===================================   =======   ====================================================================
   Signal Name                           Unit      Description
   ===================================   =======   ====================================================================
   sRackPo_ErrorDetected_xdu16                     Plausi error detected value based on error configuration  
   sRackPo_QualifierStatemachine_xdu8              Statemachine for RackPosQualifier: 1-invalid, 2-goErrPerm, 3-goErrRev, 4-valid
   zRackPo_ErrorCycleCounter_xdu8                  Counter of new sync cycles after error is detected
   tRackPo_MainErrorFilterTimer_xdu16              Redundant filtertime for RackPosMain plausi errors
   ===================================   =======   ====================================================================


Detailed Description
--------------------

The RackPositionMain calulates the Pinion angle and rackposition values.
Therefore the accumulated rotor angle from the HwLib is corrected by an offset from the synchronization component and then multiplied by the GearRatios.

Incase of accumulated rotor angle from HwLib is not valid the pinion angle and RackPosition is calculated from TPO angle (validations for TPO angle is done at RackPositionSync component)

Calculation of Acuumulator Rotor Angle:
==========================================
Accumulated rotor angle is calulated as gear sign compensated rotor position(HW Lib) if 
   * The rotor based info from HwLib is ok
   * Rotor  Position signal is valid
   * OS Mon and MCD error levels are not set
   
Calculation of Rack Speed:
============================
Rack Speed is calculated from the GearSign compensated Rotor Speed by mutiplying the RotorSpeed to the Gear
conversion 1/min => 1/sec: 1/60 = 273/2^14 if 

   * OS Mon and MCD error levels are not set
   * Rotor speed signal is valid
   
Calculation of Rack Position:
================================
RackPosition calculation is done only if ARA is valid and synchronization state is Exact is Raw. 

Rotor anlge ramped is used to calculate the RackPosition if ARA is valid

Rotor Angle Ramped = Accumulated rotor angle - RotorAngleOffset_Cur. (RackPositionSynchronization component) 
A new offset value is always accepted (change detected) and the ramping is done depending on the InitOffsetControl 
(0 - no ramping, 1 - use ramping) 

If ARA is invalid and RackPositionSyncrohinzation state is already synced then  TPO angle will be used for the calculation of RackPosition which is Fallback state

In case of ECU state is error then RackPosition value will be set to SNA and no fallback is possible

Configuration
==================

To adapt the calculation of the rackposition to the requirements of the project there are configuration flags:

sRackPo_ConfigFlagsMain_XDU16 (bitwise):

* 1 - default values are set to 0 or to SNA (bit=1)

* 8 - set the pinion angle and rackposition to invalid (permanently) if the System is in the ErrorMode (bit=1) or continue providing the signals (bit=0)

* 16 - Used to enable fallback in case of ARA invalid, this increases higher availability(bit 4)


Safety mechanism and Configuration
====================================

There is a monitoring for the RackPosition calculation. There can be configured, which parts of the monitoring shall be used and what should be the reaction to a detected error.

sRackPo_ConfigFlagsMainPlausiActivErr_XDU16 (bitwise): configure, which parts of monitoring are used (bit=1) or not (bit=0)

* 2 - check deviation between calculated rackposition and accumulated rotor angle from HW-Lib

* 4 - range check of pinion angle and rackposition

* 8 - not used currently

* 16 - compare gradient of rotor angle ramped and rotor angle from HW-Lib

* 32 - not used currently

sRackPo_ConfigFlagsMainPlausiReactErr_XDU16 (bitwise): configure the reaction to the different checks; go to permanent error (bit=1) or reversible error (bit=0)

* The Bitmask is the same as given above.

In case an error is detected and entered to the error memory / event manager, the corresponding errorcode / monitoring ID is: MONID_RACKPOS_MAIN

Many of the outputs of the component are stored redundantly.


Calibration/Application Parameters
==================================

============================================   =======   ===========   ====================================================================================================================
Parameters in calculation                      Unit      Range         Description
============================================   =======   ===========   ====================================================================================================================
wRackPoI_MaxAbsRotbasedAngle_XDF32             rad       500 .. 750    maximum possible accumulated rotor angle
wRackPo_OffsetReductionStep_XDU16              °RA       0 .. 720      reduction step/ms of possible rotor position offset while initialization, scaled in 1/16 deg. rotor
sRackPo_ConfigFlagsMain_XDU16                            0 .. 65535    Configuration of component behaviour; see above or in Unit Design
============================================   =======   ===========   ====================================================================================================================

============================================   =======   ===========   ====================================================================================================================
Parameters in monitoring                       Unit      Range         Description
============================================   =======   ===========   ====================================================================================================================
wRackPo_SteeringAngleMax_XDU16                 °SA       0 .. 800      maximum range of steering angle for verification
lRackPo_RackPositionMax_XDU16                  mm        0 .. 200      maximum range of racktravel for verification
tRackPo_ErrorFilterTimeout_XDU16               ms        0 .. 100      max. filtertime for redundant filtering of general RackPos-errors
vRackPo_RotAngGradientDiffMax_XDU16            °RA/ms    0 .. 2.5      maximum gradient deviation between rotor shaft and calculated rackposition (relevant while resynchronization)
wRackPo_GradErrReductStep_XDU16                °RA/ms    0 .. 2850     Reduction step of error integral from gradient monitoring, if gradients are ok
wRackPo_GradErrLimit_XDU16                     °RA       0 .. 500      error integral from gradient monitoring in terms of rotor angle
wRackPo_RackposToleranceRA_XDU16               °RA       0 .. 30000    Threshold for deviation of calculated rackposition and accumulated rotorangle from HwLib
sRackPo_ConfigFlagsMainPlausiActivErr_XDU16              0 .. 65535    Configuration of monitoring behavior; see above or in Unit Design
sRackPo_ConfigFlagsMainPlausiReactErr_XDU16              0 .. 65535    Configuration of monitoring behavior; see above or in Unit Design
zRackPo_ErrorCounterLimit_XDU8                           0 .. 250      Threshold for Resync-Cycles after detected errors to switch to permanent error
============================================   =======   ===========   ====================================================================================================================


.. only:: confidential

   Internal calibration parameters
   -------------------------------

   ================================= =====   ==================  ========================
   System Parameter Name             Unit    Range               Description
   ================================= =====   ==================  ========================
   jsyInvSteeringRatio_XDU16                 900 .. 3000         1/steeringratio * 2^15
   xsyGearRatioMot2Rack_XDU16         mm     2 .. 5              scaling factor for servomotorrev to racktravel [mm]
   ================================= =====   ==================  ========================

.. include:: RackPositionMain_CalMan_VT.irst

Blocked Steering Detection
##########################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
==================
The component BlockedSteeringDetection calculates a motor torque offset and sends it to the EPS motor, if a suspicion of a blocked steering is detected.
Depending on the vehicle speed it is checked if the rotor is moving, if no change is detected the suspicion of a blocked steering is present. 
To confirm this, a motor torque will be added and the rotor position is checked again. If still there are no changes in the rotor position then a blocked steering confirmed.

.. only:: confidential

   Block Diagram
   ==============

   .. image:: BlockedSteeringDetection_CalMan_BlockDiagram.png
   

Input Signals
-------------

================================   ====   =======================================================================================
Signal Name                        Unit   Description
================================   ====   =======================================================================================
vVehSpI_AbsAvgVehSpd_xdu16         km/h    Average vehicle speed. Goal: be as close to the actual speed over ground as possible
wApplI_RotorPosition_xds32         °       Integrated, compensated rotorposition
mApplI_TorsionBarTorque_xds16      Nm      torsion bar torque
wApplI_SteeringAngle_xds16         °       corrected steering angle
fBsdI_ActivationFlag_xdb                   Activation Signal from BSD Supp component.
================================   ====   =======================================================================================

.. only:: confidential

   ===============================   ====   ====================================================================================================
   Signal Name                       Unit   Description
   ===============================   ====   ====================================================================================================
   fBsdI_MonSafeOk_xdb                      Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   xApplI_GearSign_xds8                     Sign of the steering gear
   sApplI_SteeringAngleState_xdu8           steering angle status(0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit)
   xApplI_TotalMotTorLim_xdu16       Nm     total reduction of torque reduction coordinator
   ===============================   ====   ====================================================================================================

Output Signals
--------------

===================================   ====   ======================================================================================
Signal Name                           Unit   Description
===================================   ====   ======================================================================================
sBsdI_BlockedSteeringDetection_xdu8          states Blocked Steering Detection 0: not blocked 1: suspicion of blocking 2: blocked 
===================================   ====   ======================================================================================

.. only:: confidential
   
   =======================================   =====   ===========================================================
   Signal Name                               Unit    Description
   =======================================   =====   ===========================================================
   zBsd_BlockSuspicionCnt_xdu16                      Bsd Counter when BSD enters SUSPICION state of statemachine
   zBsd_BlockDetectedCnt_xdu16                       Bsd Counter when Blocked steering is detected  
   mBsdI_MotorTorque4Check_xds16             Nm      Blocked steering detection motor torque offset for check
   =======================================   =====   ===========================================================
   
Detailed Description
--------------------

As seen in the block diagram, it is checked if the condition for blocked steering are fulfilled. If fulfilled, a motor torque offset is calculated.
The calculated motor torque offset is ramped linearly and is added to the summation point after Motor Torque Limiter.

.. only:: confidential

   A motor torque offset is calculates gradient internally  based on VibrationTorque and tBsd_MaxTimeTorqueActive.This torque is then multiplied with
   Gear Sign and TBT direction to get final BSD_torque, which is sent to check component.


Calibration/Application Parameters
==================================

======================================   =====   ===========    =====================================
Parameter Name                           Unit    Range          Description
======================================   =====   ===========    =====================================
wBsd_MinRotPosChange_XDU16               °       0..50          min change for rotor position
mBsd_VibrationTorque_XDU16               Nm      0..1           motor torque offset
======================================   =====   ===========    =====================================

.. only:: confidential

   Internal calibration parameters
   -------------------------------
   ========================================   =====   =======   ================================================
   Parameter Name                             Unit    Range     Description
   ========================================   =====   =======   ================================================
   tBsd_MaxTimeTorqueActive_XDU16             ms      2..6000   maximum time torque active
   vBsd_VehicleSpeedForBSDActivation_XDU16    km/h    0..100    minimum vehicle speed to start detection
   tBsd_StateCycletimer_XDU8                          1..100    cycle time of server call
   zBsd_MaxRampUpCycles_XDU8                          1..3      Max Torque generation cycles for rotor move
   mBsd_TBTDeadband_XDU16                      Nm     0..0.5    Deadband for Direction Change for Motor Torque
   wBsd_SteeringAngleLimit_XDU16               °      0..600    steering angle border for endstop     
   vBsd_LowVehSpeed_XDU16                      km/h   0..10     Low vehicle speed for stopping TorqueGeneration   
   ========================================   =====   =======   ================================================

   .. image:: TorqueDiagram.png

.. include:: BlockedSteeringDetection_CalMan_VT.irst

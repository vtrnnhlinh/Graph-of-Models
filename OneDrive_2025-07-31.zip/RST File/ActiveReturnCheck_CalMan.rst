Active Return Check
###################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The function ActiveReturnCheck is responsible for the saturation and monitoring of the motor torque calculated by ActiveReturn.
In case of a deviation detected by the implemented monitoring functionality
the output torque is set to zero.


Block Diagram
=============

.. image:: ActiveReturnCheck_CalMan_BlockDiagram.png


Input Signals
-------------

==============================   ====   ==========================================================================
Signal Name                      Unit   Description
==============================   ====   ==========================================================================
mActRetI_MotTrq4Check_xds16      Nm     motor torque of active return component for check
mApplI_TorsionBarTorque_xds16    Nm     torsion bar torque
vVehSpI_AbsMaxSafeVehSpd_xdu16   km/h   Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd
wApplI_SteeringAngle_xds16       deg    corrected steering angle
==============================   ====   ==========================================================================


Output Signals
--------------

=============================   ====   =======================================================================================
Signal Name                     Unit   Description
=============================   ====   =======================================================================================
mActRetI_MotorTorque_xds16      Nm     motor torque of active return functionality
=============================   ====   =======================================================================================

.. only:: confidential

=============================   ====   ====================================================================================================
Signal Name                     Unit   Description
=============================   ====   ====================================================================================================
fActRet_Disable_xdb             -      in case of a detected error during the monitoring the active return is disabled
mActRet_MotTrqSaturated_xds16   Nm     saturated motor torque
=============================   ====   ====================================================================================================


Detailed Description
--------------------

The Active Return Check provides the safety limitation of the calculated motor torque depending
on vehicle speed and steering angle. In case of an invalid input signal the substituion value
is choosen to take the lowest value of the appropriate curve.

Usually the torque from Active Return and all the other part torques (Power Assist, etc.) are tuned in a way that together they provide
a proper steering feeling. In case functionality Motor Torque Limiter ramps out MTL_MotorTorque, the torques from functionality Active Return,
Software Endstop and Loss of Assist Prevention remain as the only torques and must also be controllable in this situation.
Independently from Software Endstop this is ensured as follows:
If functionality Active Return exclusively sets its torque, a very high torque towards the center position maybe induced
which is not controllable by the driver. This induced torque leads to a Steering Torque ~8Nm. If such a high Steering Torque is recognized,
Active Return is immediately switched off.

The runnable Saturation implements the safety limitation. The Monitoring implementation is to ensure the ASIL integrity.



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

==============================================   ====   =====   ==============================================================
Parameter Name                                   Unit   Range   Description
==============================================   ====   =====   ==============================================================
mActRet_MaxMotorTorqueDepOnVehSpeed_XAU16        Nm     0..3    limitation of active return torque depending on vehicle speed
mActRet_MaxMotorTorqueDepOnSteeringAngle_XAU16   Nm     0..3    limitation of active return torque depending on steering angle
mActRet_MaxTBT4ShutDown_XDU8                     Nm     0..15   maximum torsion bar torque to allow active return torque
==============================================   ====   =====   ==============================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: ActiveReturnCheck_CalMan_VT.irst

EndStopHsdSupp
##############

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

Set the flag for enabling the undervoltage offset in EndStopHsd based on a calibration value.


Block Diagram
=============

.. image:: EndStopHsdSupp_BlockDiagram.png


Input Signals
-------------

none


Output Signals
--------------

======================================   ====   ====================================================
Signal Name                              Unit   Description
======================================   ====   ====================================================
fEndStopHsdI_EnableUndervoltOffset_xdb          Enable undervolt offset in EndStopHsd if set to true
======================================   ====   ====================================================


Detailed Description
--------------------

This component can be modified by customer projects to implement advanced logic for enabling the undervolt offset.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

======================================   ====   =====   ====================================================
Parameter Name                           Unit   Range   Description
======================================   ====   =====   ====================================================
fEndStopHsd_EnableUndervoltOffset_XDU8          0..1    Enable undervolt offset in EndStopHsd if set to true
======================================   ====   =====   ====================================================


.. include:: EndStopHsdSupp_CalMan_VT.irst

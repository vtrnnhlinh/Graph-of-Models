Shimmy Compensation
#########################

.. only:: confidential

   .. warning:: The following Description is for internal use only and is rated as **confidential**!
        
        Parts of this confidential description are in the "official" version as well. Have a look in the NON Confidential Manual for a comparison.
        
Short Description
=================

The ShimmyCompensation function is a model based function and compensates steering wheel rotational vibrations caused by e.g. wheel imbalances. 
Shimmy-Disturbances are always sinusoidal and have the same frequency as the wheel frequency. They will be detected in TorsionBar-Torque (TBT) signal.
With the information of the identified model of the steering gear (transfer function EPS-Motor to TorsionBar)
and the information of the TBT, a Motor-Torque is calculated to compensate/reduce the steering wheel rotational vibrations.

For every vehicle and software combination it is necessary to use the right shimmy parameters, which have to be identified by measurement or simulation!


Block Diagram
=============

.. only:: not confidential

   .. image:: ShimmyCompensation_BlockDiagReduced.png
 
.. only:: confidential
   
   .. image:: ShimmyCompensation_BlockDiagConfidential.png
   

Input Signals
-------------

=================================   =====   ========================================================================================
Name                                Unit    Description
=================================   =====   ========================================================================================
mApplI_TorsionBarTorque_xds16       Nm      HW LIB: torsion bar torque
qApplI_WheelFrequencyFL_xds16       Hz      Turning-Frequency of the tire front left
qApplI_WheelFrequencyFR_xds16       Hz      Turning-Frequency of the tire front right
sApplI_SteeringAngleLinState_xdu8           State of steering angle (rackposition: 0-invalid, 1-raw, 2-exactly)
wApplI_AbsSteeringAngle_xdu16       °       Abs. corrected steering angle
vVehSpI_AbsAvgVehSpd_xdu16          km/h    Abs. processed vehicle speed
=================================   =====   ========================================================================================


.. only:: confidential
   
   ======================   =====   =========================================================================================
   Name                     Unit    Description
   ======================   =====   =========================================================================================
   xApplI_GearSign_xds8             Sign of the steering gear
   fShimmyI_MonSafeOk_xdb           Indicates whether the monitor checks report OK (1) or if they have detected a problem (0)
   ======================   =====   =========================================================================================
   

Output Signals
--------------

================================   ====   ==========================================
Signal Name                        Unit   Description
================================   ====   ==========================================
mShimmyI_MotorTorque4Check_xds16   Nm     Motor torque Shimmy Compensation for check
================================   ====   ==========================================


.. only:: confidential
   
   ====================   =====   =============
   Signal Name            Unit    Description
   ====================   =====   =============
   sShimmyI_Status_xdu8           Shimmy status
   ====================   =====   =============

   
Detailed Description
====================

**Signal Processing:**

To only see the Shimmy-relevant fraction the input value *mApplI_TorsionBarTorque_xds16* is band-pass filtered. The mid-frequency of this filter is
*qShimmy_Freq_xdu16*, which is calculated as the mean value of *qApplI_WheelFrequencyFR_xds16* and *qApplI_WheelFrequencyFL_xds16*.	
The output of the band-pass filter is *mShimmy_EstimatorIn_xds16* and the activation of ShimmyCompensation minimizes the amplitude of this signal.


.. image:: BandPass_TBT_toFilteredTBT.png


.. only:: confidential
   
   
   The bandwidth of the band-pass filter has to be switched depending on the change-rate of the shimmy frequency.
   
   If the vehicle is driven with constant speed or accelerating, the bandwidth of the filter is small (*qShimmy_BandWidth_xdu16* = *xShimmy_DampingFactorNorm_XDU16*).
   
   If the vehicle is decelerating with a negative value lower than *aShimmy_VehDecelTh_XDS16* for longer than *tShimmy_VehDecelTime_XDU8* (strong breaking)
   the BandWidth is changed from *xShimmy_DampingFactorNorm_XDU16* to *xShimmy_DampingFactorDecel_XDU16*.
   

**Shimmy Identification:**

ShimmyCompensation is allowed to be active if the following conditions are TRUE:

  * ShimmyCompensation functionality is enabled by customer coding ( *SY_SHIMMY_FUNCT_ACTIVATED* =1, *SY_SHIMMYCUSTOMER_FUNCT_ACTIVATED* =1)
  * *sApplI_SteeringAngleLinState_xdu8* is RAW or EXACTLY
  * Wheel frequencies are valid
  * *qShimmy_FrequencyMin_XDU8* < *qShimmy_Freq_xdu16* < *qShimmy_FrequencyMax_XDU8*
  * *xShimmy_CompensationActive_XDU8* = 1
  * *wApplI_AbsSteeringAngle_xdu16* < *wShimmy_SteeringAngleMax_XDU16*
  * *mShimmy_AmpTBT_xdu16* is passed the preconditions
  

If Shimmy is allowed to be active, it will follow the following states:

 * 1 = ALLOWED
 * 2 = ACTIVE_WAIT
 * 3 = ACTIVE_RAMPIN
 * 4 = ACTIVE
 * 5 = ACTIVE_HYSTER
 * 6 = ACTIVE_RAMPOUT
 
If all conditions are fulfilled, Shimmy is in ALLOWED state but is not providing a Compensation Torque, then Shimmy will go to ACTIVE_WAIT if *mShimmy_AmpTBT_xdu16* > *xShimmy_CompBoundary_XDU16* and waits 
for a defined time (still no torque), then Shimmy will go to ACTIVE_RAMPIN and ramp the Compensation Torque with *xShimmy_RampFactor_XDU16*. After ramping, Shimmy is in ACTIVE and 
performs with 100%. If the Shimmy-Disturbance getting lower (*mShimmy_AmpTBT_xdu16* < *xShimmy_CompHyster_XDU16*) Shimmy will go to ACTIVE_HYSTER
and waits for a defined time until it will go to ACTIVE_RAMPOUT with *xShimmy_RampFactor_XDU16*.

ShimmyCompensation related torque is arbitrated within the framework of SW functionalities. The arbitration procedure is handled through the activation request towards to the Function Coordnator.
 

.. only:: confidential
   
   Also the following conditions must be met that Shimmy is allowed:
    
    * fShimmyI_MonSafeOk_xdb = 0 (Flag from ShimmyCompensationCheck that the OutputTorque is ok)
    * *mShimmy_AmpTBT_xdu16* < *mShimmy_AmpTBTMax_XDU16* (*mShimmy_AmpTBT_xdu16* is the Amplitude of *mShimmy_EstimatorIn_xds16*)
    
   If an error is detected (*fShimmyI_MonSafeOk_xdb* = 1, OR *mShimmy_AmpTBT_xdu16* > *mShimmy_AmpTBTMax_XDU16* for longer 
   than *tShimmy_CountMaxAmp_XDU16*) the state is changed instantly to 7 and Shimmy-Output is ZERO.


   For detailed information about the transitions see StatusMachine in the next figure: 

   .. image:: ShimmyComp_CalMan_StateMachine.png

**Shimmy Compensation:**

Based on *mShimmy_EstimatorIn_xds16* and the internal model of the steering gear a CompensationTorque is calculated which is used 
to reduce the Shimmy-Disturbance in the TorsionBarTorque. 

If ShimmyCompensation is getting active the Shimmy-Disturbance torque in the TBT is reduced. To avoid that, the function is getting inactive because 
of a low Shimmy-Disturbance in the TBT, the torque which is already compensated is included and added to *mShimmy_EstimatorIn_xds16*.

.. only:: not confidential

   *mShimmy_MotorTorque_xds16* is calculated by multiply the CompensationTorque with a Factor from
   Status-Activation. 
   
   
.. only:: confidential
   
   The CompensationTorque is multiplied with the Ramp-Factor *xShimmy_LimFactor_xds16* and the vehicle speed dependent value *xShimmy_MotorTorqueFactor_XAU16*. 
   To have the correct sign of the torque, it is also multiplied with *xApplI_GearSign_xds8*. The result of this multiplication is *mShimmy_MotorTorque4Check_xds16* which is sent to ShimmyCompensationCheck.
   
   The internal used *mShimmy_FeedbackValue_xds16* is calculated by multiplying *mShimmy_MotorTorque4Check_xds16* with *xShimmy_FeedbackFactor_XDS16*.
   

Influence to the identified model of the steering gear and therefore to the Shimmy-Parameters                                                                            
---------------------------------------------------------------------------------------------
Tuning of the following components will influence the transfer function of the steering gear (motor to torsion bar). 
Therefore the Shimmy Performance will be influenced or even the function will be instable.  If unstable, a new identification has to be performed.

* Basic Steer Torque
* RG3 – Tuning (PID-values)             
* Active Inertia        
* D-fraction      
* Active Return and Active Damping (if the function is active at “small steering angle”)
* FOC


Calibration/Application Parameters
==================================
  
.. note: the following list of parameters will always be visible in the generated documentation!
  
===============================   ====   ===========   ======================================================
Parameter                         Unit   Range         Description
===============================   ====   ===========   ======================================================
qShimmy_FrequencyMin_XDU8         Hz     8..15         Min frequency for the Shimmy Compensation
qShimmy_FrequencyMax_XDU8         Hz     10..25        Max frequency for the Shimmy Compensation
wShimmy_SteeringAngleMax_XDU16    °      0..60         Max Steering angle for the Shimmy Compensation
xShimmy_CompensationActive_XDU8          0..1          Shimmy Compensation active
xShimmy_CompBoundary_XDU16               0..1          Border of compensation
xShimmy_CompHyster_XDU16                 0..1          Border of compensation for hysteresis
xShimmy_RampFactor_XDU16                 0..1          Ramp factor motor torque
tShimmy_Time_XDU16                ms     0.001..0.01   Tasklist time
===============================   ====   ===========   ======================================================
  
.. only:: confidential
   
   ================================   ====   ===========   =========================================================================================
   Parameter                          Unit   Range         Description                                                                           
   ================================   ====   ===========   =========================================================================================
   xShimmy_DampingFactorNorm_XDU16    Hz     0..5          Damping factor during acceleration or steady state vehicle speed 
   xShimmy_DampingFactorDecel_XDU16   Hz     0..5          Damping factor During Decceleration Only
   xShimmy_FeedbackFactor_XDS16              -0.9..0.9     Feedback factor
   xShimmy_MotorTorqueFactor_XAU16           0..1          Vehicle speed dependent factor for motor torque factor
   xShimmy_TorqFactor_XDU16                  0.5..10       Shimmy torque factor
   mShimmy_MaxMotorTorq_XDU16         Nm     0..0.5        Max. motor torque
   mShimmy_AmpTBTMax_XDU16            Nm     0..5          Max. allowed Shimmy-TBT for Shimmy active 
   tShimmy_CountMaxAmp_XDU16          ms     0..5          Delay time for deactivation of the compensation, if the TBT is higher than AmpTBTMax
   xShimmy_CountOn_XDU16              ms     0..1          Delay status machine switch on
   xShimmy_CountOff_XDU16             ms     0..20         Delay status machine hysteresis
   xShimmy_WheelAccelBeta_XDU16              0..0.99       Filter factor of PT1-filter for acceleration (filter factor = 1-EXP(-W2*Ts))
   xShimmy_WheelAccelPole_XDU16              1..100        Filter cutoff frequency (cutoff frequency W2 = 2*pi*Fc)
   aShimmy_VehDecelTh_XDS16                  -32..0        Vehicle deceleration Threshold
   tShimmy_VehDecelTime_XDU8          s      0..15         Vehicle deceleration Time Threshold
   xShimmy_PinionSign_XDS8                   -1..1         Pinion sign for the addition sign change of Shimmy motor torque
   xShimmy_ShimmyActFactor_XDS16             -2..2         Shimmy active (Shimmy Pos = 1; Shimmy Neg = -1; Shimmy Pas =0)
   xShimmy_A11_XDU16                         0..3.9        Shimmy parameter for the internal steering gear model
   xShimmy_A12_XDS16                         -3.9..3.9     Shimmy parameter for the internal steering gear model
   xShimmy_A13_XDU16                         0..3          Shimmy parameter for the internal steering gear model
   xShimmy_A21_XDS16                         -4..4         Shimmy parameter for the internal steering gear model
   xShimmy_A22L_XAU16                        0..30         Shimmy parameter for the internal steering gear model
   xShimmy_A23_XDS16                         -30..30       Shimmy parameter for the internal steering gear model
   xShimmy_A31_XDS16                         -4..4         Shimmy parameter for the internal steering gear model
   xShimmy_B11_XDS16                         -0.99..0.99   Shimmy parameter for the internal steering gear model
   xShimmy_B21L_XAU16                        0..63         Shimmy parameter for the internal steering gear model
   xShimmy_B22L_XAU16                        0..63         Shimmy parameter for the internal steering gear model
   xShimmy_B23L_XAU16                        0..63         Shimmy parameter for the internal steering gear model
   xShimmy_B24L_XAU16                        0..63         Shimmy parameter for the internal steering gear model
   xShimmy_B25L_XAU16                        0..63         Shimmy parameter for the internal steering gear model
   xShimmy_C1_XDS16                          -0.99..0.99   Shimmy parameter for the internal steering gear model
   ================================   ====   ===========   =========================================================================================

.. include:: ShimmyCompensationV2_CalMan_VT.irst

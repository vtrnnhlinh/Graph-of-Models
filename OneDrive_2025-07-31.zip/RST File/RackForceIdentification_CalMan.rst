RackForce Identification
########################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

.. warning:: This function shall not be used for anything else than RFMC identification manneuvers!

This functionality generates a sine wave of given amplitude (steering angle) and frequency (Hz). It then
uses the AutomaticParkingControl function to make the SCU steer the sine wave.


Input Signals
-------------

================================   ====   ============================================
Signal Name                        Unit   Description
================================   ====   ============================================
wApplI_SteeringAngle               °      The SteeringAngle
lRackPoI_LTCorrRackPos             mm     LongTerm correction value of RackPosition
mApplI_AbsTorsionBarTorque_xdu16   Nm     TorsionBarTorque absolute value
mAutParkCtrlI_MotorTorque4Check    Nm     MotorTorque calculated by AutParkCtrl main
================================   ====   ============================================

Output Signals
--------------

=================================   ====   ====================================================================================
Signal Name                         Unit   Description
=================================   ====   ====================================================================================
fRackForId_HandsOn                   -     Hands on Flag
wRackForId_PendularAngle            °      Calculated sine angle
lRackForId_PendularRackPos          mm     Sine angle 2 RackPos (eliminated LTCorr influence)
sRackForId_State                     -     State of the function
xRackForId_Waves                     -     Number of periods already calculated
lAutParkCtrlI_DesiredRackPosition   mm     Desired RackPos of AutParkCtrl (equals PendularRackPos in normal operation)
mApplI_NominalMotorTorque           Nm     Nominal motor torque which gets set after calling AutParkCtrl
mAutParkCtrlI_MotorTorque4Check     Nm     Output torque of AutParkCtrl
sAutParkCtrlI_ControlCommand         -     Control command for AutParkCtrl
=================================   ====   ====================================================================================

Detailed Description
--------------------

Sine wave gets calculated with help of geometric numeric series (triangle wave into Taylor series calculation with octant selection &
predefined fractions of pi as taylor parameters).
Then it gets converted to a desired rack position, where the longterm correction value gets zeroed out.
Then AutParkCtrl is being called and after that the resulting motortorque gets directly written to the nominal motortorque.



Calibration/Application Parameters
==================================

======================================   =====   ==========   ================================================================
Parameter Name                           Unit    Range      Description
======================================   =====   ==========   ================================================================
fRackForId_ActivateFunction_XDU8          -       0 ..    1   Activates the sine generator if all conditions are met
mRackForId_HandsOnLimit_XDU16            Nm       0 ..   10   Max allowed tbt while the function is active (safety!)
qRackForId_SinSweepFrequency_XDU16       Hz       0 ..    2   Frequency of the sine wave
tRackForId_HandsOnTime_XDU16             ms       0 ..  500   Time at which max tbt is allowed before HandsOn Flag gets set
tRackForId_Lead_XDU16                    ms       0 .. 2000   Time constant of the lead part
tRackForId_StepTime_XDU8                  s       0 .. 0.25   Steptime of the function (normally 1ms / 0.001s)
wRackForId_SinSweepAmplitude_XDU16        °       0 ..  100   Amplitude of sine wave in SteeringAngle
xRackForId_InitFreq_XDU16                 -       0 ..   10   Factor for the frequency of the pre-wave
xRackForId_InitOffsetAmp_XDU16            °       0 ..   10   Offset of the initial amplitude
zRackForId_PendularWaves_XDU8             -       0 ..   50   Number of periods that are getting calculated in one go
======================================   =====   ==========   ================================================================

.. warning:: If the MTL will stop the function from working, please set the `sMotTorLim_LimiterSwitch_XDU8` to 1 to deactivate the MTL.

.. include:: TemplateComponent_CalMan_VT.irst

.. only:: not confidential

   Smart Cruise Interface | Primary Controller
   ###########################################

   This is a controller within the SCruise Steer Torque functionality to increase the nominal steer torque performace.


.. only:: confidential

   Smart Cruise Interface | Primary Controller
   ###########################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   Nominal steer torque primary controller to increase nominal steer torque performance. The primary combines to different controller types

   * **Legacy Controller** - to ensure the well known behaviour
   * **Performances Controller** - to reach higher customers performance requirements


   Legacy Controller
   =================

   Set the paramter ``sSCruise_RackSpdCtrlrType_XDU8=0`` to ensure the well known controller behaviour with PID-controller.

   Block Diagram
   -------------

   .. image:: SCruisePrimCtrlr_CalMan_BlockDiagram_LegacyCtrlr.png


   Input Signals
   -------------

   =================================   ======   ==================================================================================================================================
   Signal Name                         Unit     Description
   =================================   ======   ==================================================================================================================================
   lSCruiseI_RackPosnDelta_xds16       mm       This signal is the Rack Position Deviation which was between filtered Rack Position and Nominal Rack Position (after InputLimiter)
   mSCruiseI_TorsBarTrq_xds16          Nm       Validity checked TorsionBarTorque for SCruise
   sSCruiseI_Mod_xdu8                  Status   SmartCruise operation mode: 0=Inactive, 1=HandsOn, 2=HandsFree, 3=Parking, 4=HandsOnInc
   sSCruiseI_State_xdu8                Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   sSCruiseLimrI_State_xdu8            Status   Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   vSCruiseI_AbsAvgVehSpd_xdu16        km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   xSCruiseI_HandsOnFadrFac_xdu16               Fading factor from a HandsOn (1) mode to non-HandsOn modes (0)
   xSCruiseI_StfnFac_xdu16                      Rate limited stiffness factor for SCruise, received from bus
   =================================   ======   ==================================================================================================================================


   Output Signals
   --------------

   ==================================   ====   =================================================================================
   Signal Name                          Unit   Description
   ==================================   ====   =================================================================================
   mSCruiseI_NomPrimCtrlrTrq_xds16      Nm     Nominal Steer Torque to increase Rack Position accuracy in the primary controller
   mSCruise_DPrimTrq_xds16              Nm     D-Part of the primary controller
   mSCruise_IPrimMaxTrq_xdu16           Nm     Maximum of I-Part of the primary controller or total torque for
   mSCruise_IPrimTrq_xds16              Nm     I-Part of the primary controller
   mSCruise_PPrimTrq_xds32              Nm     P-Part of the primary controller
   ==================================   ====   =================================================================================


   Detailed Description
   --------------------

   This component provides a PID-controller controlling the rack position deviation to increase the performance in a hands-free use case.
   In a hands-on use case the torque output is limited depending on the applied torsion bar torque ``xSCruise_PrimCtrlrTrqFac_XAU16``.
   There are two different modes, the "HandsOn/HandsFree mode" and the "parking mode" on which different performance characteristic curves are used.

   Moreover the torque output is also limited by a mode dependant stiffness factor.
   The mode is differentiated between "HandsOn modes" and "non HandsOn modes" using the interface ``xSCruiseI_HandsOnFadrFac_xdu16``.

   Resulting Controller Behaviour
   ------------------------------

   This is a resulting demonstration from the `simulation model`_ with the legacy controller.

   .. _legacy controller: https://sourcecode02.de.bosch.com/projects/ASMPAPP/repos/asmp-dev/browse/comps_repo/SCruiseTorqueController/fc_test/IntegrationModel_SCI

   .. image:: LegacyCtrlrRackPosn.png
   .. image:: LegacyCtrlrRackSpd.png

   Calibration/Application Parameters
   ----------------------------------

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ==========================================   ==========   ============   ================================================================================================================
   Parameter Name                               Unit         Range          Description
   ==========================================   ==========   ============   ================================================================================================================
   mSCruise_IPartPrimMaxTrq_XAU16               Nm           0..12          Legacy PrimCtrlr: I-Part max. torque (dependent on vehicle speed)
   sSCruise_RackSpdCtrlrType_XDU8                            0..1           0: legacy PrimCtrlr, 1: Prim as cascaded RackSpdCtrlr
   xSCruise_DPartPrimCtrlr_XAU16                             0..30          D-Part Gain of Primary Controller
   xSCruise_DPrimFiltFac_XDU8                                0.0078125..1   low-pass filter factor for DPrim
   xSCruise_IPartPrimCtrlr_XAU16                             0..1           I-Part Gain of Primary Controller
   xSCruise_PPartPrimCtrlr_XAU16                             0..10          P-Part Gain of Primary Controller
   xSCruise_PrimCtrlrTrqFacPrkg_XAU16                        0..1           factor to the maximum steering torque of primary controller in parking mode
   xSCruise_PrimCtrlrTrqFac_XAU16                            0..1           factor to the maximum steering torque of primary controller in HandOn and Handsfree mode
   xSCruise_PrimStfnFacX_XAU16                               0..1           PrimCtrl: Modify StiffnessFactor (X-axis) depending on itself for PID-parts in all modes
   xSCruise_PrimStfnFacHndFreeY_XAU16                        0..1           PrimCtrl: Modify StiffnessFactor (Y-axis) depending on itself for PID-parts in HandFree modes
   xSCruise_PrimStfnFacHndOnY_XAU16                          0..1           PrimCtrl: Modify StiffnessFactor (Y-axis) depending on itself for PID-parts in HandOn modes
   ==========================================   ==========   ============   ================================================================================================================



   Performance Controller
   ======================

   Set the paramter ``sSCruise_RackSpdCtrlrType_XDU8=1`` to enable the Performance Controller which is a cascaded rack position /-speed controller.

   Block Diagram
   -------------

   .. image:: SCruisePrimCtrlr_CalMan_BlockDiagram_PerfCtrlr.png


   Input Signals
   -------------

   =================================   ======   ==================================================================================================================================
   Signal Name                         Unit     Description
   =================================   ======   ==================================================================================================================================
   lSCruiseI_RackPosnDelta_xds16       mm       This signal is the Rack Position Deviation which was between filtered Rack Position and Nominal Rack Position (after InputLimiter)
   mSCruiseI_TorsBarTrq_xds16          Nm       Validity checked TorsionBarTorque for SCruise
   sSCruiseI_Mod_xdu8                  Status   SmartCruise operation mode: 0=Inactive, 1=HandsOn, 2=HandsFree, 3=Parking, 4=HandsOnInc
   sSCruiseI_State_xdu8                Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   sSCruiseLimrI_State_xdu8            Status   Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   vSCruiseI_AbsAvgVehSpd_xdu16        km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   vSCruiseI_RackSpd_xds32             mm/s     PT2 filtered rack speed [mm/s]
   vSCruiseLimrI_RackSpdLim_xdu16      mm/s     max. allowed rack speed checked
   xSCruiseI_HandsOnFadrFac_xdu16               Fading factor from a HandsOn (1) mode to non-HandsOn modes (0)
   xSCruiseI_StfnFac_xdu16                      Rate limited stiffness factor for SCruise, received from bus
   fSCruiseI_DeactvRackSpdLimr_xdu8             Deactivate (1) or Activate (0) rack speed limiter in case of steering jerk
   =================================   ======   ==================================================================================================================================


   Output Signals
   --------------

   ==================================   ====   =================================================================================
   Signal Name                          Unit   Description
   ==================================   ====   =================================================================================
   mSCruiseI_NomPrimCtrlrTrq_xds16      Nm     Nominal Steer Torque to increase Rack Position accuracy in the primary controller
   mSCruise_DRackSpdCtrlrTrq_xds16      Nm     D-Part of the rack speed controller
   mSCruise_IPrimMaxTrq_xdu16           Nm     Maximum of I-Part of the primary controller or total torque for
   mSCruise_IRackSpdCtrlrTrq_xds16      Nm     I-Part of the rack speed controller
   mSCruise_PRackSpdCtrlrTrq_xds16      Nm     P-Part of the rack speed controller
   vSCruise_CascdNomRackSpdLimd_xds16   mm/s   Gradient limited nominal rack speed
   xSCruise_PrimSpdCtrlrFac_xdu8               Factor to torsion bar torque dependent reduction of RackSpdCtrlrTrq (CtrlrType=1)
   xSCruise_RackPosnCtrlr_xds16                PPart of the outer cascade (rack position controller)
   ==================================   ====   =================================================================================


   Detailed Description
   --------------------

   This component provides a cascaded PID-controller controlling the rack position deviation and the rack speed deviation
   to increase the performance in a hands-off use case. In a hands-on use case the torque output is limited depending on the applied torsion bar torque
   ``xSCruise_PrimRackSpdCtrlrTrqFac_XAU16``.
   There are two different modes, the "HandsOn/HandsFree mode" and the "parking mode" on which different performance characteristic curves are used.

   Moreover the torque output is also limited by a mode dependant stiffness factor.
   The mode is differentiated between "HandsOn modes" and "non HandsOn modes" using the interface ``xSCruiseI_HandsOnFadrFac_xdu16``.

   The usage of ``vSCruiseLimrI_RackSpdLim`` ensures a smooth controlling and avoids an interaction with the safety measure **RackSpdLimiter**.

   In case of steering jerk (``fSCruiseI_DeactvRackSpdLimr_xdu8``) the limitation of rack speed is disabled .

   For first setups the possibility of a failure injection (``fSCruise_EnaRackSpdInj_XDB`` and ``vSCruise_InjdRackSpd_XDS16``)
   which overwrites the value of ``vSCruise_CascdNomRackSpdLimd_xds16`` helps to identify the right parameter.

   Resulting Controller Behaviour
   ------------------------------

   This is a resulting demonstration from the `simulation model`_ with the performance controller.

   .. _simulation model: https://sourcecode02.de.bosch.com/projects/ASMPAPP/repos/asmp-dev/browse/comps_repo/SCruiseTorqueController/fc_test/IntegrationModel_SCI

   .. image:: PerfCtrlrRackPosn.png
   .. image:: PerfCtrlrRackSpd.png


   Calibration/Application Parameters
   ----------------------------------

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ======================================   ==========   ============   ==============================================================================================================
   Parameter Name                           Unit         Range          Description
   ======================================   ==========   ============   ==============================================================================================================
   fSCruise_EnaRackSpdInj_XDB               Bitanzeige   0..1           1 enabled, 0 disabled. Enable Rack Speed Injection
   mSCruise_IPartPrimMaxTrq_XAU16           Nm           0..12          PrimCtrlr: I-Part max. nominal steer torque for legacy and performance controller (dependent on vehicle speed)
   mSCruise_PrimMaxTrq_XDU8                 Nm           0..12          CascadedCtrlr: PID-part max torque
   sSCruise_RackSpdCtrlrType_XDU8                        0..1           0: legacy PrimCtrlr, 1: Prim as cascaded RackSpdCtrlr
   vSCruise_InjdRackSpd_XDS16               mm/s         -200..200      Injected RackSpeed for rack speed controller tuning
   vSCruise_MaxGrdtRackSpd_XDU16            1/s          1..1000        maximum allowed gradient of nomial rack speed
   xSCruise_PPartRackPosnCtrlr_XAU16                     0..20          P-Part Gain of rack position controller for RackSpdCtrlrType=1
   xSCruise_DPartRackSpdCtrlr_XAU16                      0..20          D-Part gain of rack speed controller
   xSCruise_DPrimFiltFac_XDU8                            0.0078125..1   low-pass filter factor for DPrim
   xSCruise_IPartRackSpdCtrlr_XAU16                      0..1           I-Part gain of rack speed controller
   xSCruise_MaxRackSpdLimFact_XDU8                       0.5..2         Factor to apply for rack speed limit to reduce or have a reserve to SCruiseLimiter
   xSCruise_PPartRackSpdCtrlr_XAU16                      0..10          P-Part gain of rack speed controller
   xSCruise_PrimCtrlrTrqFacPrkg_XAU16                    0..1           factor to the maximum steering torque of primary controller in parking mode
   xSCruise_PrimRackSpdCtrlrTrqFac_XAU16                 0..1           factor to the maximum steering torque of primary rack speed controller in HandOn and Handsfree mode
   xSCruise_PrimStfnFacHndFreeY_XAU16                    0..1           PrimCtrl: Modify StiffnessFactor (Y-axis) depending on itself for PID-parts in HandFree modes
   xSCruise_PrimStfnFacHndOnY_XAU16                      0..1           PrimCtrl: Modify StiffnessFactor (Y-axis) depending on itself for PID-parts in HandOn modes
   xSCruise_PrimStfnFacX_XAU16                           0..1           PrimCtrl: Modify StiffnessFactor (X-axis) depending on itself for PID-parts in all modes
   ======================================   ==========   ============   ==============================================================================================================


   .. include:: SCruisePrimCtrlr_CalMan_VT.irst

﻿FltManHandleStateInitDualUcSymmSRA
###################################

Short Description
=================

The FltManHandleStateInitDualUcSymmSRA Component is a subsystem of CFM State Machine in SRA systems.
It checks and decide the system to react based on fault during startup.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: FltManHandleStateInitDualUcSymmSRA.PNG

   Input Signals
   """""""""""""

   =========================================   ==========   ============   ===============================================================================================================================
   Signal Name                                 Unit         Range          Description
   =========================================   ==========   ============   ===============================================================================================================================
   sFltManI_Events_xdu8                        n.a          0..1           An array of error events. 0-No Error, 1- Error
   =========================================   ==========   ============   ===============================================================================================================================

   Output Signals
   """"""""""""""

   =====================================   ====   =========   =========================================================================
   Signal Name                             Unit   Range       Description
   =====================================   ====   =========   =========================================================================
   fFltManI_StartUpConditions_xdu8         n.a    0..1        Flag for startup condition is fulfilled
   =====================================   ====   =========   =========================================================================

   Measurement Signals
   """""""""""""""""""

   =================================================   ==========   =======================   =====================================================================================================
   Signal Name                                         Unit         Range                     Description
   =================================================   ==========   =======================   =====================================================================================================
   sFltMan_InitMode_xdu8                                n.a          0..3                     State variable of Init Mode sub state machine
   zFltMan_InitSyncTimeoutTimer_xdu16                   sec          0..20                    Counter indicating time spent during sync mcu mode
   =================================================   ==========   =======================   =====================================================================================================

.. include:: FltManHandleStateInitDualUcSymmSRA_CalMan_VT.irst

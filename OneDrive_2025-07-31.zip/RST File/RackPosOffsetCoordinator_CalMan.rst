﻿RackPosOffsetCoordinator
###########################

Short Description
=================

The component RackPosOffsetCoordinator coordinates all the offsets (external offset sum, ASM to DSM offset..) and calculates the final DSM requested rack position.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RackPosOffsetCoordinator.PNG

   Input Signals
   -------------

   ======================================      =========    ==========    ============================================================================================================================================================
   Signal Name                                 Unit         Range         Description
   ======================================      =========    ==========    ============================================================================================================================================================
   lSWRConI_ReqRackPos_xds16                   mm           -200..200     Rack Position calculated from Steering Wheel Angle Request
   lApplI_RackPosition_xds16                   mm           -200..200     rack position
   lRocI_DSMReqOffset_xds16                    mm           -200..200     valid Sum of DSM Requested RackPositionOffset
   lRocI_InvalidOffsetSum_xds16                mm           -200..200     Sum of Invalid RackPositionOffset
   sFltManI_EcuChannelRole_xdu8                -            [0],[1]       indicated whether current channel is Master (1=Master 0=Slave)
   fRPCI_Activate_xdu8                         -            [0],[1]       flag for the activation of the RPC controller
   sTpcI_ActiveRackPosChannel_xdu8             -            0..2          Active channel (ASM or DSM)
   ======================================      =========    ==========    ============================================================================================================================================================

   Output Signals
   --------------

   ======================================      =========  ==========   ===============================================================================================================================================================
   Signal Name                                   Unit       Range       Description
   ======================================      =========  ==========   ===============================================================================================================================================================
   lRocI_DSMReqRackPos_xds16                      mm       -200..200    DSM Requested Rack Position
   ======================================      =========  ==========   ===============================================================================================================================================================

   Measurement Signals
   -------------------

   ==========================================   ======   =============   ====================================================================================================
   Signal Name                                  Unit     Range           Description
   ==========================================   ======   =============   ====================================================================================================
   lRoc_RampDownOffset_xds32                    mm       -600..600       offset to avoid jumps in DSM. Gets ramped out only when steering angle request changes.
   ==========================================   ======   =============   ====================================================================================================

   Calibration/Application Parameters
   ----------------------------------

   ====================================================    =====   ==============   ====================================================================
   Parameter Name                                          Unit    Range            Description
   ====================================================    =====   ==============   ====================================================================
   qRoc_FrequncyCycle_XDU16                                Hz      0..1000          Frequncy cycle for ROC [Hz]. qRoc_FrequncyCycle_XDU16 = 1000/time cycle of RackPositionOffsetCoordinator
   xRoc_OffsetReductionFactor_XDU16                        -       0.001..0.5       Indicates how fast lRoc_RampDownOffset is ramped down dependent on change of steering request
   vRoc_MaxRacksp4OffsetReduction_XDU16                    -       0..500           Maximum requested rackspeed threshold
   lRoc_MaxRampDownOffset_XDS32                            mm      -200..200        Maximum RampDownOffset threshold
   ====================================================    =====   ==============   ====================================================================

.. include:: RackPosOffsetCoordinator_CalMan_VT.irst

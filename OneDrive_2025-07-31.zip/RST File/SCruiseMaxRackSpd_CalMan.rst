.. only:: not confidential

   Smart Cruise Limiter | Max Rack Spd
   ###################################

   This implements the calculation of the maximum rack speed limit depended on the Mode.
   The default limit is given by a curve. Due to driver's intervention
   the limit needs to be increased to provide the required dynamic.

.. only:: confidential

   Smart Cruise Limiter | Max Rack Spd
   ###################################

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Short Description
   =================

   This implements the calculation of the maximum rack speed limit depended on the Mode.
   The default limit is given by a curve. Due to driver's intervention
   the limit needs to be increased to provide the required dynamic.


   Block Diagram
   =============

   .. image:: SCruiseMaxRackSpd_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ====================================   ======   =======================================================================================================================
   Signal Name                            Unit     Description
   ====================================   ======   =======================================================================================================================
   lSCruiseI_RackPosn_xds16               mm       SCruise filtered current Rackposition
   lSCruiseI_ReqdRackPosn_xds32           mm       Requested Rackposition for SCruise from Bus, mapped to internally
   mApplI_TorsionBarTorque_xds16          Nm       HW LIB: torsion bar torque
   mSCruiseLimrI_GradTorsBarTrq_xds16     Nm/ms    gradient of the torsion bar torque
   sSCruiseI_ReqdState_xdu8               Status   Requested State for SCruise from Bus, mapped to internally. 0-Inactive, 1-HandsOn, 2-HandsFree, 3-Parking, 4=HandsOnInc
   vSCruiseI_RackSpd_xds32                mm/s     PT2 filtered rack speed [mm/s]
   vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16   km/h     Maximum vehicle speed
   vSCruiseLimrI_AbsMinSafeVehSpd_xdu16   km/h     Minimum vehicle speed
   xSCruiseFadrI_Prgs2SCI_xdu16                    Factor indicates fading progress (0=SFC; 1=SCI)
   ====================================   ======   =======================================================================================================================


   Output Signals
   --------------

   ========================================   ======   ==========================================================================================================
   Signal Name                                Unit     Description
   ========================================   ======   ==========================================================================================================
   fScruiseLimr_LoDrvrIntractn_xdu8                    Flag to indicate low driver interaction leading to reset the limit expansion
   lSCruiseLimr_ReqdRackPosnLimd_xds32                 Rate limited requested rack position to calculate the rack position deviation
   sSCruiseLimr_StateESS_xdu8                 Status   State of evasive steering support: 0=Inactv, 1=LoDynDetd, 2=IncDynDet, 3=HiDynDet, 4=ChkExtReq, 5=ESSActvt
   vSCruiseLimrI_NegRackSpdLim4Chk_xds16      mm/s     max. allowed negative rack speed with possible limit opening due to driver interaction checked
   vSCruiseLimrI_PosRackSpdLim4Chk_xds16      mm/s     max. allowed positive rack speed with possible limit opening due to driver interaction checked
   vSCruiseLimrI_RackSpdLim4Chk_xdu16         mm/s     max. allowed rack speed
   xSCruiseLimr_DrvrIntractnCloseLim_xds8              factor to indicate Driver Interaction to close limit due to opp sign RackSpeed and TBT Grad
   xSCruiseLimr_DrvrIntractnOpenNegLim_xds8            Indicate driver interaction to open limit into negative direction
   xSCruiseLimr_DrvrIntractnOpenPosLim_xds8            Indicate driver interaction to open limit into positive direction
   zSCruiseLimr_CntrESS_xdu16                 s        counter of evasive steering detection; used for debouncing and maximum ESS
   zSCruiseLimr_JImp_xds16                    s        inertia impulse counter
   ========================================   ======   ==========================================================================================================


   Detailed Description
   --------------------

   This component provides the vehicle speed dependent maximum allowed rack speed. Different maximum allowed rack speed have been specified based on the input sSCruiseI_ReqdState_xdu8

   - If sSCruiseI_ReqdState_xdu8 = 1 (HandsOn) we use the limits specified by calibration curve vSCruiseLimr_MaxRackSpdHandsOn_XAU16
   - If sSCruiseI_ReqdState_xdu8 = 2 (HandsFree) we use the limits specified by calibration curve vSCruiseLimr_MaxRackSpdHandsFree_XAU16
   - If sSCruiseI_ReqdState_xdu8 = 3 (Parking) we use the limits specified by calibration curve vSCruiseLimr_MaxRackSpdPrkg_XAU16. If vehicle speed is above highest setpoint vSCruiseLimr_MaxRackSpdHandsFree_XAU16 will be applied
   - If sSCruiseI_ReqdState_xdu8 = 4 (HandsOnInc) we use the limits specified by calibration curve vSCruiseLimr_MaxRackSpdHandsOnInc_XAU16

   To identify a driver interaction, the rack speed, torsion bar and torsion bar torque gradient are evaluated as shown in the block diagram.

   In scenarios a driver interaction is detected the maximum allowed rack speed in HandsOn (vSCruiseLimr_MaxRackSpdHandsOn_XAU16) is increased to the limits specified in calibration curve vSCruiseLimr_MaxRackSpdDrvrIsIntractn_XAU16
   to allow sufficient dynamic for the driver's operation. To set the vSCruiseLimrI_RackSpdLim4Chk_xdu16 to the driver interaction limits, the calibration fSCruiseLimr_EnaDrvrIsIntractn4RackSpdLim_XDU8 should be = 1.
   The limits can be opened symmetrically in positive and negative direction or asymmetrically.

   If an inertia impulse (JImp) has been detected in the Hands Off situation (misuse of HandsOn) then we avoid a rack speed limit expansion.
   Opposite signs of rack speed and torsion bar torque (given that calibrated thresholds of the deadbands are exceeded) is an indicator of an inertia impulse.
   The maximum supposed time span of an inertia impulse is calibrated via tSCruiseLimr_JImp_XDU8. As long as JImp does not exceed this calibrated time, limit expansion is restricted.
   Once the time is exceeded, limit expansion is allowed by JImp.

   Evasive Steering Support (ESS)
   ------------------------------

   For ESS an own driver intervention detection has been implemented realized based on TBT and RackSpd thresholds. Initially straight ahead driving condition is recognised for certain period of time(tSCruiseLimr_LoDynPrecndnESS_XDU8)
   within a specified speed range defined by the vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16 and vSCruiseLimrI_AbsMinSafeVehSpd_xdu16. Then the detection of high rack speed initiated by the driver takes place. When TBT and rack speed is above
   thresholds and in the same direction then ESS is recognised.

   ESS activation is different based on the need for external request (fSCruiseLimr_EnaExtReqESS_XDU8). If fSCruiseLimr_EnaExtReqESS_XDU8 = 1 then ESS activation is via the ReqdState sSCruiseI_ReqdState_xdu8
   for a maximum time tSCruiseLimr_MaxEnadESS_XDU8.

   To enable the ESSfeature use fSCruiseLimr_EnaESS_XDU8. Be aware that the controllability shall be ensured via vehicle FuSi validation tests.

   To deactive ESS if SCI is deactivated, the flag fScruiseLimr_DisableESSLimReset should be = 0

   Asymmetric Limits
   ------------------------------
   The asymmetric limits are done to ensure the correctness of the SCruiseController in HandsFree mode.
   If the deviation is too high the RackSpdLim into wrong direction will be closed up to inverted. This will force the RackSpdLimr to get active and take over the control.

   The deviation of the ReqdRackPosn and current RackPosn is the input for the asymmetric limit. The deviation will be rate limited by the "HandsFree"-limit.
   The initialization is required to ensure a smooth transition while activation of SCI.


   Avoidance of unnecessary monitoring issue
   -----------------------------------------

   Due to `SF1-1123 <https://rb-tracker.bosch.com/tracker07/browse/SF1-1123>`_ it's required to follow some rules of the parameter to avoid a monitoring issue of the MaxRackSpdLim.

   - Choose values of vSCruiseLimr_MaxRackSpdHandsOn_XAU16 and vSCruiseLimr_MaxRackSpdHandsOnInc_XAU16 less or equal than vSCruiseLimr_MaxRackSpdDrvrIsIntractn_XAU16.
   - Choose values of all other maximum allowed rack speed limits greater or equal than vSCruiseLimr_MaxRackSpdHandsFree_XAU16.


   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ==============================================   ==========   ============   ===================================================================================================================================================================================
   Parameter Name                                   Unit         Range          Description
   ==============================================   ==========   ============   ===================================================================================================================================================================================
   fSCruiseLimr_EnaDrvrIsIntractn4RackSpdLim_XDU8   Bitanzeige   0..1           Enable DrvrIsInteractn for vSCruiseLimrI_RackSpdLim/-4Chk
   fSCruiseLimr_EnaESS_XDU8                         Bitanzeige   0..1           Enable detection of evasive steering support to map MaxRackSpdLim
   fSCruiseLimr_EnaExtReqESS_XDU8                   Bitanzeige   0..1           External request is (1: required) / (0: not required) in order to perform evasive steering support
   fSCruiseLimr_OpnRackSpdLimAsym_XDB               Bitanzeige   0..1           Open the rack speed limits symmetric due to driver interaction in HandsOn (0) or independent into pos/-negative direction (1)
   fScruiseLimr_DisableESSLimReset_XDU8             Bitanzeige   0..1           Flag to enable/disable reset of ESS limits after switch to SFC 0=>Reset 1=> Do not reset
   mSCruiseLimr_TbtDbnd4LoDrvr_XDU16                Nm           0..12          dead band for TorsionBarTorque used to detect low driver interaction
   mSCruiseLimr_TbtDbndOpenLim_XAU16                Nm           0..12          minium torsion bar torque to open the limit (dependent on vehicle speed)
   mSCruiseLimr_TbtGradDbndCloseLim_XDU16           Nm/ms        0..1.8999      dead band for TorsionBarTorque s gradient to close limit expansion
   mSCruiseLimr_TbtGradDbnd_XAU16                   Nm/ms        0..1.8999      dead band for TorsionBarTorque s gradient for driver s interaction to open limit expansion
   mSCruiseLimr_TbtThdESS_XAU16                     Nm           0..12          Minimum torsion bar torque threshold for detection of evasive steering event
   tSCruiseLimr_DetnDebESSHiDyn_XDU8                s            0..1           maximum time between beginning of the driver interaction and detection of high dynamic
   tSCruiseLimr_DetnDebESSThd_XDU8                  s            0..1           maximum time between detection of high dynamic and the detection of an ESS trigger
   tSCruiseLimr_LoDynPrecndnESS_XDU8                s            0..2.5         Driver is not interacting for a specified time before ESS is triggert
   tSCruiseLimr_MaxDebExtReqESS_XDU8                s            0..1           maximum time to debounce a driver event waiting for external request of evasive steering support
   tSCruiseLimr_MaxEnadESS_XDU8                     s            0..5           maximum time of enabled evasive steering support
   tSCruiseLimr_MaxJImp_XDU8                        s            0.002..0.25    maximum supposed inertia impulse to suppress a TBT expansion
   tSCruiseLimr_MinJImp_XDU8                        s            0.001..0.249   minimum supposed inertia impulse to suppress a TBT expansion
   vSCruiseLimr_MaxRackSpdDrvrIsIntractn_XAU16      mm/s         1..250         maximum allowed rack speed in case of driver interaction (dependent on vehicle speed)
   vSCruiseLimr_MaxRackSpdESS_XAU16                 mm/s         0..250         maximum allowed rack speed in case of evasive steering (dependent on vehicle speed)
   vSCruiseLimr_MaxRackSpdHandsFree_XAU16           mm/s         0..249         maximum allowed rack speed while HandsFree is active (dependent on vehicle speed)
   vSCruiseLimr_MaxRackSpdHandsOnInc_XAU16          mm/s         0..249         maximum allowed rack speed while HandsOn Dynamic Increased is active (dependent on vehicle speed)
   vSCruiseLimr_MaxRackSpdHandsOn_XAU16             mm/s         0..249         maximum allowed rack speed while HandsOn is active (dependent on vehicle speed)
   vSCruiseLimr_MaxRackSpdPrkg_XAU16                mm/s         0..249         maximum allowed rack speed while parking is active (dependent on vehicle speed). If vehicle speed is above highest setpoint vSCruiseLimr_MaxRackSpdHandsFree_XAU16 will be applied.
   vSCruiseLimr_MaxVehSpdESS_XDU8                   km/h         0..250         maximum vehicle speed for evasive steering support
   vSCruiseLimr_MinVehSpdESS_XDU8                   km/h         0..250         minimum vehicle speed for evasive steering support
   vSCruiseLimr_RackSpdThdESS_XAU16                 mm/s         0..249         Minimum RackSpeed threshold for detection of evasive steering event
   xSCruiseLimr_MaxRackSpd4JImpFac_XDU8                          0..1           factor to limit of rack speed used for inertia impulse detection
   xSCruiseLimr_MaxRackSpdOpenFac_XDU8                           0.8..1         factor to limit of rack speed used for OPENING limits
   xSCruiseLimr_MaxRackSpdRedFac_XDU8                            0..1           factor to limit of rack speed used for low driver interaction indication (lower hysteresis)
   xSCruiseLimr_TbtGrdtFilFac_XDU16                 1            0.0001..1      filter factor for TorsionBarTorque s gradient
   xSCruiseLimr_AsymRackSpdLim_XAS16                             -1..1          Reduction of asymmetric RackSpdLim into opposite direction for HandsFree mode (curve will be mirrored to both sides
   ==============================================   ==========   ============   ===================================================================================================================================================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: SCruiseMaxRackSpd_CalMan_VT.irst

Smart Cruise Interface | Controller
####################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
This component provides a PID controller to calculate the desired motor torque based on the delta of the target and actual steer torque.


Block Diagram
=============

.. only:: confidential

   .. image:: SCruiseController_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SCruiseController_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

.. only:: not confidential

   ===============================   ======   ==================================================================================================================================================================
   Signal Name                       Unit     Description
   ===============================   ======   ==================================================================================================================================================================
   mSCruiseI_TorsBarTrq_xds16        Nm       Validity checked TorsionBarTorque for SCruise
   vSCruiseI_AbsAvgVehSpd_xdu16      km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   mSCruiseI_NomPrimCtrlrTrq_xds16   Nm       Nominal Steer Torque to increase Rack Position accuracy in the primary controller
   mSCruiseI_NomSteerTrqSum_xds16    Nm       This is the sum of the SteeringTorque of Damping, SteerFeel, Requested Steering Torque, ActvJ Torque and NomSteerIPart Torque which will be send to the controller
   ===============================   ======   ==================================================================================================================================================================

.. only:: confidential

   ===============================   ======   ==================================================================================================================================================================
   Signal Name                       Unit     Description
   ===============================   ======   ==================================================================================================================================================================
   mApplI_HWLMaxUsableTorque_xdf32            MaxUsableTorque
   mSCruiseI_NomSteerTrqSum_xds16    Nm       This is the sum of the SteeringTorque of Damping, SteerFeel, Requested Steering Torque, ActvJ Torque and NomSteerIPart Torque which will be send to the controller
   mSCruiseI_TorsBarTrq_xds16        Nm       Validity checked TorsionBarTorque for SCruise
   mSCruiseI_MotTrqSumCoupl_xds16    Nm       Filtered summation of all input motor torques of main connector
   sSCruiseI_State_xdu8              Status   State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   sSCruiseLimrI_State_xdu8          Status   Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   vSCruiseI_AbsAvgVehSpd_xdu16      km/h     SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   xApplI_GearSign_xds8                       sign of the steering gear
   xSCruiseLimrI_DynResv_xds16                dynamic reserve until limit has been reached (1:full reserve; 0:no reserve, -1:full overshoot)
   ===============================   ======   ==================================================================================================================================================================


Output Signals
--------------

============================   ======   =========================================================================
Signal Name                    Unit     Description
============================   ======   =========================================================================
mSCruiseI_MotTrq_xds16         Nm       MotorTorque requested by the SCruiseController
mSCruise_DPart_xds16           Nm       DPart of the PID controller
mSCruise_IPart_xds16           Nm       IPart of the PID controller
mSCruise_PPart_xds16           Nm       PPart of the PID controller
mSCruise_TbtDeviation_xds16    Nm       TorsionBarTorque deviation as input of controller
============================   ======   =========================================================================


.. only:: confidential

   ============================   ======   =========================================================================
   Signal Name                    Unit     Description
   ============================   ======   =========================================================================
   sSCruiseI_CtrlrState_xdu8      Status   state of the controller (0=Inactv, 1=Actv, 2=Err)
   xSCruise_StabnFacRamped_xdu8            ramped stabilization factor (scaling reduced for measurement RSH10->RSH7)
   ============================   ======   =========================================================================

   Detailed Description
   --------------------

   This component calculates as output the desired motor torque. The delta between target and actual steer torque is calculated and then taken as the PID controller input which provides the desired motor torque.
   Furthermore a signal processing is done within this component. In case the input signals are invalid the controller state is set to "Err". The last valid motor torque is hold while in parallel a
   comfort fade-out is triggered via the controller state. The controller is activated if all inputs are valid and if sSCruiseI_State is considered as enabled (FadeIn, Active, FadeOut). In this case the controller state is set to "Actv".
   If sSCruiseI_State does not show any of these states the torque outputs are set to SNA and the controller state shows "Error".

   It has shown that a fast fading into SCI (e.g. in case of ESS) can lead to a spike in the TorsionBarTorque. To avoid this the IPart will be initialized with the value of the motor torque (mSCruiseI_MotTrqSumCoupl_xds16).
   This behavior can be influenced by xSCruise_IPartInitFac_XDU8. The initialization is GearSign-compensated.

   Stabilization Measure
   =====================

   The stabilization measure (with its parameter xSCruise_StabnFac_XAS16) is done to reduce the interaction with the SCruiseLimiter if the maximum allowed rack speed has been reached. Therefore a reduction factor (xSCruise_StabnFacRamped_xdu8) will be applied to PI-part.

   .. image:: SCruiseController_StabnFac.drawio.png

   A hysteresis is done to release the factor as an additional measure.

   Calibration/Application Parameters
   ==================================

   ======================================   ==========   ============   ==========================================================================================
   Parameter Name                           Unit         Range          Description
   ======================================   ==========   ============   ==========================================================================================
   fSCruise_EnblIPartScal_XDB               Bitanzeige   0..1           1 enabled, 0 disabled. Scaling of I-Part gain depending on the StabnFac
   fSCruise_EnblPPartScal_XDB               Bitanzeige   0..1           1 enabled, 0 disabled. Scaling of P-Part gain depending on the StabnFac
   mSCruise_IPartMax_XDU16                  Nm           0..12          maximum allowed I-part Torque controller
   mSCruise_MinValMaxUsableMotTorque_XDU8   Nm           0.5..5         Min Value of Max Usable Motor Torque
   tSCruise_TiToRelsStabn_XDU8              s            0.01..1        time until stabilization measure will be released fully
   xSCruise_DPartFiltFact_XDU8                           0.0078125..1   low-pass filter factor for D-part
   xSCruise_DPart_XAU16                     Nm           0..30          D-part Torque controller dependent on vehicle speed
   xSCruise_IPartInitFac_XDU8                            0..1           Enable initialization of IPart while SCI is deactivated with factor of mTrqSumI_MotTrqSum1
   xSCruise_IPart_XAU16                     Nm           0..1           I-part Torque controller dependent on vehicle speed
   xSCruise_PPart_XAU16                     Nm           0..7           P-part Torque controller dependent on vehicle speed
   xSCruise_StabnFacX_XAS16                              -1..1          stabilization measure depending on dynamic reserve (x-axis)
   xSCruise_StabnFacY_XAU8                               0..1           stabilization measure depending on dynamic reserve (y-axis)
   xSCruise_ThdToRelsStabn_XDU8                          0..1           hysteresis threshold to start ramping to normal behaviour
   ======================================   ==========   ============   ==========================================================================================


   .. include:: SCruiseController_CalMan_VT.irst

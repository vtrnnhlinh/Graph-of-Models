Servo Slip Detection
####################


Short Description
=================

The ServoSlipDetection component is responsible for the detection of a possible slipping clutch event. 
The input for this component is the WormWheelTorque, calculated on the WormWheelDamageTracker, which is compared to a specified limit value,
and if exceeded, the component increments a counter which means that a slip has occurred. The counter is then used as one of the inputs 
for the RackPositionSynchronisation component for resetting the index positions, hence invalidating the steering angle.


Block Diagram
=============

.. image:: ServoSlipDetection_CalMan_BlockDiagram1.png
.. image:: ServoSlipDetection_CalMan_BlockDiagram2.png
.. image:: ServoSlipDetection_CalMan_BlockDiagram3.png


Input Signals
-------------

=============================  ======  ==========================================
Signal Name                    Unit    Description
=============================  ======  ==========================================
mLdTrkI_WormWheelTorque_xds16  Nm      Worm wheel torque calculated in every 1 ms
=============================  ======  ==========================================


Output Signals
--------------

==============================   ====  ================================================================================
Signal Name                      Unit  Description
==============================   ====  ================================================================================
zSSDetI_DetectionCounter_xdu16         Counter of the already detected slippings in an ignition cycle
zSSDet_JustUpdated_xdu8                Flag for indicate whether slipping has been detected at the corresponding sample
==============================   ====  ================================================================================


Detailed Description
--------------------

The server detect any possible slipping suspicious event and count it via zSSDetI_DetectionCounter. 
The corresponding counter is overflow protected via toggling the LSB when the maximum value is reached.
Meanwhile, it also indicate that, whether a clutch slipping is detected or not at the corresponding sample via zSSDetI_JustUpdated.
Possible slipping event is determined based on the comparisation of the absolute value of mLdTrkI_WormWheelTorque
and the corresponding (MaxMotorTorque + Offset) which is based on a calibration parameter (mSSDet_MaxTorqueOffset_XDU16).
When the value of mLdTrkI_WormWheelTorque remains the same in 2 consecutive samples, the incrementation
process be disabled in order to avoid the step-by-step counter incrementation via fault injection. In a real driving situation, 
it is impossible the reproduce same torque in 2 consecutive sample, over the torque limitation of slipping clutch detection.
First sample detection check was also implemented, therefore in the first sample also can be detect
any possible slipping suspicious event either through SNA value or over the torque limiation.

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

============================  ====  ======  ======================================================
Parameter Name                Unit  Range    Description
============================  ====  ======  ======================================================
mSSDet_MaxTorqueOffset_XDU16  Nm    0..400  (MaxMotorTorque + Torque offset) value for slip clutch
============================  ====  ======  ======================================================

.. include:: ServoSlipDetection_CalMan_VT.irst
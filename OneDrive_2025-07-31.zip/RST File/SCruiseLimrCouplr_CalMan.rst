.. only:: not confidential

   Smart Cruise Limiter | SCruise Limr Couplr
   ##########################################

   The component is an intermediate coupler component designed to be used for processing signals before being used in the RackSpdLimr controller.

.. only:: confidential

   Smart Cruise Limiter | SCruise Limr Couplr
   ##########################################


   Short Description
   =================

   The component SCruiseLimrCouplr is an intermediate coupler component designed to be used for processing signals before being used in the RackSpdLimr controller.


   Block Diagram
   =============

   .. image:: SCruiseLimrCouplr_sm_SCruiseLimrI_LimrCouplr.png


   Input Signals
   -------------

   ===========================   ====   ==============================
   Signal Name                   Unit   Description
   ===========================   ====   ==============================
   vSCruiseI_RackSpd_xds32       mm/s   PT2 filtered rack speed [mm/s]
   ===========================   ====   ==============================


   Output Signals
   --------------

   ================================   ====   ==============================
   Signal Name                        Unit   Description
   ================================   ====   ==============================
   vSCruiseLimrI_RackSpdCoupl_xds16   mm/s   PT2 filtered rack speed [mm/s]
   ================================   ====   ==============================


   Detailed Description
   --------------------

   Provide a detailed description of the functionality depicted in the block diagram.


   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ==============   ====   =====   ===========
   Parameter Name   Unit   Range   Description
   ==============   ====   =====   ===========
   ==============   ====   =====   ===========


   .. only:: confidential

      .. Move confidential parameters from the above table down here, if applicable.

   .. include:: SCruiseLimrCouplr_CalMan_VT.irst

Smart Cruise Signal Processor | Signal Processsor Conditioning
##############################################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component belongs to the functionality SCruise Signal Processor.
It is responsible for the signal processing and conditioning of the SCI external receivers, including the BUS signals.


Block Diagram
=============

.. only:: confidential

   .. image:: SCruiseSigPrcrCdng_CalMan_BlockDiagram.png


Input Signals
-------------

   =====================================   ========   ===========================================================================================================================
   Signal Name                             Unit       Description
   =====================================   ========   ===========================================================================================================================
   lEpsInI_SCruiseReqdRackPosn_xds32       mm         SCruise requested rack position
   lApplI_RackPosition_xds16               mm         rack position
   vVehSpI_AbsAvgVehSpd_xdu16              km/h       Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
   =====================================   ========   ===========================================================================================================================

.. only:: confidential

   ===================================   ======   ===========================================================================================================================
   Signal Name                           Unit     Description
   ===================================   ======   ===========================================================================================================================
   fSCruiseI_SteerTrqReqOff_xdu8                  summarizes different inputs required from SCruiseTorqueController to switch SCI Off(1) or keep available(0)
   sApplI_EcuState_xdu8                  Status   Ecu safe state
   sApplI_SteeringAngleState_xdu8                 steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit, 4=Fallback)
   sBsdI_BlockedSteeringDetection_xdu8            states Blocked Steering Detection 0: No Blocked Steering ,1: Suspicion of Block , 2: Block Detected
   sEpsInI_SCruiseReqdState_xdu8                  SCruise s requested state: 0=Off, 1=HandsOn, 2=HandsFree, 3=Parking, 4=HandsOnInc
   sSCruiseFadrI_State_xdu8              Status   FaderState (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=SCI2SFCPND; 6=REPLCMT; 7=ERR)
   sSCruiseI_CtrlrState_xdu8             Status   state of the controller (0=Inactv, 1=Actv, 2=Err)
   sSCruiseI_FuCoCnclCdn_xdu8                     FunctionCoordinator s Cancel conditions: Bit0=FctCoLockd, Bit1=FctCoOverruled
   sSCruiseLimrI_State_xdu8              Status   Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   xApplI_TotalMotTorLim_xdu16                    total reduction of torque reduction coordinator
   xSCruiseFadrI_Prgs2SCI_xdu16                   Factor indicates fading progress (0=SFC; 1=SCI)
   ===================================   ======   ===========================================================================================================================


Output Signals
--------------

   ===================================   ========   ============================================================================================================================================================================================================================================================================================
   Signal Name                           Unit       Description
   ===================================   ========   ============================================================================================================================================================================================================================================================================================
   lSCruiseI_RackPosn_xds16              mm         SCruise filtered current Rackposition
   vSCruiseI_AbsAvgVehSpd_xdu16          km/h       SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible
   sSCruiseI_CnclCdn_xdu16                          Cancel conditions indicating why active control mode of statemachine cannot be reached: Bit0=RedLvlTooLo, Bit1=FctCoOverruled, Bit2=SigInvld, Bit3=CtrlErr, Bit4=LimrErr, Bit5=FaderErr, Bit6=FaderEmgcy, Bit7=EcuSt, Bit8=VehSpd, Bit9=BlkdSteer, Bit10=SigPrcrReqOff, Bit11=SteerTrqReqOff
   ===================================   ========   ============================================================================================================================================================================================================================================================================================

.. only:: confidential

   ====================================   ======   =============================================================================================================================================================================================================================================================================================
   Signal Name                            Unit     Description
   ====================================   ======   =============================================================================================================================================================================================================================================================================================
   lSCruiseI_RackPosnRawDelta_xds16       mm       SCruise Rackposition difference between filtered current and measured value
   lSCruiseI_ReqdRackPosn_xds32           mm       Requested Rackposition for SCruise from Bus, mapped to internally
   sApplI_TorqReductionCtrl_xdu8                   Trigger to control HwLib Reductions (0: reductions active, 1: reductions inactive)
   sSCruiseI_ReqdState_xdu8               Status   Requested State for SCruise from Bus, mapped to internally. 0-Inactive, 1-HandsOn, 2-HandsFree, 3-Parking, 4=HandsOnInc
   tSCruise_DlyCntrRstReqRackPosn_xdu16   s        Elapsed time after Fadeout is triggered
   tSCruise_RedLvlReqTooLoTmr_xds8        s        Debounce timer of too low requested reduction level
   lSCruise_RackPosnFiltPT1_xds32         mm/s     PT1 filtered rack position used for redundant check
   ====================================   ======   =============================================================================================================================================================================================================================================================================================


Detailed Description
--------------------

   The incoming signals are checked for validity. The measured rack position is PT1 filtered and used to calculate the delta between current and measured rackposition.
   In case there is invalidity in the incoming signals, or the boundary conditions to activate the SCI are not met, then the component will switch off the SCI via the sender interface sSCruiseI_CnclCdn.
   The enhanced KLA is activated by a Calibration. During enhanced KLA or when replacement controller is active together with enabled calibration, the last valid requested rack position is held and  after a calibrated delay set to 0.
   This calibrated delay or hold period should ideally be tuned smaller than the mode dependent fader pending time.

   `lSCruise_RackPosnFiltPT1_xds32` is only used internally to enable the redundant storage to ensure freedom from interference.

Calibration/Application Parameters
==================================

   =============================   ====   ============   =========================================================================
   Parameter Name                  Unit   Range          Description
   =============================   ====   ============   =========================================================================
   lSCruise_SubRackPosn_XDS16      mm     -200..254      Substitution of ReqRackPosn if value is within valid range of ReqRackPosn
   sSCruise_SubState_XDU8                 0..255         Substitution of ReqdState if value is within valid range of ReqdState
   =============================   ====   ============   =========================================================================

.. only:: confidential

   ========================================    ====   ============   ===================================================================================
   Parameter Name                              Unit   Range          Description
   ========================================    ====   ============   ===================================================================================
   tSCruise_DebTmrRedLvlReqTooLo_XDU8          s      0..0.05        Debouncing time to detect a too low requested reduction level
   vSCruise_MaxVehSpd_XDU16                    km/h   0..500         maximum allowed vehicle speed to enable the Smart Cruise Interface
   vSCruise_MinVehSpd_XDU16                    km/h   0..500         minimum allowed vehicle speed to enable the Smart Cruise Interface
   xSCruise_MinRedLvlHandsFree_XDU8                   0..1           minimum allowed requested reduction level for HandsFree mode to enable/continue SCI
   xSCruise_MinRedLvl_XDU8                            0..1           minimum allowed requested reduction level to enable/continue SCI
   xSCruise_RackPosFiltFact_XDU8                      0.0078125..1   Filter factor for RackPosition
   tSCruise_DlyCntrThdRstReqRackPosn_XDU16     s      0.001..4       Time threshold to reset the Resqested Rack Position in advanced Fadeout
   fSCruise_RstReqRackPosnEna_XDB                     0..1           Flag to enable reseting of Requested Rack Position
   ========================================    ====   ============   ===================================================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: SCruiseSigPrcrCdng_CalMan_VT.irst

Mechanical Stuck Prevention Check
#################################

Short Description
=================
This component receives motor torque offset from MechanicalStuckPrevention component, and checks if it is with in the safe limits.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============
   
   .. image:: MechanicalStuckPreventionCheck_CalMan_BlockDiagram.png

   Input Signals
   -------------

   ===================================   ====   ===============================================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ===============================================================================================================================
   mMchStPrvI_MotorTorque4Check_xds16    Nm     Motortorque Mechanical Stuck Prevention for check
   sFctCoI_ArbitrationResult_xau8    			Arbitration state of the channels :0= Arbitration Not OK; 1= Arbitration OK, Channel Active; 2= Arbitration OK, Channel Passive
   ===================================   ====   ===============================================================================================================================

   Output Signals
   --------------

   ===================================   ====   ==========================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ==========================================================================================
   mMchStPrvI_DesMotTrqOffset_xds16      Nm     Checked Motortorque Mechanical Stuck Prevention
   fMchStPrvI_MonSafeOk_xdb                     Indicates whether MonitorSafe checks report OK (1) or if they have detected a problem (0)
   ===================================   ====   ==========================================================================================
   
   =====================================   ====   ===================================================================
   Signal Name [Internal]                  Unit   Description
   =====================================   ====   ===================================================================
   mMchStPrv_MotorTorqueSaturated_xds16    Nm     saturated Motortorque Mechanical Stuck Prevention
   sMchStPrv_FailureCause_xdu8                    Cause of failure (0= no failure, 1=requested MotorTorque too high) 
   =====================================   ====   ===================================================================

   Detailed Description
   --------------------
   This component performs the safety limitation for the motor torque offset from MechanicalStuckPrevention.
   It deactivates the function until the end of the cycle in case the safety limitation or the arbitration check fails.

   Calibration/Application Parameters
   ==================================

   ===================================   ====   =========   ===================================
   Parameter Name                        Unit   Range       Description
   ===================================   ====   =========   ===================================
   mMchStPrv_MaxSafetyMotorTorq_XDU16    Nm     0 .. 0.5    Max motortorque
   ===================================   ====   =========   ===================================

.. include:: MechanicalStuckPreventionCheck_CalMan_VT.irst

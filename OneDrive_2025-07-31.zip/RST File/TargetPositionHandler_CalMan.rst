﻿TargetPositionHandler
#########################

Short Description
=================

The component TargetPositionHandler handles the fading between different RackPostion, if there is a new channel request.
The output of the TargetPositionHandler is used by RPC controller for calculating motor torque.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: TargetPositionHandler.PNG

   Input Signals
   """""""""""""

   =========================================   ==========   ============   ===============================================================================================================================
   Signal Name                                 Unit         Range          Description
   =========================================   ==========   ============   ===============================================================================================================================
   lTpcI_TargetRackPosition_xds16              mm           -200..200      Target Rack Position selected based on active channel [mm]
   xTpcI_SelectedFadingGradient_xdu16          n.a          0.001..1       Fading gradient selected based on active channel
   sTpcI_ActiveRackPosChannel_xdu8             n.a          0..2           active Rack Positon channel
   lApplI_RackPosition_xds16                   mm           -200..200      rack position [mm]
   =========================================   ==========   ============   ===============================================================================================================================

   Output Signals
   """"""""""""""

   =====================================   ====   =========   =========================================================================
   Signal Name                             Unit   Range       Description
   =====================================   ====   =========   =========================================================================
   lTpcI_ReqRackPosition_xds16             mm     -200..200   Requested rack position for RPC Controller [mm]
   =====================================   ====   =========   =========================================================================

   Measurement Signals
   """""""""""""""""""

   =================================================   ==========   =======================   =====================================================================================================
   Signal Name                                         Unit         Range                     Description
   =================================================   ==========   =======================   =====================================================================================================
   fTpc_FadingActive_xdb                               n.a          0..1                      Indicates whether Fading is active
   xTpc_FadingFactor_xdu16                             n.a          0..1                      Current fading factor
   =================================================   ==========   =======================   =====================================================================================================

.. include:: TargetPositionHandler_CalMan_VT.irst

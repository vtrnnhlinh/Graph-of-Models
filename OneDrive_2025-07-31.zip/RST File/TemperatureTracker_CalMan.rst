Temperature Tracker
###################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Short Description
=================

The component TemperatureTracker is used to track how long the steering system was in particular temperature zone.
 
Block Diagram
=============
.. image:: TemperatureTracker_CalMan_BlockDiagram.png

Input Signals
-------------

===========================   ====   ====================================
Signal Name                   Unit   Description
===========================   ====   ====================================
cApplI_InternTempFilt_xdu8    °C     HW LIB: Filtered temperature intern
===========================   ====   ====================================


Output Signals
--------------

==============================   ====   =======================================================
Signal Name                      Unit   Description
==============================   ====   =======================================================
tLdTrkI_TimeTempZone01_xdu32            Time, how long the steering system was in temp zone 1  
tLdTrkI_TimeTempZone02_xdu32            Time, how long the steering system was in temp zone 2  
tLdTrkI_TimeTempZone03_xdu32            Time, how long the steering system was in temp zone 3
tLdTrkI_TimeTempZone04_xdu32            Time, how long the steering system was in temp zone 4
tLdTrkI_TimeTempZone05_xdu32            Time, how long the steering system was in temp zone 5
tLdTrkI_TimeTempZone06_xdu32            Time, how long the steering system was in temp zone 6
tLdTrkI_TimeTempZone07_xdu32            Time, how long the steering system was in temp zone 7
tLdTrkI_TimeTempZone08_xdu32            Time, how long the steering system was in temp zone 8
tLdTrkI_TimeTempZone09_xdu32            Time, how long the steering system was in temp zone 9  
tLdTrkI_TimeTempZone10_xdu32            Time, how long the steering system was in temp zone 10 
tLdTrkI_TimeTempZone11_xdu32            Time, how long the steering system was in temp zone 11
tLdTrkI_TimeTempZone12_xdu32            Time, how long the steering system was in temp zone 12
tLdTrkI_TimeTempZone13_xdu32            Time, how long the steering system was in temp zone 13
tLdTrkI_TimeTempZone14_xdu32            Time, how long the steering system was in temp zone 14
tLdTrkI_TimeTempZone15_xdu32            Time, how long the steering system was in temp zone 15
tLdTrkI_TimeTempZone16_xdu32            Time, how long the steering system was in temp zone 16
tLdTrkI_TimeTempZone17_xdu32            Time, how long the steering system was in temp zone 17
tLdTrkI_TimeTempZone18_xdu32            Time, how long the steering system was in temp zone 18
tLdTrkI_TimeTempZone19_xdu32            Time, how long the steering system was in temp zone 19
tLdTrkI_TimeTempZone20_xdu32            Time, how long the steering system was in temp zone 20 
==============================   ====   =======================================================

.. only:: confidential

   =========================================   ====   ========================
   Signal Name [Measurement Signals]           Unit   Description
   =========================================   ====   ========================
   fLdTrk_TemperatureTrackerJobResultOK_xdb           Flag for NvM read status
   =========================================   ====   ========================


   Detailed Description
   --------------------
 
   The component TemperatureTracker is used to track how long the steering system was in particular temperature zone.
   PCB temperature is classified into different zones and the time period in each zone is calculated by incrementing 
   the time counter of the corresponding zone.
 
   
   Calibration/Application Parameters
   ==================================

   Provide a table of internal calibration parameters.
   
   =================================   =====   ===========   ===========================
   Parameter Name                      Unit    Range         Description
   =================================   =====   ===========   ===========================
   cLdTrk_TemperatureBorder1_XDU8      °C      -70 .. -40    Limit temperature zone 1
   cLdTrk_TemperatureBorder2_XDU8      °C      -40 .. -30    Limit temperature zone 2
   cLdTrk_TemperatureBorder3_XDU8      °C      -30 .. -20    Limit temperature zone 3
   cLdTrk_TemperatureBorder4_XDU8      °C      -20 .. -10    Limit temperature zone 4
   cLdTrk_TemperatureBorder5_XDU8      °C      -10 .. 0      Limit temperature zone 5
   cLdTrk_TemperatureBorder6_XDU8      °C       0 .. 10      Limit temperature zone 6
   cLdTrk_TemperatureBorder7_XDU8      °C       10 .. 20     Limit temperature zone 7
   cLdTrk_TemperatureBorder8_XDU8      °C       20 .. 30     Limit temperature zone 8
   cLdTrk_TemperatureBorder9_XDU8      °C       30 .. 40     Limit temperature zone 9
   cLdTrk_TemperatureBorder10_XDU8     °C       40 .. 50     Limit temperature zone 10
   cLdTrk_TemperatureBorder11_XDU8     °C       50 .. 60     Limit temperature zone 11
   cLdTrk_TemperatureBorder12_XDU8     °C       60 .. 70     Limit temperature zone 12
   cLdTrk_TemperatureBorder13_XDU8     °C       70 .. 80     Limit temperature zone 13
   cLdTrk_TemperatureBorder14_XDU8     °C       80 .. 90     Limit temperature zone 14
   cLdTrk_TemperatureBorder15_XDU8     °C       90 .. 100    Limit temperature zone 15
   cLdTrk_TemperatureBorder16_XDU8     °C      100 .. 110    Limit temperature zone 16
   cLdTrk_TemperatureBorder17_XDU8     °C      110 .. 120    Limit temperature zone 17
   cLdTrk_TemperatureBorder18_XDU8     °C      120 .. 130    Limit temperature zone 18
   cLdTrk_TemperatureBorder19_XDU8     °C      130 .. 140    Limit temperature zone 19
   =================================   =====   ===========   ===========================


.. include:: TemperatureTracker_CalMan_VT.irst

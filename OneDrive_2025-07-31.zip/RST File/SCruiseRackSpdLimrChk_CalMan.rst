.. only:: not confidential

   Smart Cruise Limiter
   ####################

   Input Signals
   -------------

   =====================================  ======   ============================================================================================================================
   Signal Name                            Unit     Description
   =====================================  ======   ============================================================================================================================
   vVehSpI_AbsMaxSafeVehSpd               km/h     Maximum safe vehicle speed
   vSCruiseI_RackSpd_xds32                mm/s     PT2 filtered rack speed
   mApplI_TorsionBarTorque                Nm       Torsion bar torque
   mSCruiseI_MotTrq_xds16                 Nm       MotorTorque requested by the SCruiseController
   =====================================  ======   ============================================================================================================================

   Output Signals
   --------------

   ===================================   ========   =====================================================================================================================================
   Signal Name                           Unit       Description
   ===================================   ========   =====================================================================================================================================
   mSCruiseLimrI_GradTorsBarTrq_xds16    Nm/ms      gradient of the torsion bar torque
   vSCruiseLimrI_RackSpdLim_xdu16        mm/s       max. allowed rack speed checked
   fSCruiseLimr_RackSpdMonSafeOk_xdb                Indicates whether the MaxRackSpd Monitoring reports OK (true) or if they have detected a problem (false)
   mSCruiseLimr_RackSpdCtrlrTrq_xds16    Nm         rack speed controller motor torque
   mSCruiseLimrI_MotTrq_xds16            Nm         SCruise Limiter Motor Torque
   sSCruiseLimrI_State_xdu8              Status     Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   fSCruiseLimrI_MonSafeOk_xdb           mm/s       Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   ===================================   ========   =====================================================================================================================================


.. only:: confidential

   Smart Cruise Limiter | Rack Speed Limiter Check
   ###############################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   First of all the motor torque is limited to the vehicle speed dependent safety limit. This is done as hand injury protection in case of an UAF.

   The rack speed deviation above the rack speed limit will be integrated and monitored. This ensures the correctness of the rack speed limitation.

   A limiter state monitoring is also implemented.

   A monitoring issue will be forwarded to SCruiseFader's damping.


   Block Diagram
   =============

   .. image:: SCruiseRackSpdLimrChk_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ====================================   ======   =======================================================================================================================
   Signal Name                            Unit     Description
   ====================================   ======   =======================================================================================================================
   fSCruiseLimrI_RackSpdMonSafeOk_xdb              Indicates whether the MaxRackSpd Monitoring reports OK (true) or if they have detected a problem (false)
   fSCruiseLimrI_ReqOff_xdb                        Request off (fade-out) in case of invalid inputs
   lSCruiseI_RackPosn_xds16               mm       SCruise filtered current Rackposition
   mSCruiseI_MotTrq_xds16                 Nm       MotorTorque requested by the SCruiseController
   mSCruiseLimrI_MotTrq4Chk_xds16         Nm       SCruise Limiter Motor Torque
   sSCruiseFadrI_State_xdu8               Status   FaderState (0=SFC; 1=SCI; 2=SFC2SCI; 3=SCI2SFC; 4=EMGY; 5=SCI2SFCPND; 6=DAMPG; 7=ERR)
   sSCruiseI_ReqdState_xdu8               Status   Requested State for SCruise from Bus, mapped to internally. 0-Inactive, 1-HandsOn, 2-HandsFree, 3-Parking, 4=HandsOnInc
   vSCruiseI_RackSpd_xds32                mm/s     PT2 filtered rack speed
   vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16   km/h     Maximum vehicle speed
   vSCruiseLimrI_NegRackSpdLim_xds16      mm/s     max. allowed negative rack speed with possible limit opening due to driver interaction checked
   vSCruiseLimrI_PosRackSpdLim_xds16      mm/s     max. allowed positive rack speed with possible limit opening due to driver interaction checked
   xApplI_GearSign_xds8                            sign of the steering gear
   xSCruiseFadrI_Prgs2SCI_xdu16                    Factor indicates fading progress (0=SFC; 1=SCI)
   ====================================   ======   =======================================================================================================================


   Output Signals
   --------------

   =================================   ========   ===========================================================================================================================
   Signal Name                         Unit       Description
   =================================   ========   ===========================================================================================================================
   fSCruiseLimrI_MonSafeOk_xdb                    Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   mSCruiseLimrI_MotTrq_xds16          Nm         SCruise Limiter Motor Torque
   mSCruiseLimr_MotTrqChkd_xds16       Nm         SCruise Limiter Motor Torque for Disable Switch
   sSCruiseLimrI_State_xdu8            Status     Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   sSCruiseLimr_St4Swt_xdu8            Status     Indicates the state of the SCruise Limiter: 0 = Not limited, 1 = Positiv Limited, 2 = Negativ Limited, 3 = Problem Detected
   xSCruiseLimrI_MotTrqDynResv_xds16              motor torque dynamic reserve until limit has been reached (1:full reserve; 0:no reserve, -1:full overshoot)
   xSCruiseLimr_IntglLimMon_xdu16      %/100*s    Integral of Limiter monitoring function
   xSCruiseLimr_NomIntglLimMon_xdu8               Normalized integral (to max value) of limiter monitoring function
   xSCruiseLimr_RackSpdDeQuo_xds16                Deviation requested rack speed and limited rack speed
   xSCruiseLimr_RawIntglLimMon_xds32   %/100*ms   Integral of Limiter monitoring function 1ms
   =================================   ========   ===========================================================================================================================


   Detailed Description
   --------------------

   First of all the motor torque is limited to the vehicle speed dependent safety limit. There are different calibration curves based on different modes HandsOn, HandsFree, Parking, HandsOnInc.
   Based on the Limiter requested state it is decide which curve is used. This is done as hand injury protection in case of an UAF.

   In case of low rack speed, the maximum allowed motor torque limit is increased if calibrated motor torque (mSCruiseLimr_MaxMotTrqLowRackSpd_XDU16) is greater than the vehicle speed dependent motor torque limit. Else, the vehicle speed dependent motor torque limit is used.

   A motor torque dynamic reserve is implemented to indicate if the Motor Torque is additionally limited by vehicle speed dependent characteristics curves. (1:- no motor torque applied, 0:- MotTrq=MotTrqLim, <0:-MtrTrq > MaxMotTrq )

   The percentual rack speed deviation (xSCruiseLimr_RackSpdDeQuo_xds16) above the rack speed limit (in addition to the buffer xSCruiseLimr_RackSpdLimBuf_XDU8) will be integrated and monitored.
   The monitoring checks if ThxSCruiseLimr_IntglLimMon_xdu16 >= xSCruiseLimr_MaxIntglMon_XDU16 (This parameter is vehicle speed dependent and differently characterised for Handsfree mode).
   This ensures the correctness of the rack speed limitation.

   A limiter state monitoring is also implemented. Limiter state sSCruiseLimrI_State_xdu8 = 3 (= ERROR) if fSCruiseLimrI_ReqOff_xdb = 1

   A monitoring issue (fSCruiseLimrI_MonSafeOk_xdb) will be forwarded to SCruiseFader's damping.

   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   =============================================   =======   ===============   ===================================================================================================================================================
   Parameter Name                                  Unit      Range             Description
   =============================================   =======   ===============   ===================================================================================================================================================
   mSCruiseLimr_MaxMotTrqHandsFree_XAU16           Nm        0..10             Max motor torque dependent on vehicle speed in HandsFree mode
   mSCruiseLimr_MaxMotTrqHandsOnInc_XAU16          Nm        0..10             Max motor torque dependent on vehicle speed in HandsOnInc mode
   mSCruiseLimr_MaxMotTrqHandsOn_XAU16             Nm        0..10             Max motor torque dependent on vehicle speed in HandsOn mode
   mSCruiseLimr_MaxMotTrqLowRackSpd_XDU16          Nm        0..10             Max motor torque in case of low rack speed
   mSCruiseLimr_MaxMotTrqPrkg_XAU16                Nm        0..10             Max motor torque dependent on vehicle speed in Parking mode
   vSCruiseLimr_RackSpdThdMaxMotTrq_XDU16          mm/s      0..20             Rack speed threshold for increasing the max motor torque for FreezingWaterDetection
   xSCruiseLimr_MaxIntglMonVehSpdHandsFree_XAU16   %/100*s   3.0518e-05..0.5   Maximum integral of percentual rack speed exceedance to detect a monitoring event ONLY HANDS FREE (dependent on vehicle speed)
   xSCruiseLimr_MaxIntglMonVehSpd_XAU16            %/100*s   3.0518e-05..0.5   Maximum integral of percentual rack speed exceedance to detect a monitoring event (dependent on vehicle speed)
   xSCruiseLimr_RackSpdLimBufVehSpd_XAU16                    0..1              factor to rack speed limit to increase monitoring s robustness due to the normal overshoot while rack speed limitation (dependent on vehicle speed)
   =============================================   =======   ===============   ===================================================================================================================================================


   .. include:: SCruiseRackSpdLimrChk_CalMan_VT.irst

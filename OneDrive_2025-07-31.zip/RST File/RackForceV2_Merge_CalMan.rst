RackForceV2_Merge
#################

Short Description
=================

The rack force module RackForce Merge merges the rack forces from RFMC and RFMD denpending on the vehicle speed
 	
.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!
   

Block Diagram
=============

 .. image:: RackForceV2_Merge_CalMan_BlockDiagram.png


Input Signals
-------------

==================================  ====  =================================================================================
SignalName                          Unit  Description
==================================  ====  =================================================================================
xApplI_VehDirection_xds8            -     Represents the vehicles driving direction 
vApplI_AbsVehicleSpeedFilt_xdu16    km/h  Represents the average vehicle speed calculated out of all inputs
sApplI_VehicleSpeedState_xdu8       -     Represents the validity of the average vehicle speed calculated out of all inputs
kApplI_RackForce_xds16              N     Computed rack force
kRackForceI_RackForceComfort_xds16  N     Computed comfort rack force
==================================  ====  =================================================================================


Output Signals
--------------

============================  ====   ====================================================================
Signal Name                   Unit   Description
============================  ====   ====================================================================
kApplI_RackForceMerge_xds16   N      Merged rack force
xRackForceI_RatioD2C_xdu16    -      Computed ratio of the merged rack force (1=100% RFM-D, 0=100% RFM-C)
============================  ====   ====================================================================


Detailed Description
--------------------
Disturbances like the variation of internal friction are not displayed in the rack force signal based on vehicle model and the information about the character of the driving surface is only displayed in the rack force signal based on equitation of motion. Thus the rack force based on vehicle model should only be used, if the disbturbances can occur. This function realizes a smooth transition while selecting the wanted rack force alternative.

Calibration/Application Parameters
==================================

=================================================  ====  ==========  ===========================================
Name                                               Unit  Range       Description
=================================================  ====  ==========  ===========================================
xRackForce_FilterFactorRatioDynamic2Comfort_XDU16  N     0.001 .. 1  Filter factor for merge dynamic and comfort
yRackForce_Switch_XDU8                             -     0 .. 2      Switch for dynamic mode(1)/comfort mode(2)
yRackForce_RFMD_WhileReversing_XDU8                N     0 .. 1      RFMD for reverse gear
vRackForce_RackForceMergeVehicleSpeedSubst_XDU16   km/h  0 .. 500    substitute vehicle speed when invalid
xRackForceMerge_RatioDyn2Com_XAU16                 -     0 .. 1      Kennfeld for RackForce Merge; X-Axis: RackForce, Y-Axis: VehicleSpeed
=================================================  ====  ==========  ===========================================

.. include:: RackForceV2_Merge_CalMan_VT.irst
TargetPositionArbitrator
#########################

Short Description
=================

The server receives all the Requested Rack Position and selects the target rack position based on the priority configured

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: TargetPositionArbitrator.PNG

   Input Signals
   -------------

   ==================================   ==========   =========   ===================================================================================================
   Signal Name                          Unit         Range       Description
   ==================================   ==========   =========   ===================================================================================================
   lRocI_DSMReqRackPos_xds16            mm           -200..200   DSM Requested Rack Position
   lTpcI_ReqRackPosition_xds16          mm           -200..200   Requested rack position for RPC Controller
   lApplI_RackPosition_xds16            mm           -200..200   current rack position [mm]
   fSyncMonI_Status_xdu8                n.a          0..1        status Flag: 0 = N_OK, 1 = OK
   sFltManI_EcuChannelRole_xdu8         n.a          0..1        indicated whether current channel is Master
   fRPCI_Activate_xdu8                  n.a          0..1        flag for the activation of the RPC controller
   ==================================   ==========   =========   ===================================================================================================

   Output Signals
   --------------

   ===============================================   =========   =========   ============================================================================================
   Signal Name                                       Unit        Range       Description
   ===============================================   =========   =========   ============================================================================================
   lTpcI_TargetRackPosition_xds16                    Nm          -200..200   Target Rack Position selected based on active channel
   sTpcI_ActiveRackPosChannel_xdu8                   n.a         0..2        Active Rack Positon channel
   xTpcI_SelectedFadingGradient_xdu16                n.a         0.001..1    Fading gradient selected based on active channel
   ===============================================   =========   =========   ============================================================================================

   Calibration/Application Parameters
   ==================================
   Internal calibration parameters.

   ======================================  =====   ========   =====================================================================================================
   Parameter Name                          Unit    Range      Description
   ======================================  =====   ========   =====================================================================================================
   xTpc_DSMFadingGradient_XDU16            n.a     0..1       Fading gradient for DSM Channel
   ======================================  =====   ========   =====================================================================================================

.. include:: TargetPositionArbitrator_CalMan_VT.irst

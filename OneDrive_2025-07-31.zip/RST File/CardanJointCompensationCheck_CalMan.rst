Cardan Joint Compensation Check
###############################


Short Description
=================

The CardanJointCompensationCheck component receives the steering and motor torque offset from the
CardanJointCompensation module. The steering torque offset value is checked against the
safety measurements.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Block Diagram
   =============

   .. image:: CardanJointCompensationCheck_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ===================================   ====   ================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ================================================================================================
   mCJCI_DesMotTrqOffset4Check_xds16     Nm     Desired motor torque offset of Cardan Joint Compensation to be read by Check component only
   mCJCI_DesSteerTrqOffset4Check_xds16   Nm     Desired steering torque offset from Cardan Joint Compensation to be read by Check component only
   sFctCoI_ArbitrationResult_xau8               is arbitration valid for this channel?
   ===================================   ====   ================================================================================================


   Output Signals
   --------------

   ===================================   ====   ====================================================================================================
   Signal Name                           Unit   Description
   ===================================   ====   ====================================================================================================
   fCJCI_MonSafeOk_xdb                          Indicates whether the MonitorSafe checks report OK (true) or if they have detected a problem (false)
   mCJCI_DesMotTrqOffset_xds16           Nm     Desired motor torque offset of Cardan Joint Compensation
   mCJCI_DesSteerTrqOffset_xds16         Nm     Desired steer torque offset of Cardan Joint Compensation
   ===================================   ====   ====================================================================================================
     
   
   ===================================   ====   ====================================================================================================
   Signal Name [Internal]                Unit   Description
   ===================================   ====   ====================================================================================================   
   mCJC_DesSteerTrqOffsetChecked_xds16   Nm     Steer torque offset which has been subjected to the MakeSafe measures
   ===================================   ====   ====================================================================================================


   Detailed Description
   --------------------

   The data flow is shown in the diagram. MakeSafe implements safety limitation. MonitorSafe and
   DisableSwitch implements the deactivation until the end of the cycle in case of safety limitation
   or arbitration fails.


   Calibration/Application Parameters
   ==================================

   =================================   ====   =====   ===================================
   Parameter Name                      Unit   Range   Description
   =================================   ====   =====   ===================================
   mCJC_SafetyLimitSteerTorque_XDU16   Nm     0..3    Safety limit of steer torque offset
   =================================   ====   =====   ===================================

.. include:: CardanJointCompensationCheck_CalMan_VT.irst

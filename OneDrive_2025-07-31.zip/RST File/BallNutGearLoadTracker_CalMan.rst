BallNutGear Load Tracker
########################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component calcualtes and stores information about the Load On BallNutGear.
The Load is calculated using the motor torque and steering angle information.

These calculation is applicable for apa steering system.

.. only:: confidential

   Block Diagram
   =============

   .. image:: BallNutGearLoadTracker_CalMan_BlockDiagram.png 

Input Signals
-------------

================================   ====   =========================================================================================
Signal Name                        Unit   Description
================================   ====   =========================================================================================
mApplI_LimitedMotorTorque_xds16    Nm     limited motor torque
wApplI_SteeringAngle_xds16         Deg    Corrected Steering Angle. This is the short-time and long-time corrected steering angle.
sApplI_SteeringAngleState_xdu8	   	  	  State of steering angle / rackposition: 0-invalid, 1-raw, 2-exactly
================================   ====   =========================================================================================


Output Signals
--------------
 
=================================   ====   ===================================
Signal Name                         Unit   Description
=================================   ====   ===================================
yLdTrkI_BallNutGear_xdu32                  Value of the BallNutGear Load
yLdTrkI_BallNutGearH_xdu32                 Value of the BallNutGear Load high
=================================   ====   ===================================

.. only:: confidential

   ==========================================   ====   =====================================
   Signal Name [Measurement Signals]            Unit   Description
   ==========================================   ====   =====================================
   mLdTrk_FiltMMot4BallNutLoadTracker_xds16		Nm	   Filtered motor torque
   yLdTrk_BallNutGearLDelta_xdf32			           Value of the BallNutGear Load Low
   fLdTrk_BallNutJobResultOK_xdb				 	   Job Result of NVM Read all operation
   ==========================================   ====   =====================================

   Detailed Description
   --------------------
   The load encountered by the steering system during its life time is calculated based on the changes in the limited motor torque and stored persistently. 
   This diagnostic information is taken into consideration when deciding if the steering system can be refurbished or it must be scrapped.


   Calibration/Application Parameters
   ==================================

   Provide a table of internal calibration parameters.
   
   =======================================   ======   ====================   ======================================================
   Parameter Name                            Unit     Range                  Description
   =======================================   ======   ====================   ======================================================
   xLdTrk_BallNutMMotFilterFact_XDU16                 0.0009765625 .. 1      filter factor motor torque
   wLdTrk_HysteresisFilterWidthKgt_XDU16     Nm	      0 .. 1000	             filter width hysteresis filter kgt alteration metric
   xLdTrk_LoadFactor_XDF32                   °Nm^3    0.0000001 .. 0.00001   Load Factor For BallNutGear
   =======================================   ======   ====================   ======================================================
   
   All other Rom-Parameter are dependent to Wöhler-Versuche or Wöhler-Kennlinien. These Rom-Parameter are set by MechanicalDataSheet.

.. include:: BallNutGearLoadTracker_CalMan_VT.irst

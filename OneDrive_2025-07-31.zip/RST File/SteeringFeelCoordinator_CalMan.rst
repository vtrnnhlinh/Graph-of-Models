Steering Feel Coordinator
#########################

Short Description
=================

The SteeringFeelCoordinator is a special torque summation point for steering torques.



Block Diagram
=============

.. image:: SteeringFeelCoordinator_CalMan_BlockDiagram_Customer.png


Input Signals
-------------

===================================   ====   =======================================
Signal Name                           Unit   Description
===================================   ====   =======================================
mActInI_NominalSteerTorque_xds16      Nm     Nominal steer torque of active inertia
mBSTI_NominalSteerTorque_xds16        Nm     Basic Steering Torque
mCentFeelI_NominalSteerTorque_xds16   Nm     nominal center feel torque
mHystTorI_NominalSteerTorque_xds16    Nm     Nominal Steer Torque of the Hysteresis
mTrqSumI_SteerTrqSum_xds16            Nm     summation of all input steering torques
===================================   ====   =======================================


Output Signals
--------------

==================================   ====   =======================================
Signal Name                          Unit   Description
==================================   ====   =======================================
mStFCI_NominalSteerTorque_xds16      Nm     Nominal Steer Torque for Controller
==================================   ====   =======================================

Detailed Description
--------------------

The task of this component is to specify the target torsion bar torque for the steering system controller in dependence upon the torque portions of the application functions.
The fundamental structure consists of the target torsion bar torques described above that are calculated via a summation point to form the target torsion bar torque.
All of the torque portions can be separately switched on and off for ease of application and to localized certain torque influences. 

Calibration/Application Parameters
==================================

=============================   ==========   =====   ===============================
Parameter Name                  Unit         Range   Description
=============================   ==========   =====   ===============================
fStFC_UseActiveInertia_XDU8     Bitanzeige   0..1    Switch for Active Inertia
fStFC_UseBasicSteerTor_XDU8     Bitanzeige   0..1    Switch for Basic Steer Torque
fStFC_UseCenterPointFeel_XDU8   Bitanzeige   0..1    Switch for Center Point Feeling
fStFC_UseHysteresis_XDU8        Bitanzeige   0..1    Switch for Hysteresis
=============================   ==========   =====   ===============================


.. include:: SteeringFeelCoordinator_CalMan_VT.irst

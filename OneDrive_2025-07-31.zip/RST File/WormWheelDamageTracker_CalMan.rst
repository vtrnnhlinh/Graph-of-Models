﻿WormWheelDamageTracker
######################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!
Short Description
=================
.. only:: confidential

Dual Pinion steering systems use a worm drive which has a worm wheel that can break depending on the daily wear and tear.
In some special cases this defect can cause a blocked steering.
Even a single, very high stress impulse can be enough to cause the wheel to break, therefore a clutch was used in the past to prevent this from happening.

The component WormWheelDamageTracker (Part of LoadTracking) is used to estimate if and when the wheel will break to warn the driver and to initiate a visit of a shop before the damage actually happens.

For more detailed and general Information take a look in our complete Documentation stored in Docupedia:
https://inside-docupedia.bosch.com/confluence/pages/viewpage.action?pageId=777788365


Block Diagram
=============
.. only:: confidential

Principle Concept is shown in the following BlockDiagram

.. image:: BlockDiagram_2.png

The whole Component WormWheelDamageTracker consits of nine servers:
 - LdTrkI_CalcWormWheelTorque
	The server LdTrkI_CalcWormWheelTorque implements the calculation of the worm wheel torque.
	Output is the resulting torque at the worm wheel as a result of the load from steering support (rotational dominant mode)
	and influences from outside of steering system over tie rods (impact dominant mode).
	This worm wheel torque is further used to calculate the damage of the worm wheel as well as to detect a slipping clutch if needed.
	Furthermore the server calculates the maximal worm wheel torque during the ignition cycle.

 - LdTrkI_WWTFindTurningPoints
	The server LdTrkI_WWTFindTurningPoints finds extremas of the worm wheel torque and classifies each extrema as Impact or Rotary. Then it provides the found extremas to the components that calculate the damage based on them.
	Besides it also calculates the temperature of the worm wheel.

 - LdTrkI_TrackWormWheelImpactDamage
	The sever LdTrkI_TrackWormWheelImpactDamage implements the impact damage calculation of the worm wheel based on the found extremas of type Impact of worm wheel torque.
	Output is the impact damage of the worm wheel.

 - LdTrkI_SolveFinalWormWheelImpactResidue
	The server LdTrkI_SolveFinalWormWheelImpactResidue implements the impact damage calculation of the worm wheel in post run.
	Input is the residuum, calculated in the main function.
	Output is the impact damage of the worm wheel.

 - LdTrkI_TrackWormWheelRotationalDamage
	The server LdTrkI_TrackWormWheelRotationalDamage implements the rotational damage calculation of the worm wheel based on the found extremas of type Rotary of worm wheel torque. 
	Output is the rotational damage of the worm wheel.
 
 - LdTrkI_SolveFinalWormWheelRotationalResidue
	The module LdTrkI_SolveFinalWormWheelRotationalResidue implements the rotational damage calculation of the worm wheel in post run.
	Input is the residuum, calculated in the main function.
	Output is the damage of the worm wheel.

 - LdTrkI_WormWheelSafeGuard
	A decreasing damage due to an error shall be avoided.
	Therefore it is checked, if the damage is greater or equal the value at the beginning of the cycle.
	If damage counter is greater or equal, there has been no error and the new value is used,
	if damage is lower, then a default value is added to the damage value and this damage value is used.
 
 - LdTrkI_DataLossCompensation
	The server checks if last ignition cycle was ended properly. 
	If not, DF has not been written last cycle (which is detected from sI_ResetState).
	So a default value is added to the worm wheel damage. The damage is stored for further use in WormWheelSafeGuard.
	
 - LdTrkI_NvMJobStatusCallback
	The server checks if the NvM Read all was successful and the information from DF is copied to RTE.
 

Input Signals
-------------
.. only:: confidential

====================================   ========   ===========================================
Signal Name                            Unit       Description
====================================   ========   ===========================================
mApplI_LimitedMotorTorque_xds16        Nm         limited motor torque
nApplI_RotorSpeed_xds16                1/min      unfiltered rotor speed
cApplI_InternTempFilt_xdu8             °C         filtered internal temperature
cHwlWrapI_UcTempFilt_xdu8              °C         temperature of the microcontroller
wApplI_RotorPosition_xds32             °          integrated, compensated rotor position
mHwlWrapI_ProvidedMotorTorque_xdf32    Nm         provided motor torque
sHwlWrapI_ActuatorState_xde                       Actuator state
sMcdI_ErrLvl_xdu8                                 Error level MCDataIntegrity
====================================   ========   ===========================================

Output Signals (Interfaces)
----------------------------
.. only:: confidential

==================================     ========   =========================================================================================
Signal Name                            Unit       Description
==================================     ========   =========================================================================================
yLdTrkI_WormWheelRotDamage_xdu32                  Value of the worm wheel rotational damage for Low-UInt32
yLdTrkI_WormWheelRotDamageH_xdu32                 Value of the worm wheel rotational damage for High-UInt32
yLdTrkI_WormWheelImpDamage_xdu32                  Value of the worm wheel impact damage for Low-UInt32
yLdTrkI_WormWheelImpDamageH_xdu32                 Value of the worm wheel impact damage for High-UInt32
mLdTrkI_MaxWormWheelTorque_xdu16       Nm         Max Impact WormWheelTorque
mLdTrkI_WormWheelTorque_xds16          Nm         worm wheel torque
sLdTrkI_ResetState_xdu8                           Toggle flag to detect if the block was written at the end of the last ignition cycle
yLdTrkI_DataLossCount_xdu16                       Counter of data loss caused by power loss
sLdTrkI_ReadJobResultOK							  Nvm Read Success
sLdTrkI_WriteJobResultOK						  Nvm Write Success
sLdTrkI_ErrLvl									  Error level (Set when Nvm Read/Write failed)
sLdTrkI_ErrLvl_Red								  Error level (Set when Nvm Read/Write failed)
==================================     ========   ========================================================================================= 

Output Signals (MeasurementsVariables)
--------------------------------------
.. only:: confidential

=================================================     ===============================================================================================================
Signal Name                                           Description
=================================================     =============================================================================================================== 
yLdTrk_ResiduumWormWheelRotDamage_xau8                Residuum Worm wheel, array size = (2xamount of classes+1)x2
cLdTrk_ResiduumWormWheelRotTemperature_xau8           Residuum Worm wheel temperatur, size must be equal to size of AlterationResiduum
zLdTrk_ValuesInResRot_xdu16                           Values in residuum, max value must be equal to size of AlterationResiduum
yLdTrk_WormWheelRotDamage_LastCycle_xdu32             Value of the worm wheel alteration of last cycle lower 32Bit
yLdTrk_WormWheelRotDamageHigh_LastCycle_xdu32         Value of the worm wheel alteration of last cycle upper 32Bit
yLdTrk_ResiduumWormWheelImpDamage_xau8                Residuum Worm wheel for impact damage, array size = (2xamount of classes+1)x2, amount of classes = maxp_w
zLdTrk_ValuesInResImp_xdu16                           Values in residuum for impact damage, max value must be equal to size of AlterationResiduum
yLdTrk_WormWheelImpDamage_LastCycle_xdu32             Value of the worm wheel alteration of last cycle lower 32Bit (ImpactPart)
yLdTrk_WormWheelImpDamageHigh_LastCycle_xdu32         Value of the worm wheel alteration of last cycle upper 32Bit (ImpactPart)
mLdTrk_WormWheelTorqueFilt_xds16                      PT1-filtered worm wheel torque
xLdTrk_EfficiencySystem_xds16                         Efficiency of the system
aLdTrk_RotAccelDiffQuotient_xds32                     Rotor acceleration with difference quotient over 4 ms
mLdTrk_FOCTorqueMeasurment_xds16                      Motor torque which is used for the calculation of the worm wheel torque.
fLdTrk_DataLossChecked_xdu8                           Flag indicates that DataLossCompensation was done in current ignition cycle
sLdTrk_JobResultOK_xdu8                               Give the result whether data is ok or corrupted.
cLdTrk_CalcWormWheelTemp_xdu8                         Calculated snail wheel temperature
=================================================     ===============================================================================================================

Detailed Description
--------------------
.. only:: confidential

For more detailed and general Information take a look in our complete Documentation stored in Docupedia:
https://inside-docupedia.bosch.com/confluence/pages/viewpage.action?pageId=777788365

Calibration/Application Parameters
==================================

.. only:: confidential

Provide a table of calibration parameters.
   
===========================================   ====================   ===================================================================================
Parameter Name                                Range                  Description
===========================================   ====================   ===================================================================================
xLdTrk_FilterFactTempWorm_XDU16               0...0.99998            filter factor temperature
xLdTrk_GradLine_XDU16                         0...1                  worm wheel temperature factor
cLdTrk_OffsetLine_XDS16                       -32...31.99            worm wheel temperature offset b
xLdTrk_RefRotorVelocity_XDU16                 1...100                reference rotor velocity for active/passive efficiency change        
xLdTrk_RefMotorTorque_XDU16                   0.1...1                reference motor torque for active/passive efficiency change
xLdTrk_ImpactTorqueFilterFact_XDU16           0.001...1              filter factor impact torque
xLdTrk_WWT4RotationalDamageFilterFact_XDU16   0.001...1              filter factor WormWheelTorque for rotational damage
xLdTrk_WWT4ImpactDamageFilterFact_XDU16       0.001...1              filter factor WormWheelTorque for impact damage
xLdTrk_RotAccFilterFact_XDU16                 0.001...1              filter factor of unfiltered rotor acceleration (Low=0.35 High=0.02 Off=1.0)
xLdTrk_Treshold4RotSpeedDeadZone_XDU16        1...100                treshold for RotorSpeed deadband
xLdTrk_LimitedMMOTFilterFact_XDU16            0.001...1              filter factor LimitedMotorTorque
xLdTrk_WWTFilterFact_XDU16                    0.001...1              filter factor worm wheel torque
xLdTrk_WWTDerivationFilterFact_XDU16          0.001...1              filter factor for PT1 for calculation of WWT derivation
cLdTrk_SubstTemp_XDU8                         0...184                substitute value if temperature signal is invalid
wLdTrk_MaxDeltaRotPos_XDU16                   0...5000               DeltaRotPos-treshold between two extrems for classifying new extrema as rotary
mLdTrk_MaxDeltaWWT_XDU16                      0...1000               Max change rate of worm wheel torque, so that it is still considered as rotary
===========================================   ====================   ===================================================================================

Hint: filter factor = 1 / ( T/dt + 1 ) with T = time constant continuous [s] and dt = cycle time [s]
   
All other Rom-Parameter are dependent to Wöhler-Versuche or Wöhler-Kennlinien. These Rom-Parameter are set by MechanicalDataSheet.
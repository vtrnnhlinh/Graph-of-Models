Safety Controller Check
#######################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The component SafCtrlCheck validates the steering assistance calculated by the SafetyController to prevent a violation of other safety goals.
In addition, the activated/deactivated MMOT from MTL is added to the checked SafetyController MMOT.


Block Diagram
=============

.. only:: confidential

   .. image:: SafetyControllerCheck_CalMan_BlockDiagram.png

No block diagram for external usage.


Input Signals
-------------

=============================   ====   ====================================================================================
Signal Name                     Unit   Description
=============================   ====   ====================================================================================
mApplI_TorsionBarTorque_xds16   Nm     HW LIB: torsion bar torque
mSafCtrlI_MotTrq4Check_xds16    Nm     Safety controller motor torque for check
mSafCtrlI_MotTrqFromMTL_xds16   Nm     limited motor torque by motortorquelimiter, which is possibly deactivated is SafCtrl
xApplI_GearSign_xds8                   sign of the steering gear
=============================   ====   ====================================================================================


Output Signals
--------------

==============================   ====   =================================================
Signal Name                      Unit   Description
==============================   ====   =================================================
mSafCtrlI_MotorTorque_xds16      Nm     Sum of SafetyController motor torque and MTL_MMOT
mSafCtrl_LowerLimitCheck_xds16   Nm     Safety controller lower limit
mSafCtrl_MotorTorque4Sum_xds16   Nm     SafetyController motor torque
mSafCtrl_UpperLimitCheck_xds16   Nm     Safety controller upper limit
==============================   ====   =================================================


Detailed Description
--------------------

.. only:: confidential

   The SafetyControllerCheck is limiting the value of mSafCtrlI_MotTrq4Check_xds16 to the current value of the characteristic curve mSafCtrl_MaxSafCtrlMotorTorque_XAU16 (depending on torsion bar torque) provided by SafetyController.

No detailed description for external usage.


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

.. only:: confidential

   Provide a table of internal calibration parameters.
   
   ====================================   =====   =====   ========================================================================================================================================================================================================
   Parameter Name                         Unit    Range   Description                                                                                                                                                                                             
   ====================================   =====   =====   ========================================================================================================================================================================================================
   mSafCtrl_MaxSafCtrlMotorTorque_XAU16   Nm      0..25   Max. SafetyController motor torque dependent on AbsTorsionBarTorque. The first two points MUST be zero due to handoff detection! The max. supporting torque MUST be below 3Nm! The curve MUST be rising!
   ====================================   =====   =====   ========================================================================================================================================================================================================

No parameters for external usage.

.. only:: confidential

   .. include:: SafCtrlCheck_CalMan_VT.irst

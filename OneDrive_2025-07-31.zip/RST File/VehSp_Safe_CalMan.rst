VehSp_Safe
##########

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

Calculate the safe vehicle speeds based on the minimum/maximum of the input signals. Also provide
the average of the input signals to be used for plausibilisation.


Block Diagram
=============

.. image:: VehSp_Safe_CalMan_BlockDiagram.png


Input Signals
-------------

=============================   ====   ===============================
Signal Name                     Unit   Description
=============================   ====   ===============================
vEpsInI_VehicleSpeedRaw_xds16   km/h   Vehicle Speed Raw Value
vEpsInI_WheelSpeedFLDiv_xds16   km/h   Diverse Wheel Speed Front Left
vEpsInI_WheelSpeedFRDiv_xds16   km/h   Diverse Wheel Speed Front Right
vEpsInI_WheelSpeedRLDiv_xds16   km/h   Diverse Wheel Speed Rear Left
vEpsInI_WheelSpeedRRDiv_xds16   km/h   Diverse Wheel Speed Rear Right
=============================   ====   ===============================


Output Signals
--------------

================================   ====   ===================================================================================================================
Signal Name                        Unit   Description
================================   ====   ===================================================================================================================
vVehSpI_AbsAvgVehSpd4Check_xdu16   km/h   Average vehicle speed to be read by check component. Note: this is just a simple average used for plausibilization.
vVehSpI_AbsMaxVehSpd4Check_xdu16   km/h   Maximum vehicle speed to be read by check component.
vVehSpI_AbsMinVehSpd4Check_xdu16   km/h   Minimum vehicle speed to be read by check component.
================================   ====   ===================================================================================================================


Detailed Description
--------------------

The *Calc Safe Speeds* algorithm is very simple. It determines the min, max and average values of
all input speed signals. Since the goal is safety, this is only done if the RawSpeed is valid and at
least zVehSp_MinValidWheelSpeeds4Safe_XDU8 wheel speeds are also valid. Gradient limitation
is applied to v_Min and v_Max in the following fashion:

  * v_Max
  
    * Increase is immediate
    * Decrease is rate limited (aVehSp_MaxNegGradientVMax_XAU8)
    
  * v_Min
  
    * Increase is rate limited (aVehSp_MaxPosGradientVMin_XAU8)
    * Decrease is immediate


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

====================================   ====   =========   =====================================================================================================
Parameter Name                         Unit   Range       Description
====================================   ====   =========   =====================================================================================================
aVehSp_MaxNegGradientVMax_XAU8         km/h   0..3.9844   Max negative gradient of the vehicle speed v_Max [km/h/10ms]
aVehSp_MaxPosGradientVMin_XAU8         km/h   0..3.9844   Max positive gradient of the vehicle speed v_Min [km/h/10ms]
zVehSp_MinValidWheelSpeeds4Safe_XDU8          1..4        Minimum number of valid wheel speed signals required to provide the safe output speeds (v_Min, v_Max)
====================================   ====   =========   =====================================================================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: VehSp_Safe_CalMan_VT.irst

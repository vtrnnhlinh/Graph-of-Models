Automatic Parking Control Check
###############################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The APC Check Component allows the Torque as requested from Main component (APC Rack Position Controller) after verifying the following conditions:
1. Whether driver has not interrupted by detecting Hands On.
2. Vehicle speed to be within the threshold.
3. Arbitration is OK and channel is active.

If the conditions are not satisfied then the requests are set to 0 Nm until the end of the cycle.


Block Diagram
=============

.. image:: AutomaticParkingControlCheck_CalMan_BlockDiagram.png


Input Signals
-------------

===========================================   ====   ===============================================================================================================================
Signal Name                                   Unit   Description
===========================================   ====   ===============================================================================================================================
mApplI_TorsionBarTorque_xds16                 Nm     HW LIB: torsion bar torque
mAutParkCtrlI_DesMotTrqOffset4Check_xds16     Nm     Desired motor torque offset of Automatic Parking Control to be read by Check component only
mAutParkCtrlI_DesSteerTrqOffset4Check_xds16   Nm     Desired steering torque offset of Automatic Parking Control to be read by Check component only
sFctCoI_ArbitrationResult_xau8                       Arbitration state of the channels :0= Arbitration Not OK; 1= Arbitration OK, Channel Active; 2= Arbitration OK, Channel Passive
vVehSpI_AbsMaxSafeVehSpd_xdu16                km/h   Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
xAutParkCtrlI_DesActRetFuncFact4Check_xdu16          Desired ActiveReturn function factor of AutomaticParkingControl to be read by Check component only
===========================================   ====   ===============================================================================================================================


Output Signals
--------------

===========================================   ====   =====================================================================================================================================================================================
Signal Name                                   Unit   Description
===========================================   ====   =====================================================================================================================================================================================
fAutParkCtrl_MonSafeOk_xdb                           Indicates whether the MonitorSafe checks report OK (1) or if they have detected a problem (0)
mAutParkCtrlI_DesMotTrqOffset_xds16           Nm     Desired motor torque offset of Automatic Parking Control
mAutParkCtrlI_DesSteerTrqOffset_xds16         Nm     Desired steer torque offset of Automatic Parking Control
mAutParkCtrl_DesMotTrqOffsetChecked_xds16     Nm     Steer torque offset which has been subjected to the MakeSafe measures
mAutParkCtrl_DesSteerTrqOffsetChecked_xds16   Nm     Steer torque offset which has been subjected to the MakeSafe measures
sAutParkCtrlI_MakeSafeAndMonState_xdu8               Indicates whether the MakeSafe and MonitorSafe checks report OK (0) or if they have detected a problem (1) or if HandsOn was detected (2) of if invalid arbitration was detected (3).
sAutParkCtrl_MakeSafeState_xdu8                      Indicates whether the MakeSafe checks report OK (0), if they have detected a problem (1) or if HandsOn was detected (2).
xAutParkCtrlI_DesActRetFuncFact_xdu16                Desired ActiveReturn function factor of AutomaticParkingControl
xAutParkCtrl_DesActRetFuncFactChecked_xdu16          ActiveReturn function factor which has been subjected to the MakeSafe measures
zAutParkCtrl_HandsOnCounter_xdu16             ms     Diverse stored counter value of HandsOnDetection
===========================================   ====   =====================================================================================================================================================================================


Detailed Description
--------------------

   Both servers - MakeSafe and MonitorSafe - are checking the APC's activity above the safety limit of vehicle speed of SafetyLimitMaxVehicleSpeed.
   In case of activity the functionality will be deactivated until the end of the cycle.
   MakeSafe implements also the temporary deactivation due to a Hands On Detection (driver interruption).


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=============================================   ====   ========   =======================================================
Parameter Name                                  Unit   Range      Description
=============================================   ====   ========   =======================================================
mAutParkCtrl_CheckHandsOnTorqLim_XDU16          Nm     0.5..7     threshold of driver s steering torque to detect HandsOn
tAutParkCtrl_CheckHandsOnSwOffTime_XDU16        ms     20..1000   detection time for HandsOn
tAutParkCtrl_CycleTimeController_XDU8           ms     1..10      Cycle time of controller function call
vAutParkCtrl_SafetyLimitMaxVehicleSpeed_XDU16   km/h   0..10      safety limit of maximum allowed vehicle speed
=============================================   ====   ========   =======================================================


.. only:: confidential

   .. Move confidential parameters from the above table down here, if applicable.

.. include:: AutomaticParkingControlCheck_CalMan_VT.irst

RackForceV2_ComfortAdapt
########################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

Calculates windup adaption for calculation of rack force comfort under consideration of driving situations


Block Diagram
=============

.. only:: confidential

   .. image:: RackForceV2_ComfortAdapt_CalMan_BlockDiagram.png          


Input Signals
-------------

=====================================   =====   =====================================================================================
Signal Name                             Unit    Description
=====================================   =====   =====================================================================================
kRackForceI_RackForceComfortRaw_xds16   N       rack force comfort raw 
vVehSpI_AbsAvgVehSpd_xdu16              km/h    Average vehicle speed. Goal: be as close to the actual speed over ground as possible.
kRackForceI_RackForceComfort_xds16      N       rack force comfort
xApplI_DegreeOfUndersteer_xdu16                 Degree of Understeer
xApplI_DegreeOfOversteer_xdu16                  Degree of Oversteer
kApplI_RackForce_xds16                  N       rack force 
fDsdI_BankedCurveDetected_xdb                   flag banked curve detection 1=banked curve detected 0=banked curve not detected
vApplI_SteeringAngleSpeed_xds16         Â°/s    Speed of the steering angle
=====================================   =====   =====================================================================================


Output Signals
--------------

=================================   ====   =======================
Signal Name                         Unit   Description
=================================   ====   =======================
vRackForceI_WindUpAdaption_xds32    N      WindUp out of adaptions
=================================   ====   =======================
 

Detailed Description
--------------------

The rack force module RackForce Comfort Adapt calculates windup adaption for calculation of rack force comfort under consideration of driving situations 
such as understeer,oversteer and banked curve



Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=========================================================   ======   ====================   =====================================================================
Parameter Name                                              Unit     Range                  Description
=========================================================   ======   ====================   =====================================================================    
xRackForceAdapt_SpOvSteerGain_XDU8                          m/s^2    0 .. 100               Setpoint oversteer gain
xRackForceAdapt_SwtDeactvGainOvSteer_XDU8                            0 .. 1                 deactivation oversteer adaption
xRackForceAdapt_GrdtLimRisngOvSteerGain_XDU16                        0 .. 1000000           positive gradient limitation of oversteer gain calculation
xRackForceAdapt_SpBankedCurveGain_XDU8                               0 .. 100               Setpoint banked curve gain
xRackForceAdapt_SwtDeactvGainBankedCurve_XDU8                        0 .. 1                 deactivation banked curve adaption
xRackForceAdapt_GrdtBankedCurveGain_XDU16                            0 .. 50                gradient limitation of banked curve calculation
xRackForceAdapt_SpUnderSteerGain_XDU8                                0 .. 100               Setpoint oversteer gain
xRackForceAdapt_SwtDeactvGainUnderSteer_XDU8                         0 .. 1                 deactivation understeer adaption
xRackForceAdapt_GainUnst4Hold_XDU16                                  0 .. 500               boundary value for hold understeer gain calculation
xRackForceAdapt_GrdtLimRisngUnSteerGain_XDU16                        0 .. 1000000           positive gradient limitation of Understeer gain calculation
xRackForceAdapt_ThdDeltaF_XDU8                                       0 .. 250               Threshold activation understeering threshold
xRackForceAdapt_SpGain_XDU16                                         0 .. 500               Setpoint overall gain
xRackForceAdapt_SwtDeactvGain_XDU8                                   0 .. 1                 deactivation overall gain adaption
xRackForceAdapt_GrdtLimRisngGain_XDU16                               0 .. 10000000          max. raising gradient overall gain
xRackForceAdapt_SatnMaxGain_XDU16                                    0 .. 500               max. overall gain valuee
xRackForceAdapt_SatnMinGain_XDU16                                    0 .. 500               min. overall gain value
xRackForceAdapt_SteerDegreeToNumGain_XDU8                            1 .. 100               multiplier applied to degree of steer for conversion into num steer
=========================================================   ======   ====================   =====================================================================

.. only:: confidential

   Provide a table of internal calibration parameters.
   
   ==================================================   ======   ====================   =========================================================================
   Parameter Name                                       Unit     Range                  Description
   ==================================================   ======   ====================   =========================================================================
   Axis_xRackForceAdapt_FiltFactRFMDAngSpeed_XAU16      Â°/s     0 .. 1500              Timeconstant PT1 Filter RFMD Value x calculation raster (default 0.001
   ==================================================   ======   ====================   =========================================================================


.. include:: RackForceV2_ComfortAdapt_CalMan_VT.irst

Stick Slip Warning
##################

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This function detects freezing water in the steering gear based on combination of various signal pattern and prevents blocking due to frozen water in the steering gear via generated shaking movements.

Block Diagram
=============

.. only:: confidential

   Main Function
   -------------
   .. image:: StickSlipWarning_CalMan_BlockDiagram.png

   Detail detection of StickSlip effect
   ------------------------------------
   .. image:: StickSlipEffect_blockDiagram.png

   Detail generation of feedback Torque
   ------------------------------------
   .. image:: GenerationofFeedbackTorque_blockDiagram.png
      :width: 20%


Input Signals
-------------

=================================== =====   ==========================================================================
Signal Name                         Unit    Description
=================================== =====   ==========================================================================
nApplI_RotorSpeedFilt_xds16         1/min   Filtered rotor speed
mApplI_TorsionBarTorque_xds16       Nm      HW LIB: torsion bar torque
mApplI_LimitedMotorTorque_xds16     Nm      Limited motor torque
vVehSpI_AbsMaxSafeVehSpd_xdu16      km/h    Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
xApplI_GearSign_xds8                        Sign of the steering gear
wApplI_SteeringAngle_xds16          °       Corrected steering angle
xtcActualTorqueRedLevel                     Active reduction for every channel
=================================== =====   ==========================================================================


Output Signals
--------------

=================================   ====   ===================================================================================================================
Signal Name                         Unit   Description
=================================   ====   ===================================================================================================================
mApplI_SSWarnTorque_xds16           Nm     Stick slip warn torque
fSSWarnI_VibrationEnabled_xdu8             Signal for persistent storage indicating that the 'anti freeze action' shall be enabled again in the next key cycle
=================================   ====   ===================================================================================================================

.. only:: confidential

   =================================   ====   ===========================================
   Signal Name [Internal]              Unit   Description
   =================================   ====   ===========================================
   sSSWarnI_ErrLvl_xdu8                       Error level of StickSlipWarning
   sSSWarnI_ErrLvl_Red_xdu8                   Error level of StickSlipWarning (Redundant)   
   =================================   ====   ===========================================

Detailed Description
--------------------

Freezing water in the steering gear can possibly block the steering. Freezing water in the steering gear causes stick slip effects which could be recognized through patterns.
These effects are detected in the rotorspeed signal through the detection part of the Stick Slip Warning functionality. If an applicable number of stick slip effects is detected
within a defined period of time, the function generates a feedback torque (shaking movement which contribute to the corresponding ice to be melted) that prevents the steering gear from freezing.
The feedback torque is ramped in and has an applicable frequency and amplitude. Once freezing water is detected, the feedback torque ramps in at startup even over the following keycycles until the car is serviced at the garage. 

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

======================================   =====   =============   =======================================================================
Parameter Name                           Unit    Range           Description
======================================   =====   =============   =======================================================================
xSSWarn_RotorSpeedFilter_XDU16                   0 .. 1          Constant for rotor speed filter
nSSWarn_RotSpeedLow_XDU16                1/min   0 .. 70         Lower border for rotor speed
nSSWarn_RotSpeedHigh_XDU16               1/min   0 .. 1000       Upper border for rotor speed
vSSWarn_MinVehicleSpeed_XDU16            km/h    0 .. 200        Lower limit for vehicle speed
wSSWarn_MaxSteeringAngle_XDU16           °       0 .. 500        Upper limit for steering angle
tSSWarn_TimeMaxNnotZero_XDU16            ms      0 .. 5000       Time border for state 'RotSpeedNotZero' 
tSSWarn_TimeMinNLow_XDU16                ms      0 .. 5000       Minimum time for low rotor speed      
tSSWarn_TimeMaxNHigh_XDU16               ms      0 .. 5000       Maximum time for high rotor speed  
tSSWarn_MaxDeltaTime_XDU16               ms      0 .. 5000       Time till Effective Torque Delta is reached
mSSWarn_DeltaEffectiveTorque_XDU16       Nm      0 .. 10         Delta Effective Torque Limit
mSSWarn_EffTrqLow_XDU16                  Nm      0 .. 6          SSW_M1
mSSWarn_EffTrqHigh_XDU16                 Nm      0 .. 6          SSW_M3
xSSWarn_ReductionGradient_XDU16                  0 .. 1          Reduction Ramp gradient
xSSWarn_ReductionLevel_XDU16                     0 .. 1          Reduction level 0 - 1 [0 - 100%]
tSSWarn_MaxAllowedReductionTime_XDU16    ms      0 .. 10000      Maximum allowed reduction time
tSSWarn_ResetStickSlipTime_XDU16         s       55 .. 65        Reset-time for stick-slip-counter 
**Prevention torque:**
mSSWarn_SSFeedbackTorque_XDU16           Nm      0 .. 6          Anti-stick-slip torque
zSSWarn_SSCounterMax_XDU16                       0 .. 20000      amount of stick-slip-counts for activation anti-stick-slip-torque 
tSSWarn_VibrationRampTime_XDU16          ms      1800 .. 2200    Vibration Ramp Time
tSSWarn_VibrationPause_XDU16             ms      0 .. 62         Vibration Pause
tSSWarn_VibrationPeriod_XDU8             ms      45 .. 65        Period of anti-stick-slip-torque
**Plausi:**  
mSSWarn_MaxFeedbackTorque_XDF32          Nm      0 .. 2          Anti-stick-slip torque limit from which on an error-integral will start
mSSWarn_MaxFeedbackTorqueDT_XDF32                0 .. 100        Limit for anti-stick-slip-torque integral-error
======================================   =====   =============   =======================================================================

.. only:: confidential

   Internal Calibration Parameters
   -------------------------------

   ======================================   =====   =========   =========================================================================================
   Parameter Name                           Unit    Range       Description
   ======================================   =====   =========   =========================================================================================
   xsyRatioEfficiency_XDU16                         0 .. 0.2    Scaling factor for torsion bar torque to motor torque (system parameter of steering gear)
   ======================================   =====   =========   =========================================================================================

.. include:: StickSlipWarning_CalMan_VT.irst

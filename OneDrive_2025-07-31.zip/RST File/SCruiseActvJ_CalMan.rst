Smart Cruise Steer Torque | Active Inertia
##########################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component provides an active inertia torque as an nominal steering torque.
It is an inertia modification due to the fact that the torque can be compensating or supporting the inertia.
Means the gain factor can be positive and also negative.

The intention of this component is to have its own independent inertia modification within Smart Cruise Interface.

Block Diagram
=============

.. only:: confidential

   .. image:: SCruiseActvJ_CalMan_BlockDiagram.png

.. only:: not confidential

   .. image:: SCruiseActvJ_CalMan_BlockDiagram_Customer.png

Input Signals
-------------

==============================   ========   ====================================================================================================
Signal Name                      Unit       Description
==============================   ========   ====================================================================================================
aSCruiseI_RotAccel_xds16         1/min/ms   SCruise mapped filtered rotor acceleration, gear sign adjusted
mSCruiseI_TorsBarTrq_xds16       Nm         Torsion bar torque for SCruise
vSCruiseI_AbsAvgVehSpd_xdu16     km/h       SCruise mapped average vehicle speed. Goal: be as close to the actual speed over ground as possible.
==============================   ========   ====================================================================================================

.. only:: confidential

   ==============================   ========   ====================================================================================================
   Signal Name                      Unit       Description
   ==============================   ========   ====================================================================================================
   xSCruiseI_HandsOnFadrFac_xdu16   --         Fading factor from HandsOn (1) to HandsFree (0)
   xSCruiseI_StfnFac_xdu16          --         Rate limited stiffness factor for SCruise, received from bus
   ==============================   ========   ====================================================================================================

Output Signals
--------------

===========================   ====   ========================================
Signal Name                   Unit   Description
===========================   ====   ========================================
mSCruiseI_NomActvJTrq_xds16   Nm     Nominal active inertia torque of SCruise
===========================   ====   ========================================


Detailed Description
--------------------

The inertia torque will be calculated analog to Steering Feel Assistance' one:
rotor acceleration multiplied with a vehicle speed dependent gain factor
and a reduction over the torsion bar torque.

.. only:: confidential

   Additionally:

   - the inertia torque is linearly scaled with the stiffness factor, in case this behavior is enabled
     via calibration

   - increased inertia torque is required in HandsFree mode due to its steeper curves
     in SCruiseNomDrvrTrqCalcn


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

=======================================   ====   =======   =====================================================
Parameter Name                            Unit   Range     Description
=======================================   ====   =======   =====================================================
mSCruise_ActvJMaxTrqVehSpd_XAU16          Nm     0..10     maximum inertia torque dependent on vehicle speed
xSCruise_ActvJFacTrq_XAU16                --     0..1      active inertia factor dependent on TorsionBarTorque
xSCruise_ActvJFacVehSpd_XAU16             --     0..10     gain factor of inertia dependent on vehicle speed
=======================================   ====   =======   =====================================================

.. only:: confidential

   =======================================   ====   =======   =====================================================
   Parameter Name                            Unit   Range     Description
   =======================================   ====   =======   =====================================================
   xSCruise_ActvJFacModChg_XAU16             --     0..2      active inertia factor dependent on HandsOn/-Free
   fSCruise_DampgAndJTrqDpdtOnStfnFac_XDU8   --     0; 1      flag to enable dependency of damping (in component
                                                              SCruiseDampg) and inertia torque on stiffness factor
                                                              (both torque values will be scaled with stiffness
                                                              factor).
   =======================================   ====   =======   =====================================================

   .. include:: SCruiseActvJ_CalMan_VT.irst

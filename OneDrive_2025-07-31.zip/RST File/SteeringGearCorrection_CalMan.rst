SteeringGearCorrection
#######################

Short Description
=================

The Steering Gear correction component updates the I-var correction factor.


.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!
   

Block Diagram
=============

.. only:: confidential

 .. image:: SteeringGearCorrection_CalMan_BlockDiagram.png


Input Signals
-------------

=====================================        =======   =========================================================================================
Signal Name                                  Unit      Description
=====================================        =======   =========================================================================================
sApplI_SteeringAngleState_xdu8                 -        The steering angle state.
wApplI_PinionAngle_xds16                       °        The pinion angle value is provided.
=====================================        =======   =========================================================================================


Output Signals
--------------

=====================================        =======   =========================================================================================
Signal Name                                  Unit      Description
=====================================        =======   =========================================================================================
xSgcI_Torque2RackForceCorrFact_xdu16           -        I-Var correction factor for rack force.
xSgcI_TorqueCorrFact_xdu16                     -        I-Var correction factor for final torque.
xSgcI_RatioMot2RackCorrFact_xdu16              -        I-Var correction factor for rack speed.
=====================================        =======   =========================================================================================


Detailed Description
--------------------
The SteeringGearCorrection component updates the I-var correction factor for final torque, rack force and rack speed with the available tuning ranges subject to applied uprate and downrate limitation.
The factor remains 1 for constant gear ratio and the variable gear ratio needs the correction factor as the relationship between torque and rack force will not be linear.

Calibration/Application Parameters
==================================
   
============================================================     =====   ===========================     =============================================================================================
Parameter Name                                                   Unit    Range                           Description
============================================================     =====   ===========================     =============================================================================================
wSgc_PinionAngleArray_XAU16                                      °       0.. 1000                        Pinion angle array at defined sample points to take care of I-var
xSgc_InvCorrectionFactorMot2Rack_XAU16                           -       0.5.. 1.0                       Rack force correction factor array at defined sample points to take care of I-var
xSgc_CorrectionFactorMot2Rack_XAU16                              -       1 ..1.5                         Torque  and rack speed correction factor array at defined sample points to take care of I-var
xSgc_UprateTorqueCorrFactor_XDS16                                -       0.000976562525 ..2              Uprate limit for I-Var correction factor for final torque
xSgc_DownrateTorqueCorrFactor_XDS16                              -       -2 ..-0.0009765625              Downrate limit for I-Var correction factor for final torque
xSgc_UprateRatioMot2RackCorrFactor_XDS16                         -       0.0009765625 ..2                Uprate limit for I-Var correction factor for rack speed
xSgc_DownrateRatioMot2RackCorrFactor_XDS16                       -       -2 ..-0.0009765625              Downrate limit for I-Var correction factor for rack speed
xSgc_UprateTorque2RackForceCorrFactor_XDS16                      -       0.0009765625 ..1                Uprate limit for rack force I-var correction factor
xSgc_DownrateTorque2RackForceCorrFactor_XDS16                    -       -1 ..-0.0009765625              Downrate limit for rack force I-var correction factor
============================================================     =====   ===========================     =============================================================================================
  
.. include:: SteeringGearCorrection_CalMan_VT.irst
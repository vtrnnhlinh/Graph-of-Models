Center Feel Torque
##################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The center feel function applies an additional handwheel torque depending on the steering angle.

The center feel constitutes the steering behaviour from the centre. The steering behaviour can be influenced independently of the rack force by using the steering wheel angle.
The vehicle speed is used to adjust the steering behaviour to the vehicle speed


Block Diagram
=============

.. only:: confidential

   .. image:: CenterFeelTorque_CalMan_BlockDiagram.png


Input Signals
-------------

===================================  ===== =========================================================================================================
Signal Name                           Unit Description
===================================  ===== =========================================================================================================
sApplI_SteeringAngleState_xdu8             state of steering angle / rackposition: 0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit
sApplI_VehicleSpeedState_xdu8              Validflag for vehicle speed vApplI_AbsVehicleSpeedFilt_xdu16 (1 = valid; 0 = invalid or substitute speed)
vApplI_AbsVehicleSpeedFilt_xdu16     km/h  Abs. vehicle speed: processed
wApplI_DynSteerAngle_xds16           °     dynamic steering angle (sum of attitude and steering wheel angle)
xFactMinI_ActiveRetFuncFactor_xdu16        Requested active return function factor
===================================  ===== =========================================================================================================


Output Signals
--------------

===================================   ====   ==========================
Signal Name                           Unit   Description
===================================   ====   ==========================
mCentFeelI_NominalSteerTorque_xds16   Nm     nominal center feel torque
===================================   ====   ==========================


Detailed Description
--------------------

The progression of the torque when steering from the center steering wheel position and consequently the center feel can be influenced
in a targeted way by the application of the center feel. The center feel torque acts like a restoring force similar to that of an undamped
spring because of the progression. Attention should be paid to keeping too much "dead steering" from being perceptible during active steering 
through the zero point of the steering angle when the increase and amount of the center feel torque are applied. A speed-dependent spread of 
the center feel torque can be achieved by applying the characteristic curve in dependence upon the vehicle speed. Since this function works with 
reference to the angle, it only feels plausible when the position of the steering wheel in a straightaway position corresponds to the force minimum of the axle.
In special situations (e.g. oversteering), the natural behavior of the axle will be distorted without special measures (dynamic return)..


Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

====================================   ====   =====   =============================================================
Parameter Name                         Unit   Range   Description
====================================   ====   =====   =============================================================
mCentFeel_MaxCenterFeelTorque_XDU16    Nm     0..1    maximum center feel torque
mCentFeel_NormCenterFeelTorque_XAU16   Nm     0..1    dynamic steering angle dependent factor of center feel torque
xCentFeel_CenterFeelTorqueFact_XAU16          0..1    vehicle speed dependent factor of center feel torque
====================================   ====   =====   =============================================================


.. include:: CenterFeelTorque_CalMan_VT.irst

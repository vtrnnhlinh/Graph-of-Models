RackPosOffsetSum
#########################

Short Description
=================
RackPosOffsetSum calculates the sum of all external offsets when they are valid.
If one of the offset becomes invalid the OffsetSum will be set to SNA for the rest of
the ignition cycle

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RackPosOffsetSum.PNG

   Input Signals
   -------------

   =====================================================   ==========   =========   ============================================================================================
   Signal Name                                             Unit         Range       Description
   =====================================================   ==========   =========   ============================================================================================
   lEpsInI_RackPosOffset_xds16                             mm           -200 200     Rack Position Offset
   =====================================================   ==========   =========   ============================================================================================

   Output Signals
   --------------

   =====================================================   ==========   =========   ============================================================================================
   Signal Name                                             Unit         Range       Description
   =====================================================   ==========   =========   ============================================================================================
   lRocI_InvalidOffsetSum_xds16                            mm           -200 200    Sum of Invalid RackPositionOffset
   lRocI_DSMReqOffset_xds16                                mm           -200 200    limited motor torque for check component
   =====================================================   ==========   =========   ============================================================================================

   Detailed Description
   --------------------
   RackPosOffSetSum calculates the sum of all external offsets when they are valid.
   If one of the offset becomes invalid the OffSetSum will be set to SNA for the rest of
   the ignition cycle

.. include:: RackPosOffsetSum_CalMan_VT.irst

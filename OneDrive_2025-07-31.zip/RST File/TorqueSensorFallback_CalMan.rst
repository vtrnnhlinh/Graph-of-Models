﻿TorqueSensorFallback
#####################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

If both channels of the TBT become defect, the function TorqueSensorFallback will freeze the last valid value and set the motor torque to plausible value.
From this value the motor torque will ramp down to 0 Nm.
If both channels are OK the input motor torque will be forwarded to the output motor torque.

The check component checks the calculated motor torque and in case of a fault the torque will be set to zero immediately.




Block Diagram
=============

.. image:: TorqueSensorFallback_CalMan_BlockDiagram.png


Input Signals
-------------

============================================   ====   ==============================================================================
Signal Name                                    Unit   Description
============================================   ====   ==============================================================================
sHwlWrapI_TorsionBarTorqueState_xde		               TBT sensor state from HWL
mFaderConnMotTrqSumI_MotTrq_xds16              Nm     Summation of all input motor torques of FaderConnMotTrqSum
wApplI_SteeringAngle_xds16                     °      corrected steering angle
xApplI_GearSign_xds8                                  sign of the steering gear
xHwlWrapI_MinRedLevel_xdu16                           Current minimum reduction factor
nApplI_RotorSpeed_xds16                        1/s    unfiltered rotor speed
============================================   ====   ==============================================================================


Output Signals
--------------

=================================   ====   ===================================================================
Signal Name                         Unit   Description
=================================   ====   ===================================================================
mTsfI_MotorTorque4Check_xds16        Nm    motor torque to the check component
=================================   ====   ===================================================================

.. only:: confidential

   =================================   ======   ========================
   Signal Name [Internal]              Unit     Description
   =================================   ======   ========================
   nTsf_AbsRotorSpeed_xdu16            1/min    abs value of rotorspeed
   =================================   ======   ========================


Detailed Description
--------------------

This function should freeze the last valid motor torque and set this value to an application value and
ramp this value down to zero in case of both torque sensors are defect.

.. only:: confidential

   **Main component**

   *SafeLastValidValue:*
   This subsystem freeze the last value after both channels of the TBT sensor are defect.

   *CalcMaxMotTrq:*
   This subsystem calculate the max required motor torque for the HWL.

   *CalcAngleTorqueGearSignValue:*
   This subsystem calculate a value depends of the steerangle, motor torque and the gearsign value.

*SteerAngleRangeIdentification:*
This subsystem sends the signal (xTsf_SteerAngleInRange = 1) to the rampdown subsystem, which sets
the torque to zero, when the steering angle is inside the range of wTsf_SteeringAngleDeactvnThd_XDU16 (+20...-20).

*RotorSpeedFuncOff:*
This subsystem provides a factor (0..1), that decreases if the product of rotorspeed and motor torque is negativ.
The factor depends on the rotorspeed and can be tuned with curve xTsf_RotSpeedCurveFact_XAU16. It is needed for countersteer when cornering.

   *RampDown:*
   Inside this subsystem the calculated motor torque will be ramped down to zero or if the the product of the gearsign, steering angle
   and the motor torque is equal or lesser than zero the output will be set immediately to zero. Also the motor torque will ramp down
   when the driver countersteer within a curve.

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!


===============================================   =====   ========   ===================================================================================================
Parameter Name                                    Unit    Range      Description
===============================================   =====   ========   ===================================================================================================
mTsf_MaxTorqValue_XDU16                           Nm      0..1.2     max. allowed error motor torq from HWL
xTsf_RampGradient_XDU16                           Nm/ms   0..1       ramp gradient in Nm/ms
xTsf_RotSpeedCurveFact_XAU16                              0..1       Rotor Speed Curve factor between 1..0. The factor depends on the rotor speed.
wTsf_SteeringAngleDeactvnThd_XDU16                °       0..1000    SteeringAngle threshold to deactivate TorqueSensorFallback when steering back to center
===============================================   =====   ========   ===================================================================================================


.. include:: TorqueSensorFallback_CalMan_VT.irst

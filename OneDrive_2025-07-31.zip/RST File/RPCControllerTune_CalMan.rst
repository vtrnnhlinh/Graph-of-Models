﻿RPCControllerTune
###################

Short Description
=================

The Component RPCControllerTune provides possibility to tune the functionality RackPositionControl.
It is used to overwrite the nominal rackposition or the nominal rackspeed with special signal behaviour to enable a tuning of the RackPositionController
in the vehicle.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RPCControllerTune.PNG

   Detailed Description
   ====================
   If the controller parameters cannot be determined analytically, RPCControllerTune provides the possiblity to determine the Parameters
   for the inner controller cascade (rackspeed controller) as well as the parameters for the outer controller cascade (rackposition controller) in car.
   The tuning function makes it possible to generate signals for the desired rack position or the desired rackspeed, and to evaluate and tune the controller
   performance based on the measured following behavior. The same RPCControllerTune module can be used for tuning both HAD and SRA RackPostionControl.

   *Hint: The interfaces for HAD and SRA are configured within the component via macro IS_SRA. If the macro IS_SRA is defined then the ControllerTune will use
   the SRA interfaces, else inputs for EPS HAD is used.*


   Input Signals
   =============

      .. note:: The following interfaces are only applicable for EPS HAD

      ======================================    ==========    ===========    =============================================================================================================
      Signal Name                               Unit          Range          Description
      ======================================    ==========    ===========    =============================================================================================================
      fHADI_Enable_xdu8                         n.a           0..1           Flag for the activation of the RPC controller at RPC-mode
      lRpHADI_RackPosition_xds16                mm            -200..200      Current rack position for HAD mode
      lEpsInI_HadRequestedRackPosition_xds16    mm            -200..200      Requested rack position for HAD mode
      ======================================    ==========    ===========    =============================================================================================================

      .. note:: The following interfaces are only applicable for SRA

      ======================================    ==========    ===========    =============================================================================================================
      Signal Name                               Unit          Range          Description
      ======================================    ==========    ===========    =============================================================================================================
      fRPCI_Activate_xdu8                       n.a           0..1           Flag for the activation of the RPC controller in SRA
      lAppI_RackPosition_xds16                  mm            -200..200      Current rack position
      lTpcI_ReqRackPosition_xds16               mm            -200..200      Requested rack position from SWA
      ======================================    ==========    ===========    =============================================================================================================


   Output Signals
   ==============
      =========================================================   =========   ==========   ===============================================================================================
      Signal Name                                                 Unit        Range        Description
      =========================================================   =========   ==========   ===============================================================================================
      vRPCI_NominalRackSpeedLimited_xds16                         mm/s        -250..250    Nominal rack speed limited (overwrite orig. signal)
      =========================================================   =========   ==========   ===============================================================================================

      .. note:: The following interfaces are applicable for EPS HAD

      =========================================================   =========   ==========   ===============================================================================================
      Signal Name                                                 Unit        Range        Description
      =========================================================   =========   ==========   ===============================================================================================
      lRPCI_NominalRackPositionPreFilter_xds16                    mm          -200..200    Nominal Rack Position after limitation and interpolation (overwrite orig. signal)
      =========================================================   =========   ==========   ===============================================================================================

      .. note:: The following interfaces are applicable for SRA

      =========================================================   =========   ==========   ===============================================================================================
      Signal Name                                                 Unit        Range        Description
      =========================================================   =========   ==========   ===============================================================================================
      lTpcI_ReqRackPosition_xds16                                 mm          -200..200    Requested rack position for SRA (overwrite orig. signal)
      =========================================================   =========   ==========   ===============================================================================================


   Internal Signals
   ================
   =========================================================   ====   ==========   ===============================================================================================
   Signal Name                                                 Unit   Range        Description
   =========================================================   ====   ==========   ===============================================================================================
   sRPC_TuningMode_xdu8                                        n.a    0..51        Tuning Mode (hold = 0, TuneRackPos = 1, TuneSpeed = 2, TuenSpeedExt = 3, notuning = 4, locked = 50/51")
   zRPC_CounterHold_xdu16                                      n.a    0..65535     RPC tuning counter
   lRPC_NominalRackPositionTune_xds32                          mm     -200..200    Nominal rack position from tune module
   vRPC_NominalRackSpeedTune_xds16                             mm/s   -250..250    Nominal rack speed from tune module
   =========================================================   ====   ==========   ===============================================================================================


   Calibration/Application Parameters
   ==================================
   Internal calibration parameters.

   =================================================          ==========   ======================   ========================================================================================
   Parameter Name                                             unit         Range                    Description
   =================================================          ==========   ======================   ========================================================================================
   sRPC_TuneController_XDU8                                   n.a          0..3                     Tune controller: 0 = No, 1 = Position, 2 = Speed, 3 = Map NomRackPosRaw to NomRackSpeed
   lRPC_NominalRackPositionTolerance_XDS8                     mm           -1..1                    Nominal rack position tolerance
   lRPC_NominalRackPositionUp_XDS16                           mm           -200..200                Nominal rack position upper bound
   lRPC_NominalRackPositionDown_XDS16                         mm           -200..200                Nominal rack position lower bound
   vRPC_NominalRackSpeedTune_XDU16                            mm/s         -250..250                Nominal rack speed tune values
   tRPC_TimeHold_XDU16                                        ms           0..65535                 Tuning hold time
   =================================================          ==========   ======================   ========================================================================================

   .. note:: The following parameter is applicable for SRA

   =================================================          ==========   ======================   ========================================================================================
   Parameter Name                                             unit         Range                    Description
   =================================================          ==========   ======================   ========================================================================================
   lRPC_ReqRackPosDelta4DriverMon_XDU16                       mm           0..200                   Only SRA: deactivation threshold for tuning
   =================================================          ==========   ======================   ========================================================================================


   Prerequisites before tuning (Applicable only for EPS HAD)
   =========================================================

   Before starting the tuning of the controllers in EPS HAD system, following parameters has to be adapted accrodingly.

   **1. Deactivate Monitoring Functions:**

      The monitoring function should be deactivated to ensure that the controller does not switch continuously to SFC mode.

      =========================================================   =====  ===============================================================================================
      Paramter Name                                               Value  Comment
      =========================================================   =====  ===============================================================================================
      mTBTMon_MaxTorque_XDU16                                     8Nm    Do not disable TBTMon, instead apply very robust setting
      fRackSpMon_EnableRackSpMonitoring_XDU8                      0      Disable RackSpeedMonitoring
      =========================================================   =====  ===============================================================================================

      *Hint: The other option is to deactivate the SafetyDriver completely via fSafDrv_Configuration_XDU8*

   **2. Deactivate/Expand Controller Limits:**

      To ensure that the performance during the tuning is not influenced by dynamic restrictions due to the SafetyDriver, the limit values are widened.

      =========================================================   =========  ===============================================================================================
      Paramter Name                                               Value      Comment
      =========================================================   =========  ===============================================================================================
      fRPC_EnableInputLimitation_XDU8                             0          Disable InputLimitation
      **(OR)**
      lRPC_LowDynMaxRackPosAtInputLimiter_XAU16                   70-80mm    Set smaller values as EndStop
      vRPC_LowDynMaxRackSpdAtInputLimiter_XAU16                   100mm/s    Large value, which is normally not exceeded
      =========================================================   =========  ===============================================================================================

      =========================================================   =======  ===============================================================================================
      Paramter Name                                               Value    Comment
      =========================================================   =======  ===============================================================================================
      fRPC_EnableRackSpeedLimitation_XDU8                         0        Disable RackSpeedLimitation
      **(OR)**
      vRPC_MaxRackSpeedDepOnVehSpeed_XAU16                        100mm/s  Increase valid rack speed range
      =========================================================   =======  ===============================================================================================

      =========================================================   =======  ===============================================================================================
      Paramter Name                                               Value    Comment
      =========================================================   =======  ===============================================================================================
      fRPC_EnableMotorTorqueLimitation_XDU8                       0        Disable MotorTorqueLimitation
      **(OR)**
      mRPC_MaxMotorTorqueDepOnVehSpeed_XAU16                      8Nm      Increase valid motor torque range
      =========================================================   =======  ===============================================================================================

      =========================================================   =======  ===============================================================================================
      Paramter Name                                               Value    Comment
      =========================================================   =======  ===============================================================================================
      vRPC_MaxGradRackSpeed_XDU16                                 5mm/s    High value for rack acceleration
      =========================================================   =======  ===============================================================================================

   **3. Deactivate Feed Forward Path:**

      In addition to the rack position controller, the outer control loop also has a feedforward control part.
      It uses the derivation of the desired rack position as additional input for the rack-speed controller.
      For tuning the PID-parameters of rack position controller, disable this feedforward part.

      =========================================================   =======  ===============================================================================================
      Paramter Name                                               Value    Comment
      =========================================================   =======  ===============================================================================================
      fRPC_EnableNominalRackPositionDerivative_XDU8               0        For tuning the rack position controller, disable this feedforward part.
      =========================================================   =======  ===============================================================================================


   Tuning of the Controllers
   =========================

   1. Tuning Rack Speed Controller (Inner Controller)
   --------------------------------------------------

      .. image:: RackSpeedController.PNG

      First, the inner cascade loop is tuned. In the inner cascade a PID controller is implemented but usually only the P and I value is used.

      Typical controller parameters for APA-steering:
            =========================================================   ======================
            Paramter Name                                               Value
            =========================================================   ======================
            xRPC_RackSpeedCtrlP_XDF32                                   0.04-0.08 [Nm*s/mm]
            xRPC_RackSpeedCtrlI_XDF32                                   0.5-2 [Nm/mm]
            xRPC_RackSpeedCtrlD_XDF32                                   0 [Nm*s^2/mm]
            =========================================================   ======================

      If rack speed tuning is active by setting the sRPC_TuneController_XDU8 = 2 the following program will be executed:

      A target rack speed is specified, which is controlled until the actual rack position exceeds an upper threshold (IRPC_NominalRackPositionUp_XDS16).
      When the threshold is reached, the target rack speed is set to zero for a short time (tRPC_TimeHold_XDU16).
      Thereafter, the target rack speed changes the direction until a lower threshold (lRPC_NominalRackPositionDown_XDS16) is again reached.
      When the threshold is reached, the target rack speed is set to zero again for a short time (tRPC_TimeHold_XDU16).
      This procedure is repeated several times (zRPC_Cycles_XDU8).

      .. image:: RackSpeedTuning.PNG

      The tuning of the controller parameters shall be done at vehicle speeds between 3-20km/h.
      The case “vehicle stands” is not that important (due to high tire friction).
      While the tuning module repeatedly generates steps in nominal rack speed, the PI(D)-parameters can be changed and the effect on the
      actual rack speed can be evaluated. Tune the PI(D)-parameters untill you are satisfied with the step-response.

      *Hint: It should be sufficient to only tune P- and I-Part of the rackspeed controller.*

      Below is the Step responses of rack speed at vehicle speed 5km/h

      .. image:: RackSpeedStepResponse.png

   1.1 Validation of Rack Speed Controller Tuning
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

      After tuning of the PI(D)-parameters is done:
      To check the performance again, the bus signal for demanded rack position can be mapped directly as nominal rack speed by setting sRPC_TuneController_XDU8 = 3.
      In this case the requested rack position is interpreted as requested rackspeed (1mm ≙ 1mm/s)
      Apply a sinusoidal signal via Restbus-Simulation and send it to the EPS/SRA (e.g. with frequency from 1 to 5 Hz and amplitude 1mm/s to 100mm/s) and
      check the controller performance (see Abbildung 10).

      .. warning:: Start with low amplitudes first!

      Below is the Sinusoidal nominal rack speed (1-5Hz) to verify performance

      .. image:: RackSpeedPerformance.png

   2. Tuning Rack Position Controller (Outer Controller)
   -----------------------------------------------------

      .. image:: RackPosController.PNG

      If the tuning of the internal control casade (RackSpeedController) is finished, the external control cascade has to be configured.
      The PID Controller usually only uses the P Parameter for setting up the RackPosition-controller.

      Typical controller parameters for APA-steering:
            =========================================================   ======================
            Paramter Name                                               Value
            =========================================================   ======================
            xRPC_RackPosCtrlP_XDF32                                     4-25 [1/s]
            xRPC_RackPosCtrlI_XDF32                                     0 [1/s^2]
            xRPC_RackPosCtrlD_XDF32                                     0
            =========================================================   ======================

      If tuning of the RackPosition is activated via sRPC_TuneController_XDU8 = 1, the following program is executed:

      *A ramp is set to reach the upper target rack position (lRPC_NominalRackPositionUp_XDS16) with target rack speed (vRPC_NominalRackSpeedTune_XDU32).
      As soon as the actual rack position reaches the target rack position, the system waits for a time (tRPC_TimeHold_XDU16) until the actual rack position
      comes to rest. Subsequently, a ramp to reach the the lower target rack position (lRPC_NominalRackPositionDown_XDS16) is set using again
      target rack speed (vRPC_NominalRackSpeedTune_XDU32).*

      .. image:: RackPosTuning.PNG

      The tuning of the controller parameters should be done at a vehicle speed between 3 and 20 km / h.
      The case “vehicle stands” is not that important (due to high tire friction). Ramps with very high rack speeds (100mm/s) are similar to a step.
      In case of an already tuned rack-speed controller, the response behavior in rack position resamples approximately a PT1 behavior.
      The time constant of the PT1 behavior can be changed by tuning the P-part of the rack position controller (xRPC_RackPosCtrlP_XDF32).

      *Hint: It should be sufficient to only tune P- Part of the rackpos controller.*

      Below is the Step responses of rack pos with increasing P part

      .. image:: RackPosStepResponse.png

   2.1 Tune feed forward of rack position derivative
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

      After tuning the rack position controller P(ID)-parameters only if the performance is not fast enough,
      enable the feedforward part again (fRPC_EnableNominalRackPositionDerivative_XDU8 = 1) and set qRPC_FiltFreqNominalRackPositionForDerivative_XDU16 to max.
      value (In case controller runs e.g. in 10ms task, set FiltFreq to 1/0.01s=100Hz) and xRPC_DerivativeRackSpeedFactor_XDU16 = 1.
      qRPC_FiltFreqNominalRackPositionForDerivative_XDU16 is the time constant of a PT1-filter for the derivation and
      xRPC_DerivativeRackSpeedFactor_XDU16 is a weight-factor for the derivation.

      Disable the rack position controller (Set the PID-part of rack position controller (not rack speed controller!) to zero).

      Now a sinusoidal signal for nominal rack position raw can be applied via bus (frequency 0.5-2Hz).
      Check whether the requested nominal rack position is derivated correct.
      The derivation (vRPC_NominalRackPositionDerivative_xds16) should have a 90 ° phase to the desired rack position and have the following amplitude: 2*pi*f*A_Rackpos

      .. image:: RackPosFeedForwardTuning.png

      .. warning:: Known issue with calculation of rack position derivation:

         Derivation is not calculated correct because controller is executed in different task than EPSInput (steering sometimes starts to vibrate acoustically).
         E.g. amplitude is twice as high as expected or strong “noise”.

         If derivation is noisy, you have two options:

            #. Activate inputinterpolation (Recommended)
                  - **HAD:** Increase zRPC_NumElementsMovingAverage_XDU8 and set fRPC_EnableInputInterpolation_XDU8 = 1
                  - **SRA:** Increase zSWRCon_ReqRackPosNumElementsMovingAverage_XDU8
            #. Lowpass-filter the demanded rackposition
                  Use the PT1-filter to smoothen the derivation (Decrease qRPC_FiltFreqNominalRackPositionForDerivative_XDU16).
                  But be careful that the phase between nominal rack position and its derivation does not become much higher than 90° for frequencies up to 5Hz
                  due to high filtering


   2.2 Validation of Rack Position Controller Tuning
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

      To validate the configured controller, the Tune module shall be switched off (sRPC_TuneController_XDU8=0).
      Only if high performance is needed, the feedforward part of the derivation shall be enabled, (fRPC_EnableNominalRackPositionDerivative_XDU8 = 1)
      The P(ID)-parts of the rack position controller shall be set to their tuned values.
      Now a sinusoidal signal can be added via bus (frequency 0.5-2Hz) and the performance can be checked again.
      If overshoot is too much, xRPC_DerivativeRackSpeedFactor can be set to a value smaller than 1.

      Below is the Sinusoidal nominal rack speed (1-5Hz) to verify performance

      .. image:: RackPosPerformance.png

   Robusteness Check
   =================

   To ensure that the controller tuning is robust, slowly steer from endstop to endstop while car is at stand still
   and while car is on hoist. The controller shall not start to show instabilities like vibrating around the target value.

   .. warning:: Don’t steer into the endstop

   Limitation of the dynamics (SafetyDriver, Applicable only for HAD)
   ==================================================================

   To ensure that the SafetyDriver can handle the controller, the tuned controller must be restricted in dynamics again.
   To get the restriction data, the vehicle test department has to do release-tests.

   Safety: Deactivation of Tune module
   ===================================
   **EPS HAD:**
      If you need to get back the control over the car while the Tuning modul is active, just end the HAD-mode via TBT-Mon by applying a torsionbar torque.
      The tuning modul is deactivated together with the HAD-mode.

   **SRA:**
      If you need to get back the control over the car while the Tuning modul is active, just change the requested angle that is send to the SRA (by changing the steering angle of the SWA).
      The tuning is deactivated if the steering angle of the SWA changes more than lRPC_ReqRackPosDelta4DriverMon_XDU16 compared to the value when you activated the tuning.
      After deactivation of the tune module by changing the steering angle of the SWA, the SRA is following the SWA,
      but there might be an offset between requested rackpos and actual rackpos which gets ramped out with further steering wheel movement.

.. include:: RPCControllerTune_CalMan_VT.irst

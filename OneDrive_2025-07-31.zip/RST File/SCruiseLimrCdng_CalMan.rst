.. only:: not confidential

   Smart Cruise Limiter | Conditioning
   ######################################

   The component checks inputs regarding validity and sets substitute values if necessary.

.. only:: confidential

   Smart Cruise Limiter | Conditioning
   ######################################

   .. warning:: This document is classified as **confidential**! Do not distribute!


   Short Description
   =================

   The limiter signal conditioning checks inputs regarding validity, sets substitute values and triggers a fade-out if necessary. Additionally it calculates a TBT gradient.


   Block Diagram
   =============

   .. image:: SCruiseLimrCdng_CalMan_BlockDiagram.png


   Input Signals
   -------------

   ==============================   ====   =================================================================================
   Signal Name                      Unit   Description
   ==============================   ====   =================================================================================
   mApplI_TorsionBarTorque_xds16    Nm     HW LIB: torsion bar torque
   mSCruiseI_MotTrq_xds16           Nm     MotorTorque requested by the SCruiseController
   vVehSpI_AbsMaxSafeVehSpd_xdu16   km/h   Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
   vVehSpI_AbsMinSafeVehSpd_xdu16   km/h   Minimum vehicle speed. Goal: actual speed over ground >= AbsMinSafeVehSpd.
   ==============================   ====   =================================================================================


   Output Signals
   --------------

   ======================================   =====   =====================================================================================
   Signal Name                              Unit    Description
   ======================================   =====   =====================================================================================
   fSCruiseLimrI_ReqOff_xdb                         Request off (fade-out) in case of invalid inputs
   mSCruiseLimrI_GradTorsBarTrq_xds16       Nm/ms   gradient of the torsion bar torque
   mSCruiseLimr_GrdtTorsBarTrqHiRes_xds32           torsion bar torque gradient [Nm/ms]
   mSCruiseLimr_TorsBarTrq_xds16            Nm      torsion bar torque
   vSCruiseLimrI_AbsMaxSafeVehSpd_xdu16     km/h    Maximum vehicle speed
   vSCruiseLimrI_AbsMinSafeVehSpd_xdu16     km/h    Minimum vehicle speed
   ======================================   =====   =====================================================================================


   Detailed Description
   --------------------

   This component checks the input interfaces regarding signal validity. It provides checked and substituted values to the subsequent SCruise Limiter components.

      #. In case the maximum and minimum vehicle speed are detected as invalid, their last valid value are taken as substitute value. At the same time a comfort fade-out is requested via
         fSCruiseLimrI_ReqOff leading to sSCruiseLimrI_State = "Error". The fade-out request is also triggered in case the SCruiseController motor torque is invalid.
      #. In case the Torsion bar torque is invalid, then we use a substitute value = 0Nm. Furthermore this component provides a PT1 filtered torsion bar torque gradient.

   Calibration/Application Parameters
   ==================================

   ================================   ====   =========   =====================================================================
   Parameter Name                     Unit   Range       Description
   ================================   ====   =========   =====================================================================
   xSCruiseLimr_TbtGrdtFilFac_XDU16   1      0.0001..1   filter factor for TorsionBarTorque s gradient
   ================================   ====   =========   =====================================================================

   .. include:: SCruiseLimrCdng_CalMan_VT.irst 

TorqueSensorFallback Check
###########################

Short Description
=================

The check component checks the calculated motor torque and in case of a fault, the torque will be set to 0 Nm immediately.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

Input Signals
-------------
============================================   ====   ==============================================================================
Signal Name                                    Unit   Description
============================================   ====   ==============================================================================
sHwlWrapI_TorsionBarTorqueState_xde                   TBT sensor state from HWL
mFaderConnMotTrqSumI_MotTrq_xds16              Nm     Summation of all input motor torques of FaderConnMotTrqSum
wApplI_SteeringAngle_xds16                     °      corrected steering angle
xApplI_GearSign_xds8                                  sign of the steering gear
xHwlWrapI_MinRedLevel_xdu16                           Current minimum reduction factor
mTsfI_MotorTorque4Check_xds16                  Nm     motor torque after the fallback function (include check component)
============================================   ====   ==============================================================================

Output Signals
--------------
=================================   ====   ===================================================================
Signal Name                         Unit   Description
=================================   ====   ===================================================================
mTsfI_MotorTorque_xds16             Nm     motor torque after the fallback function (include check component)
=================================   ====   ===================================================================

.. only:: confidential

   =================================   ====   ===================================================================
   Signal Name[Internal]               Unit   Description
   =================================   ====   ===================================================================
   sTsfI_ErrLvl_xdu8                          Error level [0=NoError], [1=SWError], [2=HWError]
   sTsfI_ErrLvl_Red_xdu8                      Error level redundant [0=NoError], [1=SWError], [2=HWError]
   =================================   ====   ===================================================================

Detailed Description
--------------------

**Check component**

The check component checks that the motor torque is not higher than the motor torque + a max. allowed value 0.1 Nm one step before and
the motor torque must be lesser after tTsf_ConstTorqueTimeout_XDU8 cycles, when both sensors are defect. If not, the motor torque will
be set to 0 Nm immediately.
Also, the check-component checks that the frozen torque will be ramped down within 20 ms after the failure. If the sign of the torque
changes after the failure, the motor torque will be set to 0 Nm immediately.
The checkfunction will send a SW-Error or a HW-Error accordingly.

   The checkfunction will set the SW-Error when the TorqueSensorFallback function is active and send the HW-Error when the output
   motor torque is 0 Nm.


Calibration/Application Parameters
==================================

==========================================   =====   ==========   ===================================================================================================
Parameter Name                                Unit    Range        Description
==========================================   =====   ==========   ===================================================================================================
mTsf_MaxTorqValueCheck_XDU16                  Nm      0..1.2       max. allowed error motor torq from HWL (Checkcomponent) must be the same as mTsf_MaxTorqValue_XDU16
tTsf_ConstTorqueTimeout_XDU8                  s       0..0.02      cycletime for check of MMot
wTsf_SteeringAngleDeactvnThdCheck_XDU16       °       0..1000      SteeringAngle threshold for deactivation of TorqueSensorFallback (value must be equal to wTsf_SteeringAngleDeactvnThd_XDU16 in TsfMain)
==========================================   =====   ==========   ===================================================================================================

.. include:: TorqueSensorFallbackCheck_CalMan_VT.irst

EndStopHsdCheck
###############

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

The motortorque that is calculated by EndStopHsd is saturated to a controllable value depending on the situation.

Block Diagram
=============

.. only:: confidential

   .. image:: EndStopHsdCheck_BlockDiagram.png
   
Input Signals
-------------
   
.. only:: confidential

   ===============================   =====   ==========================================================================
   Signal Name                       Unit    Description
   ===============================   =====   ==========================================================================
   mEndStopHsdI_MotTrq4Check_xds16   Nm      damping torque at high rotor speeds to be checked
   nApplI_RotorSpeedFilt_xds16       1/min   filtered rotor speed
   nApplI_RotorSpeed_xds16           1/min   unfiltered rotor speed
   uHwlWrapI_SupplyVoltage_xdu16     V       SupplyVoltage, unfiltered
   vVehSpI_AbsMaxSafeVehSpd_xdu16    km/h    Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
   ===============================   =====   ==========================================================================
   
Output Signals
--------------

.. only:: confidential
   
   =================================   ====   =======================================================================================
   Signal Name                         Unit   Description
   =================================   ====   =======================================================================================
   fEndStopHsd_Disable_xdb                    disable flag: in case of a detected error during the monitoring the disable flag is set
   mEndStopHsdI_MotTrq_xds16           Nm     damping torque at high rotor speeds
   mEndStopHsd_MotTrqSaturated_xds16   Nm     saturated damping torque at high rotor speeds
   =================================   ====   =======================================================================================
   
Detailed Description
--------------------
   
.. only:: confidential
   
   If the requested motortorque has the same sign as the rotorspeed, the motortorque is set to zero.
   
   Otherwise the saturation of the motortorque applies different limits depending on whether the rotorspeed is above or below a threshold.
   The base-rotorspeed threshold is different for low and for high speeds.
   In addition the threshold can be offset at low supply voltages.
   The motortorque-limits applied above the rotorspeed threshold are also dependent on the vehicle speed.
   
   It is then checked whether the saturated motortorque is actually within the defined limits. If not, the dinal output is forced to zero
   and a diagnostic event is triggered.
   
Calibration/Application Parameters
==================================

.. only:: confidential
   
   ======================================   =====   ========   =======================================================================================
   Parameter Name                           Unit    Range      Description
   ======================================   =====   ========   =======================================================================================
   fEndStopHsd_EnableUnFiltRotSpeed_XDU8            0..1       0 = filtered rotorspeed; 1 = use unfiltered rotorspeed in highspeeddamping
   mEndStopHsd_DontCareMMotTh_XDU16         Nm      0..0.5     MMot that is generally allowed if the sign is correct (opposite to rotorspeed)
   mEndStopHsd_MaxAllwdMMotVHigh_XDU16      Nm      0..12      Max allowed damping torque at high speeds
   mEndStopHsd_MaxAllwdMMotVLow_XDU16       Nm      0..12      Max allowed damping torque at low speeds
   nEndStopHsd_MinNeededRotSpdVHigh_XDU16   1/min   0..5000    At high speeds damping torque is only allowed above this value
   nEndStopHsd_MinNeededRotSpdVLow_XDU16    1/min   0..5000    At low speeds damping torque is only allowed above this value
   nEndStopHsd_UndervoltOffset_XDU16        1/min   0..5000    Offset to allow high speed damping at lower rotorspeeds in undervoltage situations
   tEndStopHsd_SpeedTooHighTol_XDU16        s       0.001..5   Time that exceeding the speed threshold is tolerated before cancelling backward driving
   uEndStopHsd_ApplyUOffsetTh_XDU16         V       0..33      Voltage threshold under which to apply the additional rotorspeed offset
   vEndStopHsd_MaxAllowedBackward_XDU8      km/h    10..100    Cancel backward driving detection above this speed
   ======================================   =====   ========   =======================================================================================


.. include:: EndStopHsdCheck_CalMan_VT.irst

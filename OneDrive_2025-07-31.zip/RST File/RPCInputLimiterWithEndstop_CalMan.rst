﻿RPCInputLimiterWithEndstop
##############################

Short Description
=================

The component RPCInputLimiterWithEndstop limits the requested rackposition based on the Endstop limits.

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: RPCInputLimiterWithEndstop.png

   Input Signals
   -------------

   =======================================   ==========   =========   ==========================================================================
   Signal Name                               Unit         Range       Description
   =======================================   ==========   =========   ==========================================================================
   fRPCI_Activate_xdu8                          -         [0],[1]     flag for the activation of the RPC controller
   lTpcI_ReqRackPosition_xds16                  mm        -200..200   Requested Rack position
   lEndStopI_EndstopPosLeft_xds16               mm        -125..125   current sw-endstop-positionleft
   lEndStopI_EndstopPosRight_xds16              mm        -125..125   current sw-endstop-positionright
   =======================================   ==========   =========   ==========================================================================

   Output Signals
   --------------

   ======================================   ====   =========   =======================================================================================
   Signal Name                              Unit   Range       Description
   ======================================   ====   =========   =======================================================================================
   lRPCI_NominalRackPosition_xds16          mm     -200..200   Requested rack position for RPC controller (after EndStop limitation)
   yRPCI_InputLimiterDiagData_gds           n.a.     -         Diag data for inputlimiterWithEndstop
   ======================================   ====   =========   =======================================================================================

   Calibration/Application Parameters
   ----------------------------------
   Internal calibration parameters.

   ================================================   =====   =========   ====================================================================
   Parameter Name                                     Unit    Range       Description
   ================================================   =====   =========   ====================================================================
   fRPC_EnableInputLimitation_XDU8                    n.a     0..1        activation of InputLimitation in RPC
   ================================================   =====   =========   ====================================================================

.. include:: RPCInputLimiterWithEndstop_CalMan_VT.irst

Chatter Sensor
##############

Short Description
=================

Detects chatter periods from rotor acceleration which are caused due to an instable controller.

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

Block Diagram
=============
.. image:: ChatterSensor_CalMan_BlockDiagram.png



Input Signals
-------------

================================   =========   ==================================================================
Signal Name                        Unit        Description
================================   =========   ==================================================================
aApplI_RotAcceleration_xds16       1/min/ms    rotor accelereation
scrChatterSensIsActive_xdu8                    ChatterSensor is active => not deactivated by an other component
vApplI_AbsVehicleSpeedFilt_xdu16   km/h        Abs. vehicle speed: processed
================================   =========   ==================================================================


Output Signals
--------------

=================================   ====   ====================================
Signal Name                         Unit   Description
=================================   ====   ====================================
zcrChatterPeriodsCount_xdu8                counter of the chatter oscillations
=================================   ====   ====================================


Detailed Description
--------------------

This function counts the chatter periods which are caused due to an instable controller.
ChatterSensIsActive can be used to deactivate the chatter detection by the supp-component,
if the chattering is a "feature" (e.g. LaneDepartureWarning).

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

======================================   =========   =============   ============================================================================================
Parameter Name                           Unit        Range            Description
======================================   =========   =============   ============================================================================================
ncruAbsChatterGrad_XDU16                 1/min/ms    1..300          minimum rotor acceleration to activation the Chatter detection
tcroChatterTime_XDU8                      ms         0.001..0.254    maximum time until next half period of rotor acceleration must be detected
vcrVehSpeedLimit_XDU16                    km/h       0..255          minimum vahicle speed to start the holding timer
tcrChatterCycleResetDelay_XDU16           ms         0.001..60       hold chatter cycle counter for this time to the value of MinChatterPeriodsCountDelayed
zcrMinChatterPeriodsCountDelayed_XDU8                0..30           minimum chatter cycle counter during holing time (after chatter detection finished)
======================================   =========   =============   ============================================================================================

.. include:: ChatterSensor_CalMan_VT.irst

HighSpeedDamping
################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================
The high speed damping torque is necessary to protect the system from mechanical damage if high forces are introduced via the tie rods. 
In this case a damping torque is calculated against the current eps motor motion and the eps motor acts as a brake to limit the eps rotor speed and the rack speed.
The high speed damping torque is mainly dependent on the rotor speed of the eps motor.
In addition to classic torque the factor dependent HSD torque (generatoric mode) is added in all driving conditions.


Block Diagram
=============

.. image:: HighSpeedDamping_CalMan_BlockDiagram.png

CalcClassicHSD_Torque
=====================
.. image:: HighSpeedDamping_CalMan_CalcClassicHSD_Torque.png

PrameterSelection
=================
.. image:: HighSpeedDamping_CalMan_PrameterSelection.png

RackForceCalc
=============
.. image:: HighSpeedDamping_CalMan_RackForceCalc.png


Input Signals
-------------

=======================================   =====   =========================================================================================================
Signal Name                               Unit    Description
=======================================   =====   =========================================================================================================
fEndStopHsdI_EnableUndervoltOffset_xdb    -       Enable undervolt offset in EndStopHsd if set to true
lEndStopI_DistanceToEndstop_xds16         mm      distance from end stop in mm
nApplI_RotorSpeedFilt_xds16               1/min   filtered rotor speed
nApplI_RotorSpeed_xds16                   1/min   unfiltered rotor speed
uApplI_SupplyVoltage_xdu16                V       SupplyVoltage, unfiltered
vVehSpI_AbsAvgVehSpd_xdu16                km/h    Average vehicle speed. Goal: be as close to the actual speed over ground as possible
vVehSpI_AbsMaxSafeVehSpd_xdu16            km/h    Maximum vehicle speed. Goal: actual speed over ground <= AbsMaxSafeVehSpd.
xApplI_VehDirection_xds8                  -       Sign of vehicle direction forward: 1, reverse: -1
mMotTorLimI_ValidatedMotorTorque_xds16    Nm      limited motor torque by motortorquelimiter
mTrqSumI_TrqSumAfterMTL_xds16             Nm      summation of all input motor torques of sub connector after MotorTorqueLimiter
mApplI_TorsionBarTorque_xds16             Nm      HW LIB: torsion bar torque
xApplI_GearSign_xds8                      -       sign of the steering gear
mApplI_HWLMaxUsableTorque_xdf             Nm      MaxUsableTorque
mHwlWrapI_MaxUsableTorqueGen_xdf32        Nm      Maximum usable motor torque generatoric 
wApplI_SteeringAngle_xds16                deg     corrected steering angle
sApplI_SteeringAngleState_xdu8            -       steering angle status (0=Error, 1=RawInit, 2=ExactlyInit, 3=NotInit, 4=Fallback)  
=======================================   =====   =========================================================================================================


Output Signals
--------------

==========================================   =====   =============================================================================
Signal Name                                  Unit    Description
==========================================   =====   =============================================================================
nEndStopHsd_RotorSpeed_xds16                 1/min   used rotor speed for HighSpeedDamping, with applied hysteresis
fEndStopHsd_ForwardDrv_xdb                   -       Internal fwd driving flag (0=bwd; 1=fwd)
mEndStopHsdI_MotTrq4Check_xds16              Nm      damping torque at high rotor speeds to be checked
fEndStopHsdI_GenMode_xdb                     -       Enable generator Mode if value = 1;Otherwise(value = 0)actuator mode active
mEndStopHsd_ClassicTorque_xds16              Nm      Classic HSD torque
mEndStopHsd_RackForceTorqueUnlimited_xds16   Nm      Totalized torque including inertia, not limited
mEndStopHsd_FactorTorque_xds16               Nm      HSD factor torque
xEndStopHsd_GenModeFactor_xds16              -       measurement value of the used factor
nEndStopHsd_AbsRotorSpeed_xdu16              1/min   used absolute rotor speed for HighSpeedDamping
nEndStopHsd_UnderVoltStartOffset_xdu16       1/min   Undervoltage start input for the calculation of the classic HSD torque
nEndStopHsd_DampStart_xdu16                  1/min   startspeed - Input for calculation of classic HSD torque
xEndStopHsd_DampFact_xdu16                   -       Damping factor for the classic HSD torque
==========================================   =====   =============================================================================


Detailed Description
--------------------
High Speed Damping is a functionality which provides damping motor torque to prevent mechanical damage of the steering gear due to high rack movement at high rotor speeds. 
The High Speed Damping torque have two modes Classic mode and Generatoric Mode. The mode selection is based on fEndStopHsdI_EnableUndervoltOffset. 

Classic Mode torque activation depends on Rotor Speed, DistanceToEndstop, VehicleSpeed, VehichleDirection, Supply Voltage and SteeringAngleState. The HSDClassicTorque  is calculated as below,

HSDClassicTorque = (RotorSpeed – ActivationSpeed) * DampingFactor
 
HSDActivationCurve nEndStopHsd_HighSpeedDampingStart_XAS16 depends on Distance to Endstop and RotorSpeed, along with this SteeringAngleState should carry and Raw or Exactly initialized value.

Damping Factor (xEndStopHsd_HighSpeedDampingFactor_XAU16) depends on VehicleSpeed. 

Based on the VehicleDirection Forward Damping Factor or Reverse Damping factor is selected.
In the normal Voltage Situation HSDActivationCurve is used, in case of undervoltage situation Undervoltageoffset(supply voltage, offset)gets subtracted from HSDActivationCurve. 

Generatoric mode will get activation only when the motor torque and rotor speed are in different directions. 
Generatoric Mode occurs when the torque of the motor is opposing the direction of rotation and the motor is generating electrical energy. 
Prevented the detection of generatoric mode in the SW Endstop Damping Torque because it is only relevant if generatoric mode is caused by external forces at the front axle.

HSDTorque = (HSD_ClassicTorque *  HSD_GenModeFactorTorq) + Hsd_FactorTorque

HSD_FactorTorque should only get active during standstill or slow driving. 

HSD_GenModeFactorTorq - The factor selection is based on the calculated Unlimited RackForceTorque. 

Unlimited RackForceTorque is calculated based on EstimatedHSDTorque (HSD_ClassicTorque, Rotor Speed, VehicleSpeed) and 
TorsionBarTorqueContribution (iVar ratio calculation from TorsionBarTorque, AbsSteeringAngle, SteeringAngleState) and 
RotorInertiaTorqueContribution (RotorAcceleration).
This calculated Unlimited RackForceTorque is filtered by using BandStop filter to damp out certain frequency.
The noise caused by rotor acceleration is removed by PT1 filter.

Calibration/Application Parameters
==================================

.. Please note: the following list of parameters will always be visible in the generated documentation!

====================================================   =====   =============== =========================================================================================================================
Parameter Name                                         Unit    Range           Description
====================================================   =====   =============== =========================================================================================================================
fEndStopHsd_EnableUnFiltRotSpeed_XDU8                          0..1            0 = filtered rotorspeed; 1 = use unfiltered rotorspeed in highspeeddamping
lEndStopHsd_SubstDistToES_XDU16                        mm      0..125          subst value - distance to endstop used if steering angle is invalid
nEndStopHsd_HighSpeedDampingStartReverse_XAS16         1/min   0..5000         rotor speed border to switch on the highspeed damping when reversing
nEndStopHsd_HighSpeedDampingStart_XAS16                1/min   0..5000         rotor speed border to switch on the highspeed damping
nEndStopHsd_UnderVoltageStartOffset_XAU16              1/min   0..5000         rotor speed reduction for start speed during undervoltage
tEndStopHsd_SpeedTooHighTol_XDU16                      s       0.001..5        Time that exceeding the speed threshold is tolerated before cancelling backward driving
tEndStopHsd_VehDirDebounceTime_XDU16                   s       0.001..10       Reverse driving flag is debounced by this amount of time before changing to forward
vEndStopHsd_BackwardDisableTh_XDU8                     km/h    0..50           Disable backward driving flag when speed falls below this threshold
vEndStopHsd_BackwardEnableTh_XDU8                      km/h    0..50           Backward driving is only detected above this speed threshold
vEndStopHsd_MaxAllowedBackward_XDU8                    km/h    10..100         Cancel backward driving detection above this speed
xEndStopHsd_HighSpeedDampingFactorReverse_XAU16        -       0..0.0048828    factor of highspeed damping Nm*min dependent on vehicle speed when reversing
xEndStopHsd_HighSpeedDampingFactor_XAU16               -       0..0.0048828    factor of highspeed damping Nm*min dependent on vehicle speed
xEndStopHsd_SubstHighSpeedDampingFactorReverse_XDU16   -       0..0.0048828    subst value - factor of highspeed damping Nm*min when reversing
xEndStopHsd_SubstHighSpeedDampingFactor_XDU16          -       0..0.0048828    subst value - factor of highspeed damping Nm*min
xEndStopHsd_EngStartHighSpeedDampingFactor_XDU16       -       0..0.0048828125 subst value - Motor Start factor of highspeed damping Nm*min
xEndStopHsd_RotAccelerationLowFilterFact_XDU16         -       0.001..1.0      filter factor to calculate the rotor acceleration
xEndStopHsd_AdditionalSystemInertiaFact_XDS16          -       -3.99..3.99     subst value/additional factor - to consider whole system intertia beside rotor inertia
xEndStopHsd_MechTorqueFilterFact_XDU16                 -       0.001..0.5      Filter factor of filtered rotor acceleration
fEndStopHsd_EnableBandStopFiltering_XDB                -       0..1            1 = Bandsperre for comp. TBT on, 0 = Bandstop out
xEndStopHsd_BandStopFilter_S1_XDF32                    -       -9..9           parameter for BandStopFilter calculation at S1
xEndStopHsd_BandStopFilter_A2_XDF32                    -       -9..9           parameter for BandStopFilter calculation at A2
xEndStopHsd_BandStopFilter_A3_XDF32                    -       -9..9           parameter for BandStopFilter calculation at A3
xEndStopHsd_BandStopFilter_B2_XDF32                    -       -9..9           parameter for BandStopFilter calculation at B2
lEndStopHsd_MinDistToES4GenMode_XDS16                  -       0..125          Below this DistanceToES, if DistanceToES is increasing, GenMode is not detected
xEndStopHsd_Thresh4ActivOfGenMode_XDU16                -       0.001..1.0      Threshold to determine steering system is in generator mode
xEndStopHsd_RotSpeedFact_XAU16                         -       0.0..1.0        
xEndStopHsd_MinRotSpeedFact_XAU16                      -       0.0..1          Vehicle speed dependent factor for FactorTorque (Limitation)
xEndStopHsd_GenModeFactor_XAS16                        -       0.0..1          Factor multiplied with the original calculated HSD_torque; Factor dependent on the Steering mode (generator/motor - mode)
====================================================   =====   =============== =========================================================================================================================


.. include:: HighSpeedDamping_CalMan_VT.irst

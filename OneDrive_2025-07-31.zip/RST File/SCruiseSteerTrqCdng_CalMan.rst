Smart Cruise Interface | Steer Torque Conditioning
#######################################################

.. only:: confidential

   .. warning:: This document is classified as **confidential**! Do not distribute!


Short Description
=================

This component provides the signal conditioning for the FC Steer Torque Calculation including validity checks and filtering of input signals.
It also provides the rack speed calculated out of the rotor speed to the SCruiseLimiter.

.. only:: confidential

   Block Diagram
   =============

   .. image:: SCruiseSteerTrqCdng_CalMan_BlockDiagram.png


Input Signals
-------------

=====================================   ========   ===========================================================================================================================
Signal Name                             Unit       Description
=====================================   ========   ===========================================================================================================================
mApplI_TorsionBarTorque_xds16           Nm         HW LIB: torsion bar torque
mStFCI_NominalSteerTorque_xds16         Nm         Nominal Steer Torque for Controller
xEpsInI_SCruiseReqdSteerFeelFac_xdu16   --         SCruise requested steer feel factor
xEpsInI_SCruiseReqdStfnFac_xdu16        --         SCruise requested stiffness factor
=====================================   ========   ===========================================================================================================================

.. only:: confidential

   =====================================   ========   ===========================================================================================================================
   Signal Name                             Unit       Description
   =====================================   ========   ===========================================================================================================================
   aHwlWrapI_RotorAcceleration_xdf32       rad/s²     filtered rotor acceleration
   nrsI_IntRotorSpeed_xds16                1/min      rotor speed
   sHwlWrapI_TorsionBarTorqueState_xde     --         HwLib TorsionBar Torque State
   xApplI_GearSign_xds8                    --         sign of the steering gear
   sSCruiseI_State_xdu8                    --         State of SmartCruise Statemachine: 0=Inin, 1=NotAvl, 2=Avl, 3=FctCoReq, 4=FadeIn, 5=Actv, 6=FadeOut
   xSCruiseI_HandsOnFadrFac_xdu16          --         Fading factor HandsOn (1) to other modes (0)
   xSgcI_RatioMot2RackCorrFact_xdu16       --         I-Var correction factor for RackSpeed
   =====================================   ========   ===========================================================================================================================

Output Signals
--------------

===================================   ========   ========================================================================================================================================
Signal Name                           Unit       Description
===================================   ========   ========================================================================================================================================
aSCruiseI_RotAccel_xds16              1/min/ms   SCruise mapped filtered rotor acceleration
mSCruiseI_NomSteerFeelTrq_xds16       Nm         Nominal Steer Assistance Torque (RG3) for Controller scaled by steer feel factor
mSCruiseI_TorsBarTrq_xds16            Nm         Validity checked TorsionBarTorque for SCruise
nSCruiseI_RotSpd_xds16                1/min      SCruise mapped filtered rotor speed, gear sign adjusted
vSCruiseI_RackSpd_xds32               mm/s       Filtered rack speed
xSCruiseI_SteerFeelFac_xdu16          --         Rate limited steering feel factor for SCruise, received from bus
xSCruiseI_StfnFac_xdu16               --         Rate limited stiffness factor for SCruise, received from bus
===================================   ========   ========================================================================================================================================

.. only:: confidential

   ===================================   ========   ========================================================================================================================================
   Signal Name                           Unit       Description
   ===================================   ========   ========================================================================================================================================
   fSCruiseI_SteerTrqReqOff_xdu8         --         Signal summarizes different inputs required from SCruiseTorqueController to switch SCI Off(1) or keep available(0)
   ===================================   ========   ========================================================================================================================================

   Detailed Description
   --------------------

   This component provides the signal conditioning for input signals of the FC Steer Torque Calculation:

   * The stiffness and steer feel factor are rate limited. The steer feel factor is multiplied with the HandsOn fading factor, hence it is set to 0 in case of HandsFree mode. Furthermore the stiffness factor shall not reach low values at the same time the steer feel factor does. Once the steer feel factor falls below the limit xSCruise_MinStfnFacAtLoSteerFeelFac_XDU8 the stiffness factor will be raised to this minimum value. For testing purposes also both factors can be set to a calibration value to overwrite the bus signal.

   * The nominal steer feel torque is provided as product of the steer feel factor and mStFCI_NominalSteerTorque.

   * The torsion bar torque is provided as SCI internal interface. The validity check considers also the torsion bar torque state validity bit.

   * The rotor speed and rotor acceleration are calculated and PT1 filtered. Furthermore they are multiplied with the gear sign.

   * All input signals are checked regarding their validity. In case either rotor speed, rotor acceleration, gear sign or torsion bar torque is invalid a comfort fade-out is requested via fSCruiseI_SteerTrqReqOff_xdu8.

   It also provides the rack speed calculated out of the rotor speed to the FC Steer Torque Calculation and the FC SCruise Limiter. The rack speed is PT2 filtered by two consecutive PT1 filters and truncation error compensated by adding a half LSB (2^-9) of the original resolution.


Calibration/Application Parameters
==================================

=========================================   ====   ==============   ===============================================================================================================
Parameter Name                              Unit   Range            Description
=========================================   ====   ==============   ===============================================================================================================
xSCruise_SubSteerFeelFac_XDU16              --     0..3.9844        substitution of xEpsInI_SCruiseReqdSteerFeelFac_xdu16 if value is within valid factor range (0..1)
xSCruise_SubStfnFac_XDU16                   --     0..3.9844        substitution of xEpsInI_SCruiseReqdStfnFac_xdu16 if value is within valid factor range (0..1)
xSCruise_StfnAndSteerFeelFacGrad_XDU16      1/s    0.2..1000        gradient of stiffness and steer feel factor
xSCruise_MinStfnFacAtLoSteerFeelFac_XDU8    --     0.3..1           minimum applied stiffness factor in case steer feel and requested stiffness factor fall both below this limit.
=========================================   ====   ==============   ===============================================================================================================

.. only:: confidential

   =========================================   ====   ==============   ===============================================================================================================
   Parameter Name                              Unit   Range            Description
   =========================================   ====   ==============   ===============================================================================================================
   xSCruise_RotSpdFiltFact_XDU16               --     0.0001..1        filter factor for rotor speed PT1 filter
   xSCruise_RotAccFiltFact_XDU16               --     0.0001..1        filter factor for rotor acceleration PT1 filter
   xSCruise_RackSpdFilFac1_XDU8                       0.1..1           low-pass filter factor for RackSpd of first PT1
   xSCruise_RackSpdFilFac2_XDU8                       0.1..1           low-pass filter factor for RackSpd of second PT1
   xsyGearRatioMot2Rack_XDU16                  mm     1.9..5           scaling factor for servomotorrev to racktravel [mm]
   =========================================   ====   ==============   ===============================================================================================================

   .. include:: SCruiseSteerTrqCdng_CalMan_VT.irst

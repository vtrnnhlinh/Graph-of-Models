FltManStateMachineDualUcSymm
############################

.. only:: confidential

    .. warning:: This document is classified as **confidential**! Do not distribute!

   Short Description
   =================

   The FltManStateMachine component calculates several flags namely; InitDone, DisableLocal as well as drive the FaultManagement state machine.


   Output Signals
   --------------

   ===================================   ====   ==============================================================
   Signal Name                           Unit   Description
   ===================================   ====   ==============================================================
   sFltManI_FaultMode_xdu8                      State variable of Fault Management state machine
   sFltManI_EcuChStateReq4Chk_xdu8              GDU control request to Hwlib
   sFltManI_ReqEcuState4Chk_xdu8                Request ECU state
   sFltManI_EcuFaultMode4Chk_xdu8               Fault mode information
   sFltManI_ActiveState4Chk_xdu16               ID of the current active state
   xFltManI_FailOpRampLevel_xdu16               Calculated FailOp ramp target
   yFltManI_FailOpRedGrad_xdu16                 Calculated FailOp ramp gradient
   sFltManI_EcuChannelRole4Chk_xdu8             Indicated whether current channel is Master (1=Master 0=Slave)
   ===================================   ====   ==============================================================

   Detailed Description
   --------------------
   This component updates component specific internal variables with corresponding provided inputs, updates the fault management state of the functionality specific 
   state machine, updates the disable request in the corresponding state of the functionality specific state machine, updates the hw initialization status in the 
   corresponding state of the functionality specific state machine,executes the corresponding state handler within a particular state, updates the SetOutputsID, 
   EcuChannelStateReq, ModeSyncTx, RequestEcuState, EcuChannelRole,TorqueDistributionStatus and EcuFaultMode functionality specific public interfaces  in order to 
   prevent the violation of safety goals by maintaining the appropriate functionality specfic state.
   
   Calibration/Application Parameters
   ==================================
 
   Internal Calibaration parameters:
   
   ===========================================   ==========   ========     ====================================================================== 
   Parameter Name                                Unit         Range        Description
   ===========================================   ==========   ========     ======================================================================
   yFltMan_FaultActionGradient_XAU16             Factor/ms    0..1         Gradients to be used for reduction in case of a dedicated fault 
   xFltMan_FaultActionRedLevel_XAU16             %            0..100       Reductions level to be used for reduction in case of a dedicated fault 
   ===========================================   ==========   ========     ======================================================================


.. include:: FltManStateMachineDualUcSymm_CalMan_VT.irst
 
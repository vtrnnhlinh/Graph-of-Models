Driver Torque V2
################

Short Description
=================

Calculates the driver torque based on the torsion bar torque and the rotor speed.

.. only:: confidential
   
   .. warning:: This document is classified as **confidential**! Do not distribute!

   Block Diagram
   =============

   .. image:: DriverTorqueV2_CalMan_BlockDiagram.png

   Input Signals
   -------------

   ==================================   =======   ==============================
   Signal Name                          Unit      Description
   ==================================   =======   ==============================
   mApplI_TorsionBarTorque_xds16        Nm        HW LIB: torsion bar torque
   nApplI_RotorSpeed_xds16              1/min     unfiltered rotor speed
   xApplI_GearSign_xds8                           sign of the steering gear
   mApplI_GradTorsionBarTorque_xds16    Nm/ms     HW LIB: torque gradient
   xApplI_TorsionBarStiffness_xdu16     NM / °    HW LIB: torsion bar stiffness
   ==================================   =======   ==============================


   Output Signals
   --------------

   =================================   ====   =============================
   Signal Name                         Unit   Description
   =================================   ====   =============================
   mApplI_DriverTorque_xds16            Nm    calculated driver torque
   mApplI_AbsDriverTorque_xdu16         Nm    abs calculated driver torque
   =================================   ====   =============================


   Detailed Description
   --------------------

   The component shall calcualte actual driver input from Torsion bar torque and Rotor Speed considering the inertia of the steering wheel.


   Calibration/Application Parameters
   ==================================

   .. Please note: the following list of parameters will always be visible in the generated documentation!

   ========================================   =======   =========   ======================================================================================================
   Parameter Name                             Unit      Range       Description
   ========================================   =======   =========   ======================================================================================================
   sDrvTorque_UseDynSteerAngle_XDU8                     0..1        0): use wApplI_DynSteerAngle_xds16; (1): use internal calculated DynSteerAngle (out of RotorPosition)
   xDrvTorque_Sign_XDS16                                -1..1       Sign DriverTorque
   xDrvTorque_TBTFilterFact_XDU16                       0.001..1    filter 1 and 2 of the torsion bar torque
   xDrvTorque_RotAccFilterFact_XDU16                    0.001..1    filter 1 and 2 of the steering wheel acceleration
   xDrvTorque_SWRotorInertia_XDU16                      0..1        relevant inertia of steering wheel[kgm^2]
   xDrvTorque_TorsionBarStiffnessMod_XDS16    NM / °    0..3        Modification of torsion bar torque
   ========================================   =======   =========   ======================================================================================================

   Internal calibration parameters
   -------------------------------

   ========================== =====   ============  ========================
   Parameter Name             Unit    Range         Description
   ========================== =====   ============  ========================
   jsyInvSteeringRatio_XDU16          900 .. 3000   1/steeringratio * 2^15
   ========================== =====   ============  ========================

.. include:: DriverTorqueV2_CalMan_VT.irst
